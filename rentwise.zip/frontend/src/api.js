const BASE = import.meta.env.VITE_API_URL || "http://localhost:3001";

function getToken() {
  return localStorage.getItem("rentwise_token");
}

async function req(path, opts = {}) {
  const token = getToken();
  const res = await fetch(`${BASE}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    ...opts,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  return res.json();
}

export const api = {
  base: BASE,
  // Stored media references are either a local relative path (/uploads/xxx)
  // or, once S3 is configured, a full signed https:// URL — this makes every
  // <img>/<a> call site work with either without caring which.
  mediaUrl: (u) => (!u ? u : /^https?:\/\//.test(u) ? u : `${BASE}${u}`),
  setToken: (t) => (t ? localStorage.setItem("rentwise_token", t) : localStorage.removeItem("rentwise_token")),
  getToken,

  signup: (data) => req(`/api/auth/signup`, { method: "POST", body: JSON.stringify(data) }),
  login: (data) => req(`/api/auth/login`, { method: "POST", body: JSON.stringify(data) }),
  me: () => req(`/api/auth/me`),
  updateProfile: (data) => req(`/api/auth/me`, { method: "PATCH", body: JSON.stringify(data) }),
  resendVerification: (email) => req(`/api/auth/resend-verification`, { method: "POST", body: JSON.stringify({ email }) }),
  forgotPassword: (email) => req(`/api/auth/forgot-password`, { method: "POST", body: JSON.stringify({ email }) }),
  resetPassword: (token, password) => req(`/api/auth/reset-password`, { method: "POST", body: JSON.stringify({ token, password }) }),
  verifyEmail: (token) => req(`/api/auth/verify-email?token=${encodeURIComponent(token)}`),
  changePassword: (data) => req(`/api/auth/change-password`, { method: "POST", body: JSON.stringify(data) }),
  exportData: () => req(`/api/auth/export-data`),
  deleteAccount: () => req(`/api/auth/me`, { method: "DELETE" }),

  googleAuthStatus: () => req(`/api/auth/google/status`),

  // Full-page redirect to Google — no popup, so there's no window.opener /
  // Cross-Origin-Opener-Policy relationship for a browser to sever.
  goToGoogleLogin() {
    window.location.href = `${BASE}/api/auth/google`;
  },

  // Called once on app load. If the URL carries a `google_auth` handoff code
  // (we just landed back here after Google), trade it for the real token+user
  // and clean the URL. Returns null when there's nothing to do.
  async consumeGoogleAuthHandoff() {
    const params = new URLSearchParams(window.location.search);
    const code = params.get("google_auth");
    if (!code) return null;
    window.history.replaceState({}, "", window.location.pathname);
    const { user, token } = await req(`/api/auth/google/exchange?code=${encodeURIComponent(code)}`);
    api.setToken(token);
    return user;
  },

  searchAreas: (q) => req(`/api/areas?q=${encodeURIComponent(q)}`),
  createArea: (area) => req(`/api/areas`, { method: "POST", body: JSON.stringify(area) }),

  searchProperties: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return req(`/api/properties${qs ? `?${qs}` : ""}`);
  },
  findDuplicates: (params) => {
    const qs = new URLSearchParams(params).toString();
    return req(`/api/properties/duplicates?${qs}`);
  },
  createProperty: (property) => req(`/api/properties`, { method: "POST", body: JSON.stringify(property) }),
  getProperty: (id) => req(`/api/properties/${id}`),
  filterDefinitions: () => req(`/api/filter-definitions`),
  setPropertyFilterValues: (propertyId, values) => req(`/api/properties/${propertyId}/filter-values`, { method: "POST", body: JSON.stringify({ values }) }),

  submitReview: (propertyId, review) =>
    req(`/api/properties/${propertyId}/reviews`, { method: "POST", body: JSON.stringify(review) }),
  reportReview: (reviewId, report) =>
    req(`/api/reviews/${reviewId}/reports`, { method: "POST", body: JSON.stringify(report) }),

  // Private verification evidence attached to a review (photo/video/document/
  // location/date_time). Never shown publicly — see routes/evidence.js.
  async uploadEvidence(propertyId, file, { caption, reviewId, documentType = "photo", submittedLat, submittedLng, eventAt } = {}) {
    const form = new FormData();
    if (file) form.append("file", file);
    if (caption) form.append("caption", caption);
    if (reviewId) form.append("review_id", reviewId);
    form.append("document_type", documentType);
    if (submittedLat != null) form.append("submitted_lat", submittedLat);
    if (submittedLng != null) form.append("submitted_lng", submittedLng);
    if (eventAt) form.append("event_at", eventAt);
    const res = await fetch(`${BASE}/api/properties/${propertyId}/evidence`, { method: "POST", body: form });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.error || `Upload failed: ${res.status}`);
    }
    return res.json();
  },

  // Public listing photo gallery (exterior/interior + cover selection), distinct from evidence above.
  async uploadPropertyPhoto(propertyId, file, { area = "exterior", caption, isCover } = {}) {
    const form = new FormData();
    form.append("file", file);
    form.append("area", area);
    if (caption) form.append("caption", caption);
    if (isCover) form.append("is_cover", "true");
    const res = await fetch(`${BASE}/api/properties/${propertyId}/photos`, { method: "POST", body: form });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.error || `Upload failed: ${res.status}`);
    }
    return res.json();
  },
  setCoverPhoto: (propertyId, photoId) =>
    req(`/api/properties/${propertyId}/photos/${photoId}/cover`, { method: "PATCH" }),
  deletePropertyPhoto: (propertyId, photoId) =>
    req(`/api/properties/${propertyId}/photos/${photoId}`, { method: "DELETE" }),

  // Admin dashboard — every call here 403s server-side unless the signed-in user has role='admin'.
  admin: {
    stats: () => req(`/api/admin/stats`),
    reports: (status) => req(`/api/admin/reports${status ? `?status=${encodeURIComponent(status)}` : ""}`),
    updateReport: (id, data) => req(`/api/admin/reports/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
    reviews: (params = {}) => req(`/api/admin/reviews?${new URLSearchParams(params).toString()}`),
    updateReview: (id, status) => req(`/api/admin/reviews/${id}`, { method: "PATCH", body: JSON.stringify({ status }) }),
    evidence: (params = {}) => req(`/api/admin/evidence?${new URLSearchParams(params).toString()}`),
    annotateEvidence: (id, adminNote) => req(`/api/admin/evidence/${id}`, { method: "PATCH", body: JSON.stringify({ admin_note: adminNote }) }),
    propertyVerification: (id) => req(`/api/admin/properties/${id}/verification`),
    users: (q) => req(`/api/admin/users?q=${encodeURIComponent(q || "")}`),
    setUserRole: (id, role) => req(`/api/admin/users/${id}/role`, { method: "PATCH", body: JSON.stringify({ role }) }),
    contactMessages: (params = {}) => req(`/api/admin/contact-messages?${new URLSearchParams(params).toString()}`),
    resolveContactMessage: (id, resolved) => req(`/api/admin/contact-messages/${id}`, { method: "PATCH", body: JSON.stringify({ resolved }) }),
    filterDefinitions: () => req(`/api/admin/filter-definitions`),
    createFilterDefinition: (data) => req(`/api/admin/filter-definitions`, { method: "POST", body: JSON.stringify(data) }),
    updateFilterDefinition: (id, data) => req(`/api/admin/filter-definitions/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
  },

  contactUs: (data) => req(`/api/contact`, { method: "POST", body: JSON.stringify(data) }),
};
