import React, { useState, useEffect, useMemo } from "react";
import {
  Search, MapPin, Droplet, Zap, Shield, Volume2, Wrench, Wifi, Star,
  Plus, ChevronLeft, Check, AlertTriangle, User, Loader2, ShieldCheck, ClipboardList,
  SlidersHorizontal, LayoutDashboard, ImageOff,
} from "lucide-react";
import "leaflet/dist/leaflet.css";
import { api } from "./api.js";
import LocationPicker from "./components/LocationPicker.jsx";
import PropertyMap from "./components/PropertyMap.jsx";
import EvidenceUploader from "./components/EvidenceUploader.jsx";
import PropertyPhotoUploader from "./components/PropertyPhotoUploader.jsx";
import SelectableOther from "./components/SelectableOther.jsx";
import { KENYA_COUNTIES, COUNTY_NAMES, subcountiesFor } from "./kenyaLocations.js";
import AdminDashboard from "./components/AdminDashboard.jsx";
import { Login, Signup, ForgotPassword, ResetPassword, VerifyEmailLanding } from "./components/AuthForms.jsx";
import { Footer, AboutPage, TermsPage, PrivacyPage, ContactPage, FaqsPage } from "./components/StaticPages.jsx";
import Account from "./components/Account.jsx";
import { User as UserIcon } from "lucide-react";

// ---------- design tokens ----------
const ink = "#20261F";
const paper = "#F6F2E9";
const paperRaised = "#FBF8F0";
const clay = "#A8451F";
const forest = "#33512E";
const ochre = "#B9862E";
const rust = "#9C2B2B";
const line = "#D8CFBD";
const glow = "#E8B84B";
const muted = "#6E6455";

const FONTS = (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700&family=IBM+Plex+Sans:wght@400;500;600&display=swap');
    html { color-scheme: light; }
    body { margin: 0; background: ${paper}; }
    .rw { font-family: 'IBM Plex Sans', sans-serif; color: ${ink}; background: ${paper}; min-height: 100vh; }
    .rw h1, .rw h2, .rw h3, .rw .display { font-family: 'Fraunces', serif; }
    .stamp { border: 1.5px solid currentColor; padding: 2px 8px; font-size: 11px; letter-spacing: 0.02em; }
    .chip { border: 1px solid ${line}; background: ${paperRaised}; cursor: pointer; user-select: none; transition: transform 0.15s cubic-bezier(.34,1.56,.64,1), background 0.15s ease, color 0.15s ease, border-color 0.15s ease; }
    .chip:hover { transform: translateY(-1px); border-color: ${clay}; }
    .chip.on { background: ${ink}; color: ${paper}; border-color: ${ink}; }
    .barwrap { background: #EAE3D2; height: 6px; border-radius: 4px; overflow: hidden; }
    .barfill { height: 6px; background: linear-gradient(90deg, ${clay}, ${glow}); transition: width 0.5s cubic-bezier(.34,1.2,.64,1); border-radius: 4px; }
    .input { width:100%; padding:10px 12px; background:${paperRaised}; border:1px solid ${line}; font-size:14px; outline:none; box-sizing: border-box; transition: border-color 0.15s ease, box-shadow 0.15s ease; }
    .input:focus { border-color: ${clay}; box-shadow: 0 0 0 3px ${clay}22; }

    /* ---- colour + motion system: links, buttons, badges, icons ---- */
    .muted-text { color: ${muted}; }
    .link { color: ${clay}; font-weight: 500; text-decoration: none; background: none; border: none; cursor: pointer; transition: color 0.15s ease; }
    .link:hover { color: ${ochre}; text-decoration: underline; }
    .btn-pop { transition: transform 0.18s cubic-bezier(.34,1.56,.64,1), box-shadow 0.18s ease; }
    .btn-pop:hover { transform: translateY(-1px) scale(1.03); box-shadow: 0 10px 22px -10px rgba(32,38,31,0.45); }
    .btn-pop:active { transform: scale(0.96); }
    .btn-pop:disabled:hover { transform: none; box-shadow: none; }
    .cat-icon { display: inline-flex; align-items: center; justify-content: center; border-radius: 50%; flex-shrink: 0; transition: transform 0.2s cubic-bezier(.34,1.56,.64,1); }
    .cat-icon:hover { transform: scale(1.12) rotate(-4deg); }
    .pill { display: inline-flex; align-items: center; gap: 4px; padding: 3px 10px; border-radius: 999px; font-size: 11px; font-weight: 600; letter-spacing: 0.01em; }
    .pill-green { background: #E3EFDD; color: ${forest}; }
    .pill-amber { background: #FBEBC9; color: ${ochre}; }
    .pill-rust  { background: #F3E0D8; color: ${clay}; }
    .pill-blue  { background: #DCEAFA; color: #2E86D6; }
    .stat-card { position: relative; overflow: hidden; }
    .stat-card::before { content: ""; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: var(--accent, ${clay}); }

    /* ---- layout widths: forms stay readable narrow, browsing/passport use the room a large screen has ---- */
    .wrap-form { max-width: 640px; margin: 0 auto; padding: 2rem 1.25rem 4rem; }
    .wrap-mid  { max-width: 980px; margin: 0 auto; padding: 1.75rem 1.25rem 5rem; }
    .wrap-wide { max-width: 1280px; margin: 0 auto; padding: 2rem 1.5rem 5rem; }
    @media (min-width: 640px)  { .wrap-mid, .wrap-wide { padding-left: 2rem; padding-right: 2rem; } }
    @media (min-width: 1024px) { .wrap-wide { padding-left: 3rem; padding-right: 3rem; } }

    .listing-grid { display: grid; grid-template-columns: 1fr; gap: 1rem; }
    @media (min-width: 640px)  { .listing-grid { grid-template-columns: 1fr 1fr; } }
    @media (min-width: 1024px) { .listing-grid { grid-template-columns: 1fr 1fr 1fr; } }

    .passport-grid { display: grid; grid-template-columns: 1fr; gap: 0 3rem; }
    @media (min-width: 900px) { .passport-grid { grid-template-columns: 1.1fr 0.9fr; align-items: start; } }
    .passport-grid > .passport-col { min-width: 0; }

    /* ---- property card ---- */
    .prop-card { background: ${paperRaised}; border: 1px solid ${line}; overflow: hidden; text-align: left; display: block; transition: transform 0.15s ease, box-shadow 0.15s ease; }
    .prop-card:hover { transform: translateY(-2px); box-shadow: 0 8px 20px -12px rgba(32,38,31,0.35); }
    .prop-card-media { position: relative; aspect-ratio: 4 / 3; overflow: hidden; background: ${ink}; }
    .prop-card-media img { width: 100%; height: 100%; object-fit: cover; }

    /* ---- roofline motif: a deliberately hand-drawn skyline of pitched roofs, used sparingly as the hero's one bold element ---- */
    .roofline { display: block; width: 100%; height: auto; }

    /* ---- hero scene: animated glow-doorway motif (evolved from the logo) ---- */
    .hero-grid { display: grid; grid-template-columns: 1fr; gap: 2rem; align-items: center; }
    @media (min-width: 720px) { .hero-grid { grid-template-columns: 1.1fr 0.9fr; } }
    .hero-scene { position: relative; aspect-ratio: 1; max-width: 320px; margin: 0 auto; }
    .hero-arch { position: relative; width: 100%; height: 100%; z-index: 1; }
    .hero-glow {
      position: absolute; inset: 10%; border-radius: 50%;
      background: radial-gradient(circle, ${glow}45 0%, ${glow}00 68%);
      animation: heroGlowPulse 5s ease-in-out infinite; z-index: 0;
    }
    @keyframes heroGlowPulse { 0%, 100% { opacity: 0.6; transform: scale(1); } 50% { opacity: 1; transform: scale(1.15); } }
    .hero-orbit-icon {
      position: absolute; z-index: 2; width: 30px; height: 30px; border-radius: 50%;
      background: ${paperRaised}; border: 1px solid ${line}; color: ${clay};
      display: flex; align-items: center; justify-content: center;
      animation: heroFloat 4s ease-in-out infinite;
      box-shadow: 0 6px 14px -8px rgba(32,38,31,0.4);
    }
    @keyframes heroFloat { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-8px); } }
    .fade-in-up { animation: fadeInUp 0.6s ease both; }
    @keyframes fadeInUp { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: translateY(0); } }
  `}</style>
);

// A simple repeating skyline of pitched-roof houses — the one bold, subject-specific
// visual moment on the home screen. Colours pull from the existing editorial palette
// rather than introducing a new accent, so it reads as part of the app, not a banner ad.
function Roofline({ color = clay, bg = "none", height = 64 }) {
  const houses = [
    { w: 46, h: 30 }, { w: 60, h: 42 }, { w: 38, h: 24 }, { w: 70, h: 50 },
    { w: 44, h: 28 }, { w: 56, h: 38 }, { w: 40, h: 26 }, { w: 64, h: 44 },
    { w: 48, h: 32 }, { w: 36, h: 22 }, { w: 58, h: 40 }, { w: 42, h: 27 },
  ];
  let x = 0;
  const baseY = 60;
  return (
    <svg className="roofline" viewBox={`0 0 640 64`} preserveAspectRatio="none" style={{ height }}>
      {bg !== "none" && <rect x="0" y="0" width="640" height="64" fill={bg} />}
      {houses.map((h, i) => {
        const startX = x;
        x += h.w;
        const roofPeakX = startX + h.w / 2;
        return (
          <g key={i} opacity={0.9 - (i % 3) * 0.15}>
            <rect x={startX + 4} y={baseY - h.h * 0.55} width={h.w - 8} height={h.h * 0.55} fill={color} opacity="0.16" />
            <polygon points={`${startX},${baseY - h.h * 0.55} ${roofPeakX},${baseY - h.h} ${startX + h.w},${baseY - h.h * 0.55}`} fill={color} opacity="0.5" />
          </g>
        );
      })}
      <line x1="0" y1={baseY} x2="640" y2={baseY} stroke={color} strokeOpacity="0.3" strokeWidth="1" />
    </svg>
  );
}

function CatIcon({ c, size = 13 }) {
  return (
    <span
      className="cat-icon"
      style={{ background: `${c.color}22`, color: c.color, width: size + 12, height: size + 12 }}
    >
      <c.icon size={size} />
    </span>
  );
}

const CATEGORIES = [
  { key: "water", label: "Water reliability", icon: Droplet, color: "#2E86D6" },
  { key: "electricity", label: "Electricity", icon: Zap, color: "#D9A61E" },
  { key: "security", label: "Security", icon: Shield, color: "#7B3FA0" },
  { key: "noise", label: "Noise", icon: Volume2, color: "#D9622B" },
  { key: "maintenance", label: "Maintenance", icon: Wrench, color: "#2F8F73" },
  { key: "internet", label: "Internet / network", icon: Wifi, color: "#5B4FCF" },
  { key: "landlord", label: "Landlord responsiveness", icon: User, color: "#C2478D" },
  { key: "value", label: "Value for money", icon: Star, color: "#C9971E" },
];

const WHY_LEFT = [
  "Rent increased", "Water problems", "Electricity problems", "Poor security",
  "Noise", "Flooding", "Poor maintenance", "Landlord issues", "Caretaker issues",
  "Poor internet/network", "Pest infestation", "Structural problems",
  "Lack of parking", "Deposit problems", "Hidden charges", "Job relocation",
  "Family reasons", "Bought own house", "Other",
];

const DURATIONS = ["<3 months", "3-6 months", "6-12 months", "1-2 years", "2+ years"];
const RECOMMEND = ["Definitely", "Probably", "Not sure", "Probably not", "Never"];
const TYPES = ["Bedsitter", "Single room", "1 Bedroom", "2 Bedroom", "3 Bedroom", "Maisonette", "SQ", "Other"];

const CHECKLIST = [
  "Test the taps for water pressure", "Ask about supply interruptions",
  "Check the water storage tank", "Ask about backup power / tokens",
  "Check common-area lighting and gate", "Ask about night security arrangements",
  "Look for cracks or damp on walls/ceiling", "Check drainage around the compound",
  "Confirm the parking arrangement and fee", "Check mobile network signal inside the unit",
  "Visit again in the evening if possible",
];

function confColor(c) {
  return c === "High" ? forest : c === "Medium" ? ochre : "currentColor";
}
function sampleLabel(n) {
  if (!n) return "No reviews yet";
  if (n === 1) return "Based on 1 review";
  return `Based on ${n} reviews`;
}

// ---------- atoms ----------
function Section({ title, children, right }) {
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm flex items-center gap-2" style={{ color: muted, fontWeight: 600 }}>
          <span style={{ width: 4, height: 4, borderRadius: "50%", background: clay, display: "inline-block" }} />
          {title}
        </h3>
        {right}
      </div>
      {children}
    </div>
  );
}
function Chip({ active, onClick, children }) {
  return (
    <button type="button" onClick={onClick} className={`chip px-3 py-1.5 text-sm mr-2 mb-2 ${active ? "on" : ""}`}>
      {children}
    </button>
  );
}
function StarPick({ value, onChange }) {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((n) => (
        <button key={n} type="button" onClick={() => onChange(n)} aria-label={`${n} stars`}>
          <Star size={20} fill={value >= n ? clay : "none"} color={value >= n ? clay : line} strokeWidth={1.5} />
        </button>
      ))}
    </div>
  );
}
function Field({ label, children }) {
  return (
    <label className="block">
      <div className="text-xs mb-1" style={{ opacity: 0.6 }}>{label}</div>
      {children}
    </label>
  );
}

// ================= APP =================
export default function App() {
  const [view, setView] = useState("home");
  const [index, setIndex] = useState([]);
  const [loadingIndex, setLoadingIndex] = useState(true);
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState({ county: "", subcounty: "", type: "", bedrooms: "", minRent: "", maxRent: "", verifiedOnly: false, sort: "recent", custom: {} });
  const [customFilterDefs, setCustomFilterDefs] = useState([]);
  const [passport, setPassport] = useState(null); // { property, categoryScores, frequentlyReported, reviews, reviewCount, photos, rentHistory, amenities }
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState(null);
  const [error, setError] = useState(null);
  const [user, setUser] = useState(null);
  const [resetToken, setResetToken] = useState(null);
  const searchSeq = React.useRef(0);
  const searchDebounce = React.useRef(null);

  useEffect(() => {
    runSearch("", filters);
    api.filterDefinitions().then(setCustomFilterDefs).catch(() => {});

    // Links from verification/reset emails land here as ?token=... on a matching path
    const params = new URLSearchParams(window.location.search);
    if (params.get("token") && window.location.pathname.includes("verify-email")) {
      setView("verify-email");
      return;
    }
    if (params.get("token") && window.location.pathname.includes("reset-password")) {
      setResetToken(params.get("token"));
      setView("reset-password");
      return;
    }

    // Landed back here after a Google sign-in redirect
    if (params.get("google_auth")) {
      api.consumeGoogleAuthHandoff()
        .then((u) => { if (u) { setUser(u); flash(`Welcome, ${u.display_name || u.email}`); } })
        .catch((e) => setError(e.message));
      return;
    }

    if (api.getToken()) {
      api.me().then(setUser).catch(() => api.setToken(null));
    }
  }, []);

  async function runSearch(q, f = filters) {
    setLoadingIndex(true);
    setError(null);
    const mySeq = ++searchSeq.current;
    try {
      const params = { q };
      if (f.county) params.county = f.county;
      if (f.subcounty) params.subcounty = f.subcounty;
      if (f.type) params.type = f.type;
      if (f.bedrooms) params.bedrooms = f.bedrooms;
      if (f.minRent) params.minRent = f.minRent;
      if (f.maxRent) params.maxRent = f.maxRent;
      if (f.verifiedOnly) params.verifiedOnly = "true";
      if (f.sort && f.sort !== "recent") params.sort = f.sort;
      for (const [k, v] of Object.entries(f.custom || {})) {
        if (v) params[`custom_${k}`] = v;
      }
      const rows = await api.searchProperties(params);
      // Ignore this response if a newer search has already been kicked off —
      // otherwise a slow early keystroke can overwrite a faster later one.
      if (mySeq === searchSeq.current) setIndex(rows);
    } catch (e) {
      if (mySeq === searchSeq.current) setError(e.message);
    } finally {
      if (mySeq === searchSeq.current) setLoadingIndex(false);
    }
  }

  // Search-as-you-type, debounced so a fast typist doesn't fire a request
  // per keystroke — the box itself stays instantly responsive either way.
  function debouncedSearch(v, f = filters) {
    setSearch(v);
    clearTimeout(searchDebounce.current);
    searchDebounce.current = setTimeout(() => runSearch(v, f), 300);
  }

  function updateFilters(patch) {
    const next = { ...filters, ...patch };
    setFilters(next);
    runSearch(search, next);
  }

  async function openProperty(id) {
    setBusy(true);
    setError(null);
    try {
      const data = await api.getProperty(id);
      setPassport(data);
      setView("property");
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  function flash(msg) {
    setToast(msg);
    setTimeout(() => setToast(null), 2800);
  }

  useEffect(() => {
    if (view === "create" && !user) setView("home");
  }, [view, user]);

  return (
    <div className="rw">
      {FONTS}
      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 text-sm" style={{ background: ink, color: paper }}>
          {toast}
        </div>
      )}
      {error && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 text-sm" style={{ background: rust, color: paper }}>
          {error}
        </div>
      )}
      {view === "home" && (
        <Home
          index={index} loading={loadingIndex} search={search}
          filters={filters} onFiltersChange={updateFilters} customFilterDefs={customFilterDefs}
          setSearch={(v) => debouncedSearch(v, filters)}
          onOpen={openProperty}
          onCreate={() => {
            if (user) setView("create");
            else { flash("Create an account first — it only takes a minute."); setView("signup"); }
          }}
          user={user}
          onAccount={() => setView("account")}
          onSignIn={() => setView("login")}
          onAdmin={() => setView("admin")}
          onFooterNav={(page) => setView(page)}
        />
      )}
      {view === "create" && user && (
        <CreateProperty
          onBack={() => setView("home")}
          onDuplicateChosen={(id) => openProperty(id)}
          customFilterDefs={customFilterDefs}
          onCreated={async (p) => {
            await runSearch(search, filters);
            await openProperty(p.id);
            setView("review");
            flash("Property documented. Now add your experience.");
          }}
        />
      )}
      {view === "property" && passport && (
        <PropertyPage
          passport={passport} busy={busy} onBack={() => setView("home")} onReview={() => setView("review")}
          onPassportUpdate={setPassport}
        />
      )}
      {view === "review" && passport && (
        <ReviewForm
          property={passport.property}
          onBack={() => setView("property")}
          onSubmit={(review) => api.submitReview(passport.property.id, review)}
          onDone={async () => {
            try {
              const fresh = await api.getProperty(passport.property.id);
              setPassport(fresh);
              setView("property");
              flash("Thanks — your experience is now part of this property's record.");
            } catch (e) {
              setError(e.message);
            }
          }}
        />
      )}
      {view === "login" && (
        <Login
          onBack={() => setView("home")}
          onSuccess={(u) => { setUser(u); setView("home"); flash(`Welcome back, ${u.display_name || u.email}`); }}
          goSignup={() => setView("signup")}
          goForgot={() => setView("forgot")}
        />
      )}
      {view === "signup" && (
        <Signup
          onBack={() => setView("home")}
          onSuccess={(u) => { setUser(u); setView("home"); flash("Account created — check your email to verify it."); }}
          goLogin={() => setView("login")}
        />
      )}
      {view === "forgot" && <ForgotPassword onBack={() => setView("login")} />}
      {view === "reset-password" && resetToken && (
        <ResetPassword token={resetToken} onDone={() => { window.history.replaceState({}, "", "/"); setView("login"); }} />
      )}
      {view === "verify-email" && (
        <VerifyEmailLanding
          token={new URLSearchParams(window.location.search).get("token")}
          onDone={() => {
            window.history.replaceState({}, "", "/");
            setView("home");
            if (api.getToken()) api.me().then(setUser).catch(() => {});
          }}
        />
      )}
      {view === "account" && user && (
        <Account
          user={user}
          onBack={() => setView("home")}
          onLogout={() => { api.setToken(null); setUser(null); setView("home"); }}
          onUserUpdated={setUser}
          onAdmin={() => setView("admin")}
        />
      )}
      {view === "admin" && user?.role === "admin" && (
        <AdminDashboard onBack={() => setView("home")} />
      )}
      {view === "about" && <AboutPage onBack={() => setView("home")} />}
      {view === "terms" && <TermsPage onBack={() => setView("home")} />}
      {view === "privacy" && <PrivacyPage onBack={() => setView("home")} />}
      {view === "contact" && <ContactPage onBack={() => setView("home")} />}
      {view === "faqs" && <FaqsPage onBack={() => setView("home")} />}
    </div>
  );
}

// A larger, animated evolution of the logo's motif: a glowing archway with
// warm light escaping it, ringed by small icons for the actual categories
// RentWise scores (water, power, security, noise). Built entirely from CSS/SVG
// gradients — no stock photography — so it's fast, licence-free, and reads as
// distinctly "RentWise" rather than generic real-estate imagery.
function HeroScene() {
  const orbit = [
    { Icon: Droplet, top: "8%", left: "6%", delay: "0s" },
    { Icon: Zap, top: "16%", left: "82%", delay: "1.1s" },
    { Icon: Shield, top: "72%", left: "84%", delay: "2.2s" },
    { Icon: Volume2, top: "80%", left: "10%", delay: "0.6s" },
  ];
  return (
    <div className="hero-scene">
      <div className="hero-glow" />
      <svg viewBox="0 0 320 320" className="hero-arch">
        <defs>
          <linearGradient id="archGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={ink} />
            <stop offset="100%" stopColor="#2E3B2A" />
          </linearGradient>
          <radialGradient id="doorGlow" cx="65%" cy="50%" r="65%">
            <stop offset="0%" stopColor={glow} stopOpacity="0.95" />
            <stop offset="100%" stopColor={glow} stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect x="18" y="18" width="284" height="284" rx="36" fill={paperRaised} stroke={line} />
        <path d="M204 240 V120 A52 52 0 0 1 204 60 Z" fill="url(#doorGlow)" opacity="0.9" />
        <path d="M120 250 L180 250 L180 90 L120 40 Z" fill="url(#archGrad)" />
        <path d="M120 165 A44 44 0 0 0 120 125 L156 145 Z" fill={paperRaised} />
        <circle cx="150" cy="145" r="15" fill="url(#archGrad)" />
      </svg>
      {orbit.map(({ Icon, top, left, delay }, i) => (
        <span key={i} className="hero-orbit-icon" style={{ top, left, animationDelay: delay }}>
          <Icon size={15} />
        </span>
      ))}
    </div>
  );
}

// ---------- HOME ----------
function Home({ index, loading, search, setSearch, filters, onFiltersChange, onOpen, onCreate, user, onAccount, onSignIn, onAdmin, onFooterNav, customFilterDefs }) {
  const [showFilters, setShowFilters] = useState(false);
  const activeFilterCount = [
    filters.county, filters.subcounty, filters.type, filters.bedrooms, filters.minRent, filters.maxRent,
    filters.verifiedOnly ? "x" : "", ...Object.values(filters.custom || {}),
  ].filter(Boolean).length;

  return (
    <div>
    <div className="wrap-wide">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <img src="/logo-96.png" alt="" width={26} height={26} style={{ borderRadius: 7 }} />
          <span className="text-xs" style={{ opacity: 0.6 }}>Know before you sign</span>
        </div>
        <div className="flex items-center gap-2">
          {user?.role === "admin" && (
            <button onClick={onAdmin} className="flex items-center gap-1.5 text-xs px-2 py-1" style={{ border: `1px solid ${line}`, background: paperRaised }}>
              <LayoutDashboard size={12} /> Admin
            </button>
          )}
          {user ? (
            <button onClick={onAccount} className="flex items-center gap-1.5 text-xs px-2 py-1" style={{ border: `1px solid ${line}`, background: paperRaised }}>
              <UserIcon size={12} /> {user.display_name || user.email.split("@")[0]}
            </button>
          ) : (
            <button onClick={onSignIn} className="text-xs px-2 py-1" style={{ border: `1px solid ${line}`, background: paperRaised }}>
              Sign in
            </button>
          )}
        </div>
      </div>

      <div className="hero-grid mb-8">
        <div className="fade-in-up">
          <h1 className="display mb-2" style={{ fontWeight: 600, fontSize: "clamp(2rem, 5vw, 3.2rem)" }}>RentWise</h1>
          <p className="text-sm mb-1" style={{ opacity: 0.75, maxWidth: 480 }}>
            The rental record, built by the people who actually lived there — water reliability,
            security, noise, and why the last tenant left, before you sign anything.
          </p>
        </div>
        <div className="fade-in-up" style={{ animationDelay: "0.15s" }}>
          <HeroScene />
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-2 mb-3">
        <div className="flex items-center gap-2 px-3 py-2 flex-1" style={{ background: paperRaised, border: `1px solid ${line}` }}>
          <Search size={16} style={{ opacity: 0.5 }} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search estate, area, or property name…"
            className="bg-transparent outline-none text-sm flex-1"
            style={{ border: "none" }}
          />
        </div>
        <button
          onClick={() => setShowFilters((s) => !s)}
          className="flex items-center justify-center gap-2 px-4 py-2 text-sm shrink-0"
          style={{ border: `1px solid ${line}`, background: showFilters ? ink : paperRaised, color: showFilters ? paper : ink }}
        >
          <SlidersHorizontal size={15} /> Filters{activeFilterCount ? ` (${activeFilterCount})` : ""}
        </button>
        <button onClick={onCreate} className="btn-pop flex items-center justify-center gap-2 px-4 py-2 text-sm shrink-0" style={{ background: clay, color: paper, border: "none" }}>
          <Plus size={16} /> Document a place
        </button>
      </div>
      <p className="text-xs mb-4" style={{ opacity: 0.45 }}>
        Use the filters below for exact matches — natural-language search ("2 bedroom in Ruaka under 30k with reliable water") is on the roadmap.
      </p>

      {showFilters && (
        <div className="grid gap-3 mb-6 p-4" style={{ background: paperRaised, border: `1px solid ${line}`, gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))" }}>
          <Field label="County">
            <select className="input" value={filters.county} onChange={(e) => onFiltersChange({ county: e.target.value, subcounty: "" })}>
              <option value="">Any county</option>
              {COUNTY_NAMES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Subcounty">
            <select className="input" value={filters.subcounty} onChange={(e) => onFiltersChange({ subcounty: e.target.value })} disabled={!filters.county}>
              <option value="">{filters.county ? "Any subcounty" : "Pick a county first"}</option>
              {subcountiesFor(filters.county).map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="Property type">
            <select className="input" value={filters.type} onChange={(e) => onFiltersChange({ type: e.target.value })}>
              <option value="">Any type</option>
              {TYPES.filter((t) => t !== "Other").map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Bedrooms / unit size">
            <input className="input" placeholder="e.g. 2" value={filters.bedrooms} onChange={(e) => onFiltersChange({ bedrooms: e.target.value })} />
          </Field>
          <Field label="Min rent (KSh)">
            <input className="input" type="number" placeholder="No min" value={filters.minRent} onChange={(e) => onFiltersChange({ minRent: e.target.value })} />
          </Field>
          <Field label="Max rent (KSh)">
            <input className="input" type="number" placeholder="No max" value={filters.maxRent} onChange={(e) => onFiltersChange({ maxRent: e.target.value })} />
          </Field>
          <Field label="Sort by">
            <select className="input" value={filters.sort} onChange={(e) => onFiltersChange({ sort: e.target.value })}>
              <option value="recent">Recently documented</option>
              <option value="most_reviewed">Most reviewed</option>
              <option value="price_asc">Price: low to high</option>
              <option value="price_desc">Price: high to low</option>
            </select>
          </Field>
          {customFilterDefs.map((fd) => (
            <Field key={fd.id} label={fd.label}>
              {fd.type === "boolean" ? (
                <div className="flex items-end pb-2">
                  <label className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="checkbox" checked={!!filters.custom[fd.key]} onChange={(e) => onFiltersChange({ custom: { ...filters.custom, [fd.key]: e.target.checked ? "true" : "" } })} />
                    {fd.label}
                  </label>
                </div>
              ) : (
                <select className="input" value={filters.custom[fd.key] || ""} onChange={(e) => onFiltersChange({ custom: { ...filters.custom, [fd.key]: e.target.value } })}>
                  <option value="">Any</option>
                  {(fd.options || []).map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              )}
            </Field>
          ))}
          <div className="flex items-end pb-2">
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input type="checkbox" checked={filters.verifiedOnly} onChange={(e) => onFiltersChange({ verifiedOnly: e.target.checked })} />
              Verified residents only
            </label>
          </div>
        </div>
      )}

      <Section title={search || activeFilterCount ? `Results (${index.length})` : `Recently documented (${index.length})`} />
      {loading && (
        <div className="flex items-center gap-2 text-sm" style={{ opacity: 0.6 }}>
          <Loader2 size={14} className="animate-spin" /> Loading properties…
        </div>
      )}
      {!loading && index.length === 0 && (
        <div className="text-sm py-10 text-center" style={{ opacity: 0.6, border: `1px dashed ${line}` }}>
          No properties match yet.<br />Try widening your filters, or be the first to document one.
        </div>
      )}
      <div className="listing-grid">
        {index.map((p) => (
          <button key={p.id} onClick={() => onOpen(p.id)} className="prop-card">
            <div className="prop-card-media">
              {p.cover_photo_url ? (
                <img src={api.mediaUrl(p.cover_photo_url)} alt={p.name || "Property photo"} />
              ) : (
                <Roofline color={paperRaised} bg={ink} height="100%" />
              )}
              {Number(p.verified_review_count) > 0 && (
                <span className="pill pill-green absolute top-2 left-2">
                  <ShieldCheck size={11} /> Verified
                </span>
              )}
            </div>
            <div className="p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="font-medium text-sm">{p.name || "Unnamed property"}</div>
                  <div className="text-xs flex items-center gap-1 mt-0.5" style={{ opacity: 0.6 }}>
                    <MapPin size={11} /> {[p.estate, p.area, p.county].filter(Boolean).join(", ")}
                  </div>
                </div>
                <div className="text-xs text-right shrink-0" style={{ opacity: 0.6 }}>
                  {p.property_type}<br />{p.review_count} review{p.review_count === "1" ? "" : "s"}
                </div>
              </div>
              {(p.rent_min || p.rent_max) && (
                <div className="text-xs mt-2" style={{ color: clay }}>
                  KSh {Number(p.rent_min).toLocaleString()}{p.rent_max && p.rent_max !== p.rent_min ? `–${Number(p.rent_max).toLocaleString()}` : ""}/mo reported
                </div>
              )}
            </div>
          </button>
        ))}
      </div>
    </div>
    <Footer onNavigate={onFooterNav} />
    </div>
  );
}

// ---------- CREATE PROPERTY ----------
function CreateProperty({ onBack, onCreated, onDuplicateChosen, customFilterDefs = [] }) {
  const [form, setForm] = useState({
    name: "", county: "Nairobi", subcounty: "", area: "", estate: "", landmark: "", locationDesc: "",
    type: "1 Bedroom", bedrooms: "", rentMin: "", rentMax: "",
    lat: null, lng: null, precision: null,
  });
  const [amenities, setAmenities] = useState({});
  const [stage, setStage] = useState("form"); // form | checking | matches
  const [matches, setMatches] = useState([]);
  const [saving, setSaving] = useState(false);
  const [detecting, setDetecting] = useState(false);
  const [detectedNote, setDetectedNote] = useState(null);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  // Best-effort: once a pin is dropped, ask OpenStreetMap's Nominatim what
  // county/subcounty it's in and pre-fill those selects — never overwriting
  // a subcounty the person already chose themselves.
  async function detectFromPin(lat, lng) {
    if (form.subcounty) return; // respect an existing manual choice
    setDetecting(true);
    setDetectedNote(null);
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}&addressdetails=1&zoom=14`);
      const data = await res.json();
      const addr = data?.address || {};
      const candidates = [addr.county, addr.state, addr.city].filter(Boolean).map((s) => s.replace(/\s+County$/i, ""));
      const matchedCounty = COUNTY_NAMES.find((c) => candidates.some((cand) => cand.toLowerCase() === c.toLowerCase()));
      if (!matchedCounty) {
        setDetectedNote("Couldn't detect the area automatically — pick County and Subcounty below.");
        return;
      }
      const subOptions = subcountiesFor(matchedCounty);
      const subCandidates = [addr.suburb, addr.city_district, addr.town, addr.borough].filter(Boolean);
      const matchedSub = subOptions.find((s) => subCandidates.some((cand) => cand.toLowerCase().includes(s.toLowerCase()) || s.toLowerCase().includes(cand.toLowerCase())));
      setForm((f) => ({ ...f, county: matchedCounty, subcounty: matchedSub || f.subcounty }));
      setDetectedNote(matchedSub ? `Detected ${matchedSub}, ${matchedCounty} — confirm or adjust below.` : `Detected ${matchedCounty} — pick the subcounty below.`);
    } catch {
      setDetectedNote("Couldn't reach the location lookup — pick County and Subcounty below.");
    } finally {
      setDetecting(false);
    }
  }

  async function checkThenCreate() {
    if (!form.area && !form.estate && !form.landmark) return;
    setStage("checking");
    try {
      const area = await api.createArea({ level1: form.county, level2: form.subcounty, neighbourhood: form.area, estate: form.estate });
      const dups = await api.findDuplicates({ name: form.name, area_id: area.id, landmark: form.landmark });
      setMatches(dups.map((d) => ({ ...d, areaId: area.id })));
      setStage("matches");
      window.__pendingAreaId = area.id; // stashed for reallyCreate
    } catch (e) {
      setStage("form");
    }
  }

  async function reallyCreate() {
    setSaving(true);
    try {
      const p = await api.createProperty({
        name: form.name.trim() || null,
        area_id: window.__pendingAreaId,
        property_type: form.type,
        bedrooms: form.bedrooms || null,
        landmark: form.landmark.trim() || null,
        location_description: form.locationDesc.trim() || null,
        location_precision: form.lat ? form.precision : (form.landmark ? "landmark_only" : form.locationDesc ? "description_only" : "landmark_only"),
        lat: form.lat || null,
        lng: form.lng || null,
        rent_min: Number(form.rentMin) || null,
        rent_max: Number(form.rentMax) || null,
      });
      const amenityValues = Object.fromEntries(Object.entries(amenities).filter(([, v]) => v));
      if (Object.keys(amenityValues).length) {
        await api.setPropertyFilterValues(p.id, amenityValues).catch(() => {}); // best-effort — the property itself is already saved
      }
      onCreated(p);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="wrap-form">
      <button onClick={onBack} className="flex items-center gap-1 text-sm mb-4" style={{ opacity: 0.7, background: "none", border: "none" }}>
        <ChevronLeft size={16} /> Back
      </button>
      <h2 className="display text-2xl mb-1" style={{ fontWeight: 600 }}>Add a property</h2>
      <p className="text-sm mb-5" style={{ opacity: 0.7 }}>
        A house doesn't need a perfect address to exist here. Fill what you know — skip the rest.
      </p>

      {stage === "form" && (
        <div className="space-y-4">
          <Field label="Property / building name (if any)">
            <input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="e.g. XYZ Apartments" className="input" />
          </Field>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Field label="County">
              <select value={form.county} onChange={(e) => setForm((f) => ({ ...f, county: e.target.value, subcounty: "" }))} className="input">
                {COUNTY_NAMES.map((c) => <option key={c}>{c}</option>)}
              </select>
            </Field>
            <Field label="Subcounty">
              <select value={form.subcounty} onChange={(e) => set("subcounty", e.target.value)} className="input">
                <option value="">Select subcounty…</option>
                {subcountiesFor(form.county).map((s) => <option key={s}>{s}</option>)}
              </select>
            </Field>
          </div>
          <Field label="Area / neighbourhood">
            <input value={form.area} onChange={(e) => set("area", e.target.value)} placeholder="e.g. Zimmerman" className="input" />
          </Field>
          <Field label="Estate / village">
            <input value={form.estate} onChange={(e) => set("estate", e.target.value)} placeholder="e.g. Mwiki" className="input" />
          </Field>
          <Field label="Nearby landmark (optional)">
            <input value={form.landmark} onChange={(e) => set("landmark", e.target.value)} placeholder="e.g. 300m behind XYZ Primary School" className="input" />
          </Field>
          <Field label="Describe how to find it (optional)">
            <textarea value={form.locationDesc} onChange={(e) => set("locationDesc", e.target.value)}
              placeholder="From the main road, enter through the second dirt road after the petrol station…" className="input" rows={3} />
          </Field>
          <Field label="Pin the location (optional)">
            <LocationPicker
              lat={form.lat} lng={form.lng} precision={form.precision}
              onChange={(lat, lng, precision) => {
                setForm((f) => ({ ...f, lat, lng, precision }));
                detectFromPin(lat, lng);
              }}
            />
            {detecting && <p className="text-xs mt-1.5 flex items-center gap-1.5" style={{ opacity: 0.6 }}><Loader2 size={11} className="animate-spin" /> Detecting county and subcounty from the pin…</p>}
            {detectedNote && !detecting && <p className="text-xs mt-1.5" style={{ color: detectedNote.startsWith("Couldn't") ? rust : forest }}>{detectedNote}</p>}
          </Field>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Field label="Type">
              <SelectableOther options={TYPES} value={form.type} onChange={(v) => set("type", v)} multi={false} />
            </Field>
            <Field label="Floor / unit (optional)">
              <input value={form.bedrooms} onChange={(e) => set("bedrooms", e.target.value)} placeholder="e.g. 3rd floor" className="input" />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Rent from (KSh)">
              <input value={form.rentMin} onChange={(e) => set("rentMin", e.target.value)} inputMode="numeric" className="input" />
            </Field>
            <Field label="Rent to (KSh, optional)">
              <input value={form.rentMax} onChange={(e) => set("rentMax", e.target.value)} inputMode="numeric" className="input" />
            </Field>
          </div>
          <p className="text-xs" style={{ opacity: 0.55 }}>
            This will be visible to everyone using the app. Don't include your name, phone number, or exact door number.
          </p>
          {customFilterDefs.length > 0 && (
            <Field label="Amenities (optional)">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {customFilterDefs.map((fd) => (
                  <div key={fd.id}>
                    {fd.type === "boolean" ? (
                      <label className="flex items-center gap-2 text-sm cursor-pointer p-2" style={{ background: paperRaised, border: `1px solid ${line}` }}>
                        <input type="checkbox" checked={!!amenities[fd.key]} onChange={(e) => setAmenities((a) => ({ ...a, [fd.key]: e.target.checked ? "true" : "" }))} />
                        {fd.label}
                      </label>
                    ) : (
                      <select className="input" value={amenities[fd.key] || ""} onChange={(e) => setAmenities((a) => ({ ...a, [fd.key]: e.target.value }))}>
                        <option value="">{fd.label}…</option>
                        {(fd.options || []).map((o) => <option key={o} value={o}>{o}</option>)}
                      </select>
                    )}
                  </div>
                ))}
              </div>
            </Field>
          )}
          <button onClick={checkThenCreate} disabled={!form.area && !form.estate && !form.landmark}
            className="btn-pop w-full py-3 text-sm" style={{ background: ink, color: paper, border: "none", opacity: (!form.area && !form.estate && !form.landmark) ? 0.4 : 1 }}>
            Continue
          </button>
        </div>
      )}

      {stage === "checking" && (
        <div className="flex items-center gap-2 text-sm py-8 justify-center" style={{ opacity: 0.6 }}>
          <Loader2 size={16} className="animate-spin" /> Checking for existing records…
        </div>
      )}

      {stage === "matches" && (
        <div>
          {matches.length > 0 ? (
            <>
              <div className="flex items-center gap-2 mb-3 text-sm" style={{ color: ochre }}>
                <AlertTriangle size={16} /> Possible existing match found
              </div>
              <div className="space-y-2 mb-5">
                {matches.map((m) => (
                  <button key={m.id} onClick={() => onDuplicateChosen(m.id)} className="w-full text-left p-3 text-sm" style={{ background: paperRaised, border: `1px solid ${line}` }}>
                    <div className="font-medium">{m.name || "Unnamed property"}</div>
                    <div className="text-xs" style={{ opacity: 0.6 }}>{m.landmark}</div>
                  </button>
                ))}
              </div>
              <p className="text-xs mb-3" style={{ opacity: 0.6 }}>None of these? Create a new record below.</p>
            </>
          ) : (
            <p className="text-sm mb-4" style={{ opacity: 0.7 }}>No existing match found — this will be a new record.</p>
          )}
          <div className="flex gap-3">
            <button onClick={() => setStage("form")} className="flex-1 py-3 text-sm" style={{ border: `1px solid ${line}`, background: "none" }}>
              Edit details
            </button>
            <button onClick={reallyCreate} disabled={saving} className="btn-pop flex-1 py-3 text-sm" style={{ background: clay, color: paper, border: "none" }}>
              {saving ? "Saving…" : "Create new record"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ---------- PROPERTY PAGE ----------
function PropertyPage({ passport, onBack, onReview, busy, onPassportUpdate }) {
  const { property, categoryScores, frequentlyReported, reviews, reviewCount, rentHistory = [], photos: initialPhotos = [], amenities = [] } = passport;
  const [checked, setChecked] = useState({});
  const [photos, setPhotos] = useState(initialPhotos);

  function updatePhotos(updater) {
    setPhotos((cur) => {
      const next = typeof updater === "function" ? updater(cur) : updater;
      onPassportUpdate?.((p) => ({ ...p, photos: next }));
      return next;
    });
  }

  const verifiedCount = reviews.filter((r) => r.verification_level === "verified_resident").length;

  return (
    <div className="wrap-mid">
      <button onClick={onBack} className="flex items-center gap-1 text-sm mb-4" style={{ opacity: 0.7, background: "none", border: "none" }}>
        <ChevronLeft size={16} /> Back
      </button>

      {/* ---- Identity ---- */}
      <div className="text-xs flex items-center gap-1 mb-1" style={{ opacity: 0.6 }}>
        <MapPin size={11} /> {[property.county, property.area, property.estate].filter(Boolean).join(" · ")}
      </div>
      <h2 className="display text-2xl sm:text-3xl mb-1" style={{ fontWeight: 600 }}>{property.name || "Unnamed property"}</h2>
      <div className="text-sm mb-1" style={{ opacity: 0.7 }}>
        {property.property_type}{property.bedrooms ? ` · ${property.bedrooms}` : ""}
      </div>
      {(property.rent_min || property.rent_max) && (
        <div className="text-sm mb-4" style={{ color: clay }}>
          KSh {Number(property.rent_min).toLocaleString()}{property.rent_max && property.rent_max !== property.rent_min ? `–${Number(property.rent_max).toLocaleString()}` : ""}/mo reported
        </div>
      )}
      <div className="flex flex-wrap items-center gap-3 text-xs mb-6" style={{ opacity: 0.7 }}>
        <span>{reviewCount} resident experience{reviewCount === 1 ? "" : "s"} documented</span>
        {verifiedCount > 0 && (
          <span className="flex items-center gap-1" style={{ color: forest }}><ShieldCheck size={12} /> {verifiedCount} verified</span>
        )}
      </div>

      <div className="passport-grid">
        <div className="passport-col">
          <Section title={`Photos (${photos.length})`}>
            {photos.length > 0 ? (
              <div className="grid grid-cols-3 gap-2 mb-3">
                {photos.slice(0, 6).map((p) => (
                  <div key={p.id} className="aspect-square overflow-hidden" style={{ border: p.is_cover ? `2px solid ${clay}` : `1px solid ${line}` }}>
                    <img src={api.mediaUrl(p.url)} alt={p.caption || `${p.area} photo`} className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex items-center gap-2 text-sm py-6 justify-center mb-3" style={{ opacity: 0.5, border: `1px dashed ${line}` }}>
                <ImageOff size={15} /> No photos yet
              </div>
            )}
            <details>
              <summary className="text-xs cursor-pointer" style={{ opacity: 0.65 }}>Add photos of this property</summary>
              <div className="pt-3">
                <PropertyPhotoUploader propertyId={property.id} photos={photos} onChange={updatePhotos} />
              </div>
            </details>
          </Section>

          {amenities.length > 0 && (
            <Section title="Amenities">
              <div className="flex flex-wrap gap-2">
                {amenities.map((a) => (
                  <span key={a.key} className="pill pill-blue">
                    {a.type === "boolean" ? a.label : `${a.label}: ${a.value}`}
                  </span>
                ))}
              </div>
            </Section>
          )}

          {(property.landmark || property.location_description) && (
            <Section title="Location">
              <div className="p-3 text-sm mb-2" style={{ background: paperRaised, border: `1px solid ${line}` }}>
                {property.landmark && <div className="mb-1"><strong>Landmark:</strong> {property.landmark}</div>}
                {property.location_description && <div style={{ opacity: 0.8 }}>{property.location_description}</div>}
                {!property.lat && <div className="text-xs mt-2" style={{ opacity: 0.5 }}>📍 Approximate location — no exact address published</div>}
              </div>
              {property.lat && property.lng && (
                <>
                  <PropertyMap lat={Number(property.lat)} lng={Number(property.lng)} precision={property.location_precision} />
                  <div className="text-xs mt-1" style={{ opacity: 0.5 }}>
                    {property.location_precision === "exact_gps" ? "Exact GPS point" : "Approximate area — shaded radius, not an exact address"}
                  </div>
                </>
              )}
            </Section>
          )}

          <Section title="Resident experience — scores">
            <div className="space-y-3">
              {CATEGORIES.map((c) => {
                const s = categoryScores[c.key];
                return (
                  <div key={c.key}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="flex items-center gap-2"><CatIcon c={c} />{c.label}</span>
                      <span style={{ fontWeight: 500 }}>{s.average ? s.average.toFixed(1) : "—"}/5</span>
                    </div>
                    <div className="barwrap w-full mb-1"><div className="barfill" style={{ width: s.average ? `${(s.average / 5) * 100}%` : "0%" }} /></div>
                    <div className="text-xs flex items-center gap-1.5" style={{ opacity: 0.5 }}>
                      <span className="inline-block rounded-full" style={{ width: 6, height: 6, background: confColor(s.confidence) }} />
                      {sampleLabel(s.sampleSize)}
                    </div>
                  </div>
                );
              })}
            </div>
          </Section>

          {frequentlyReported.length > 0 && (
            <Section title="Problems most often reported">
              <div className="space-y-2">
                {frequentlyReported.map((i) => (
                  <div key={i.reason} className="flex items-center justify-between text-sm p-2.5" style={{ background: "#F3E9E4", border: "1px solid #E4C8B8" }}>
                    <span className="flex items-center gap-2"><AlertTriangle size={13} color={rust} /> {i.reason}</span>
                    <span style={{ opacity: 0.7 }}>{i.count} report{i.count === 1 ? "" : "s"} · {i.pct}%</span>
                  </div>
                ))}
              </div>
            </Section>
          )}

          {rentHistory.length > 0 && (
            <Section title="Rent history — reported over time">
              <div className="space-y-1.5">
                {rentHistory.map((r, i) => (
                  <div key={i} className="flex items-center justify-between text-sm py-1.5" style={{ borderBottom: i < rentHistory.length - 1 ? `1px solid ${line}` : "none" }}>
                    <span style={{ opacity: 0.6 }}>{new Date(r.observed_at).toLocaleDateString(undefined, { year: "numeric", month: "short" })}</span>
                    <span style={{ color: clay, fontWeight: 500 }}>{r.currency} {Number(r.amount).toLocaleString()}/mo</span>
                  </div>
                ))}
              </div>
            </Section>
          )}

          <Section title="Before you rent — inspection checklist">
            <div className="space-y-1.5">
              {CHECKLIST.map((c, i) => (
                <label key={i} className="flex items-start gap-2 text-sm cursor-pointer">
                  <input type="checkbox" checked={!!checked[i]} onChange={() => setChecked((s) => ({ ...s, [i]: !s[i] }))} className="mt-0.5" />
                  <span style={{ opacity: checked[i] ? 0.5 : 0.85, textDecoration: checked[i] ? "line-through" : "none" }}>{c}</span>
                </label>
              ))}
            </div>
          </Section>
        </div>

        <div className="passport-col">
          <Section title={`Resident experiences (${reviews.length})`} />
          {reviews.length === 0 && (
            <div className="text-sm py-6 text-center mb-4" style={{ opacity: 0.6, border: `1px dashed ${line}` }}>
              No experiences documented yet.
            </div>
          )}
          <div className="space-y-3 mb-6">
            {reviews.map((r) => (
              <div key={r.id} className="p-3.5" style={{ background: paperRaised, border: `1px solid ${line}` }}>
                <div className="flex items-center justify-between mb-2">
                  <span className={`pill ${r.verification_level === "verified_resident" ? "pill-green" : "pill-amber"}`}>
                    {r.verification_level === "verified_resident" ? <ShieldCheck size={12} /> : <User size={12} />}
                    {r.verification_level === "verified_resident" ? "Verified former resident" : "Community contributor"}
                  </span>
                  <span className="text-xs" style={{ color: muted }}>{r.duration_lived}</span>
                </div>
                {r.why_left?.length > 0 && (
                  <div className="text-xs mb-2" style={{ opacity: 0.7 }}>Left because: {r.why_left.join(", ")}</div>
                )}
                {r.best_thing && <p className="text-sm mb-1"><strong>Best thing:</strong> {r.best_thing}</p>}
                {r.wish_knew && <p className="text-sm mb-1"><strong>Wish I'd known:</strong> {r.wish_knew}</p>}
                {r.would_rent_again && <div className="text-xs mt-2" style={{ color: clay }}>Would rent again: {r.would_rent_again}</div>}
              </div>
            ))}
          </div>

          <button onClick={onReview} disabled={busy} className="btn-pop w-full flex items-center justify-center gap-2 py-3 text-sm sticky" style={{ background: clay, color: paper, border: "none", top: "1rem" }}>
            <ClipboardList size={16} /> I've lived here — add my experience
          </button>
        </div>
      </div>
    </div>
  );
}

// ---------- REVIEW FORM ----------
function ReviewForm({ property, onBack, onSubmit, onDone }) {
  const [stage, setStage] = useState("form"); // form | proof
  const [duration, setDuration] = useState(DURATIONS[2]);
  const [stillHere, setStillHere] = useState(false);
  const [whyLeft, setWhyLeft] = useState([]);
  const [ratings, setRatings] = useState({});
  const [bestThing, setBestThing] = useState("");
  const [wishKnew, setWishKnew] = useState("");
  const [wouldRentAgain, setWouldRentAgain] = useState(RECOMMEND[0]);
  const [verified, setVerified] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [createdReview, setCreatedReview] = useState(null);

  async function submit() {
    setSubmitting(true);
    try {
      const review = await onSubmit({
        duration_lived: duration,
        still_living_here: stillHere,
        why_left: stillHere ? [] : whyLeft,
        ratings,
        best_thing: bestThing.trim(),
        wish_knew: wishKnew.trim(),
        would_rent_again: wouldRentAgain,
        verification_level: verified ? "verified_resident" : "community",
      });
      if (verified) {
        setCreatedReview(review);
        setStage("proof");
      } else {
        onDone();
      }
    } finally {
      setSubmitting(false);
    }
  }

  if (stage === "proof" && createdReview) {
    return (
      <div className="wrap-form">
        <h2 className="display text-2xl mb-1" style={{ fontWeight: 600 }}>Back up your verification (optional)</h2>
        <p className="text-sm mb-5" style={{ opacity: 0.7 }}>
          Your review is already saved. Adding proof helps an admin confirm the "verified" badge — it's
          never shown to anyone but RentWise's moderation team.
        </p>
        <EvidenceUploader propertyId={property.id} reviewId={createdReview.id} />
        <button onClick={onDone} className="w-full py-3 text-sm mt-4" style={{ border: `1px solid ${line}`, background: "none" }}>
          Skip for now — I'm done
        </button>
      </div>
    );
  }

  return (
    <div className="wrap-form">
      <button onClick={onBack} className="flex items-center gap-1 text-sm mb-4" style={{ opacity: 0.7, background: "none", border: "none" }}>
        <ChevronLeft size={16} /> Back
      </button>
      <h2 className="display text-2xl mb-1" style={{ fontWeight: 600 }}>Your experience</h2>
      <p className="text-sm mb-5" style={{ opacity: 0.7 }}>{property.name || "This property"} · takes about a minute</p>

      <Section title="How long did you live here?">
        <div className="flex flex-wrap">{DURATIONS.map((d) => <Chip key={d} active={duration === d} onClick={() => setDuration(d)}>{d}</Chip>)}</div>
      </Section>

      <Section title="Are you still living here?">
        <div className="flex flex-wrap">
          <Chip active={!stillHere} onClick={() => setStillHere(false)}>No, I've moved out</Chip>
          <Chip active={stillHere} onClick={() => setStillHere(true)}>Yes, still here</Chip>
        </div>
      </Section>

      {!stillHere && (
        <Section title="Why did you leave? (select all that apply)">
          <SelectableOther options={WHY_LEFT} value={whyLeft} onChange={setWhyLeft} multi={true} />
        </Section>
      )}

      <Section title="Rate your experience">
        <div className="space-y-3">
          {CATEGORIES.map((c) => (
            <div key={c.key} className="flex items-center justify-between">
              <span className="text-sm flex items-center gap-2"><CatIcon c={c} />{c.label}</span>
              <StarPick value={ratings[c.key] || 0} onChange={(v) => setRatings((r) => ({ ...r, [c.key]: v }))} />
            </div>
          ))}
        </div>
      </Section>

      <Section title="What was the best thing about living here?">
        <textarea value={bestThing} onChange={(e) => setBestThing(e.target.value)} rows={2} className="input" placeholder="Optional" />
      </Section>
      <Section title="What should future tenants know?">
        <textarea value={wishKnew} onChange={(e) => setWishKnew(e.target.value)} rows={2} className="input" placeholder="e.g. The area floods during heavy rain" />
      </Section>
      <Section title="Would you rent here again?">
        <div className="flex flex-wrap">{RECOMMEND.map((r) => <Chip key={r} active={wouldRentAgain === r} onClick={() => setWouldRentAgain(r)}>{r}</Chip>)}</div>
      </Section>

      <label className="flex items-start gap-2 text-sm mb-2 cursor-pointer">
        <input type="checkbox" checked={verified} onChange={(e) => setVerified(e.target.checked)} className="mt-0.5" />
        <span style={{ opacity: 0.8 }}>
          I have proof I lived here (tenancy agreement, receipts, utility bill, photos). This marks my review as <strong>verified</strong> — any proof you add is only ever seen by an admin, never the public.
        </span>
      </label>
      <p className="text-xs mb-4" style={{ opacity: 0.55 }}>
        Your review is posted anonymously as "{verified ? "Verified former resident" : "Community contributor"}" — your name is never shown.
      </p>

      <button onClick={submit} disabled={submitting} className="btn-pop w-full flex items-center justify-center gap-2 py-3 text-sm" style={{ background: ink, color: paper, border: "none", opacity: submitting ? 0.6 : 1 }}>
        {submitting ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />}
        {submitting ? "Saving…" : "Submit experience"}
      </button>
    </div>
  );
}
