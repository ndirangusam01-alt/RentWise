// Kenya's 47 counties, each broken into its constituent sub-counties.
// Sub-county boundaries in Kenya track National Assembly constituencies in
// almost all counties, which is the convention used here — it's the most
// widely-referenced civic breakdown and what most Kenyan users expect to see.
// This is reference/filter data, not something properties are validated
// against — a property's actual area/estate stays free text so nothing here
// blocks documenting a real place that doesn't fit neatly into a list.
export const KENYA_COUNTIES = [
  { county: "Nairobi", subcounties: ["Westlands", "Dagoretti North", "Dagoretti South", "Langata", "Kibra", "Roysambu", "Kasarani", "Ruaraka", "Embakasi South", "Embakasi North", "Embakasi Central", "Embakasi East", "Embakasi West", "Makadara", "Kamukunji", "Starehe", "Mathare"] },
  { county: "Mombasa", subcounties: ["Changamwe", "Jomvu", "Kisauni", "Nyali", "Likoni", "Mvita"] },
  { county: "Kwale", subcounties: ["Msambweni", "Lunga Lunga", "Matuga", "Kinango"] },
  { county: "Kilifi", subcounties: ["Kilifi North", "Kilifi South", "Kaloleni", "Rabai", "Ganze", "Malindi", "Magarini"] },
  { county: "Tana River", subcounties: ["Garsen", "Galole", "Bura"] },
  { county: "Lamu", subcounties: ["Lamu East", "Lamu West"] },
  { county: "Taita Taveta", subcounties: ["Taveta", "Wundanyi", "Mwatate", "Voi"] },
  { county: "Garissa", subcounties: ["Garissa Township", "Balambala", "Lagdera", "Dadaab", "Fafi", "Ijara"] },
  { county: "Wajir", subcounties: ["Wajir North", "Wajir East", "Tarbaj", "Wajir West", "Eldas", "Wajir South"] },
  { county: "Mandera", subcounties: ["Mandera West", "Banissa", "Mandera North", "Mandera South", "Mandera East", "Lafey"] },
  { county: "Marsabit", subcounties: ["Moyale", "North Horr", "Saku", "Laisamis"] },
  { county: "Isiolo", subcounties: ["Isiolo North", "Isiolo South"] },
  { county: "Meru", subcounties: ["Igembe South", "Igembe Central", "Igembe North", "Tigania West", "Tigania East", "North Imenti", "Buuri", "Central Imenti", "South Imenti"] },
  { county: "Tharaka Nithi", subcounties: ["Maara", "Chuka/Igambang'ombe", "Tharaka"] },
  { county: "Embu", subcounties: ["Manyatta", "Runyenjes", "Mbeere South", "Mbeere North"] },
  { county: "Kitui", subcounties: ["Mwingi North", "Mwingi West", "Mwingi Central", "Kitui West", "Kitui Rural", "Kitui Central", "Kitui East", "Kitui South"] },
  { county: "Machakos", subcounties: ["Masinga", "Yatta", "Kangundo", "Matungulu", "Kathiani", "Mavoko", "Machakos Town", "Mwala"] },
  { county: "Makueni", subcounties: ["Mbooni", "Kilome", "Kaiti", "Kibwezi West", "Kibwezi East", "Makueni", "Kilungu"] },
  { county: "Nyandarua", subcounties: ["Kinangop", "Kipipiri", "Ol Kalou", "Ol Jorok", "Ndaragwa"] },
  { county: "Nyeri", subcounties: ["Tetu", "Kieni", "Mathira", "Othaya", "Mukurweini", "Nyeri Town"] },
  { county: "Kirinyaga", subcounties: ["Mwea", "Gichugu", "Ndia", "Kirinyaga Central"] },
  { county: "Murang'a", subcounties: ["Kangema", "Mathioya", "Kiharu", "Kigumo", "Maragwa", "Kandara", "Gatanga"] },
  { county: "Kiambu", subcounties: ["Gatundu South", "Gatundu North", "Juja", "Thika Town", "Ruiru", "Githunguri", "Kiambu", "Kiambaa", "Kabete", "Kikuyu", "Limuru", "Lari"] },
  { county: "Turkana", subcounties: ["Turkana North", "Turkana West", "Turkana Central", "Loima", "Turkana South", "Turkana East"] },
  { county: "West Pokot", subcounties: ["Kapenguria", "Sigor", "Kacheliba", "Pokot South"] },
  { county: "Samburu", subcounties: ["Samburu West", "Samburu North", "Samburu East"] },
  { county: "Trans Nzoia", subcounties: ["Kwanza", "Endebess", "Saboti", "Kiminini", "Cherangany"] },
  { county: "Uasin Gishu", subcounties: ["Soy", "Turbo", "Moiben", "Ainabkoi", "Kapseret", "Kesses"] },
  { county: "Elgeyo Marakwet", subcounties: ["Marakwet East", "Marakwet West", "Keiyo North", "Keiyo South"] },
  { county: "Nandi", subcounties: ["Tinderet", "Aldai", "Nandi Hills", "Chesumei", "Emgwen", "Mosop"] },
  { county: "Baringo", subcounties: ["Tiaty", "Baringo North", "Baringo Central", "Baringo South", "Mogotio", "Eldama Ravine"] },
  { county: "Laikipia", subcounties: ["Laikipia West", "Laikipia East", "Laikipia North"] },
  { county: "Nakuru", subcounties: ["Molo", "Njoro", "Naivasha", "Gilgil", "Kuresoi South", "Kuresoi North", "Subukia", "Rongai", "Bahati", "Nakuru Town West", "Nakuru Town East"] },
  { county: "Narok", subcounties: ["Kilgoris", "Emurua Dikirr", "Narok North", "Narok East", "Narok South", "Narok West"] },
  { county: "Kajiado", subcounties: ["Kajiado North", "Kajiado Central", "Kajiado East", "Kajiado West", "Kajiado South"] },
  { county: "Kericho", subcounties: ["Kipkelion East", "Kipkelion West", "Ainamoi", "Bureti", "Belgut", "Sigowet/Soin"] },
  { county: "Bomet", subcounties: ["Sotik", "Chepalungu", "Bomet East", "Bomet Central", "Konoin"] },
  { county: "Kakamega", subcounties: ["Lugari", "Likuyani", "Malava", "Lurambi", "Navakholo", "Mumias West", "Mumias East", "Matungu", "Butere", "Khwisero", "Shinyalu", "Ikolomani"] },
  { county: "Vihiga", subcounties: ["Vihiga", "Sabatia", "Hamisi", "Luanda", "Emuhaya"] },
  { county: "Bungoma", subcounties: ["Mt. Elgon", "Sirisia", "Kabuchai", "Bumula", "Kanduyi", "Webuye East", "Webuye West", "Kimilili", "Tongaren"] },
  { county: "Busia", subcounties: ["Teso North", "Teso South", "Nambale", "Matayos", "Butula", "Funyula", "Budalangi"] },
  { county: "Siaya", subcounties: ["Ugenya", "Ugunja", "Alego Usonga", "Gem", "Bondo", "Rarieda"] },
  { county: "Kisumu", subcounties: ["Kisumu East", "Kisumu West", "Kisumu Central", "Seme", "Nyando", "Muhoroni", "Nyakach"] },
  { county: "Homa Bay", subcounties: ["Kasipul", "Kabondo Kasipul", "Karachuonyo", "Rangwe", "Homa Bay Town", "Ndhiwa", "Suba North", "Suba South"] },
  { county: "Migori", subcounties: ["Rongo", "Awendo", "Suna East", "Suna West", "Uriri", "Nyatike", "Kuria West", "Kuria East"] },
  { county: "Kisii", subcounties: ["Bonchari", "South Mugirango", "Bomachoge Borabu", "Bobasi", "Bomachoge Chache", "Nyaribari Masaba", "Nyaribari Chache", "Kitutu Chache North", "Kitutu Chache South"] },
  { county: "Nyamira", subcounties: ["Kitutu Masaba", "West Mugirango", "North Mugirango", "Borabu"] },
];

export const COUNTY_NAMES = KENYA_COUNTIES.map((c) => c.county);

export function subcountiesFor(county) {
  return KENYA_COUNTIES.find((c) => c.county === county)?.subcounties || [];
}
