import React from "react";
import { MapContainer, TileLayer, Marker, Circle } from "react-leaflet";
import L from "leaflet";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({ iconRetinaUrl: markerIcon2x, iconUrl: markerIcon, shadowUrl: markerShadow });

export default function PropertyMap({ lat, lng, precision }) {
  if (!lat || !lng) return null;
  const isExact = precision === "exact_gps";
  return (
    <div style={{ height: 180, border: "1px solid #D8CFBD" }}>
      <MapContainer center={[lat, lng]} zoom={isExact ? 16 : 14} style={{ height: "100%", width: "100%" }} scrollWheelZoom={false}>
        <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {isExact ? <Marker position={[lat, lng]} /> : <Circle center={[lat, lng]} radius={250} pathOptions={{ color: "#A8451F", fillOpacity: 0.15 }} />}
      </MapContainer>
    </div>
  );
}
