import React, { useState, useRef } from "react";
import { Camera, Loader2, X, MapPin, Clock, FileText, Lock } from "lucide-react";
import { api } from "../api.js";

const line = "#D8CFBD";
const paperRaised = "#FBF8F0";
const ink = "#20261F";
const paper = "#F6F2E9";

const TYPES = [
  { key: "photo", label: "Photo", icon: Camera },
  { key: "video", label: "Video", icon: Camera },
  { key: "document", label: "Document", icon: FileText },
  { key: "location", label: "Location", icon: MapPin },
  { key: "date_time", label: "Date/time", icon: Clock },
];

const ACCEPT = {
  photo: "image/jpeg,image/png,image/webp",
  video: "video/mp4,video/quicktime,video/webm",
  document: "application/pdf",
};

// PRIVATE verification proof attached to a review (never shown publicly — only
// an admin can view this, to verify a reviewer's claim). Supports files
// (photo/video/document) as well as file-less claims (a location pin, a
// date/time).
export default function EvidenceUploader({ propertyId, reviewId, onUploaded }) {
  const [docType, setDocType] = useState("photo");
  const [file, setFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [caption, setCaption] = useState("");
  const [lat, setLat] = useState("");
  const [lng, setLng] = useState("");
  const [eventAt, setEventAt] = useState("");
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState(null);
  const [saved, setSaved] = useState([]);
  const inputRef = useRef(null);

  function pickFile(e) {
    const f = e.target.files?.[0];
    if (!f) return;
    setError(null);
    setFile(f);
    setPreviewUrl(URL.createObjectURL(f));
  }

  function useMyLocation() {
    if (!navigator.geolocation) return setError("Location isn't available in this browser");
    navigator.geolocation.getCurrentPosition(
      (pos) => { setLat(String(pos.coords.latitude)); setLng(String(pos.coords.longitude)); },
      () => setError("Couldn't read your location — enter it manually or try again")
    );
  }

  function reset() {
    setFile(null); setPreviewUrl(null); setCaption(""); setLat(""); setLng(""); setEventAt("");
    if (inputRef.current) inputRef.current.value = "";
  }

  async function upload() {
    setError(null);
    if (["photo", "video", "document"].includes(docType) && !file) return setError("Choose a file first");
    if (docType === "location" && (!lat || !lng)) return setError("Add a location first");
    if (docType === "date_time" && !eventAt) return setError("Pick a date and time first");

    setUploading(true);
    try {
      const result = await api.uploadEvidence(propertyId, file, {
        caption, reviewId, documentType: docType,
        submittedLat: lat || undefined, submittedLng: lng || undefined,
        eventAt: eventAt ? new Date(eventAt).toISOString() : undefined,
      });
      setSaved((s) => [...s, result]);
      onUploaded?.(result);
      reset();
    } catch (e) {
      setError(e.message);
    } finally {
      setUploading(false);
    }
  }

  return (
    <div>
      <div className="flex items-start gap-2 mb-3 p-2.5 text-xs" style={{ background: "#EFE9DC", border: `1px solid ${line}`, opacity: 0.85 }}>
        <Lock size={13} className="mt-0.5 shrink-0" />
        <span>Private — only RentWise admins can see this, to verify your claim. It is never shown publicly, not even on your own review.</span>
      </div>

      <div className="flex flex-wrap gap-1.5 mb-3">
        {TYPES.map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => { setDocType(t.key); reset(); }}
            className="chip flex items-center gap-1.5 text-xs px-2.5 py-1.5"
            style={docType === t.key ? { background: ink, color: paper, borderColor: ink } : {}}
          >
            <t.icon size={12} /> {t.label}
          </button>
        ))}
      </div>

      {["photo", "video", "document"].includes(docType) && (
        file ? (
          <div className="flex items-start gap-3 mb-2 p-2.5" style={{ background: paperRaised, border: `1px solid ${line}` }}>
            {docType === "video" ? (
              <video src={previewUrl} className="w-16 h-16 object-cover shrink-0" muted />
            ) : docType === "document" ? (
              <div className="w-16 h-16 flex items-center justify-center shrink-0" style={{ background: paper, border: `1px solid ${line}` }}><FileText size={20} /></div>
            ) : (
              <img src={previewUrl} className="w-16 h-16 object-cover shrink-0" alt="preview" />
            )}
            <div className="flex-1 text-xs truncate" style={{ opacity: 0.7 }}>{file.name}</div>
            <button type="button" onClick={reset} aria-label="Cancel" style={{ background: "none", border: "none" }}><X size={15} /></button>
          </div>
        ) : (
          <label className="flex items-center justify-center gap-2 py-3 text-sm cursor-pointer mb-2" style={{ border: `1px dashed ${line}`, color: ink, opacity: 0.75 }}>
            <Camera size={16} /> Choose a {docType}
            <input ref={inputRef} type="file" accept={ACCEPT[docType]} onChange={pickFile} className="hidden" />
          </label>
        )
      )}

      {docType === "location" && (
        <div className="flex items-center gap-2 mb-2">
          <input value={lat} onChange={(e) => setLat(e.target.value)} placeholder="Latitude" className="input" style={{ width: "auto", flex: 1 }} />
          <input value={lng} onChange={(e) => setLng(e.target.value)} placeholder="Longitude" className="input" style={{ width: "auto", flex: 1 }} />
          <button type="button" onClick={useMyLocation} className="text-xs px-2 py-2 whitespace-nowrap" style={{ border: `1px solid ${line}`, background: paperRaised }}>Use my location</button>
        </div>
      )}

      {docType === "date_time" && (
        <input type="datetime-local" value={eventAt} onChange={(e) => setEventAt(e.target.value)} className="input mb-2" />
      )}

      <input
        value={caption}
        onChange={(e) => setCaption(e.target.value)}
        placeholder="Note for the admin (optional)"
        className="input mb-2"
      />

      {error && <p className="text-xs mb-2" style={{ color: "#9C2B2B" }}>{error}</p>}
      <button type="button" onClick={upload} disabled={uploading} className="w-full py-2 text-sm flex items-center justify-center gap-2" style={{ background: ink, color: paper, border: "none", opacity: uploading ? 0.6 : 1 }}>
        {uploading ? <Loader2 size={14} className="animate-spin" /> : <Lock size={13} />}
        {uploading ? "Uploading…" : "Add private proof"}
      </button>

      {saved.length > 0 && (
        <div className="text-xs mt-2" style={{ opacity: 0.6 }}>{saved.length} item{saved.length === 1 ? "" : "s"} added.</div>
      )}
    </div>
  );
}
