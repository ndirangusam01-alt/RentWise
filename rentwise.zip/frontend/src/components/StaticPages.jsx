import React, { useState } from "react";
import { ChevronLeft, Mail, MessageCircle, ChevronDown, ShieldCheck, Lock, Users, Eye } from "lucide-react";
import { api } from "../api.js";

const ink = "#20261F";
const paper = "#F6F2E9";
const paperRaised = "#FBF8F0";
const clay = "#A8451F";
const line = "#D8CFBD";
const forest = "#33512E";
const glow = "#E8B84B";

// ---------------------------------------------------------------------------
// Footer — shown at the bottom of the main app, Jiji-style link columns.
// ---------------------------------------------------------------------------
export function Footer({ onNavigate }) {
  const cols = [
    {
      title: "Company",
      links: [["About us", "about"], ["Contact us", "contact"], ["FAQs", "faqs"]],
    },
    {
      title: "Legal",
      links: [["Terms and Conditions", "terms"], ["Privacy Policy", "privacy"]],
    },
    {
      title: "Trust & safety",
      links: [["How verification works", "about"], ["Report a problem", "contact"]],
    },
  ];
  return (
    <footer style={{ background: ink, color: paper, marginTop: "3rem" }}>
      <div className="wrap-wide" style={{ paddingTop: "2.75rem", paddingBottom: "2.5rem" }}>
        <div className="footer-grid">
          <div style={{ maxWidth: 280 }}>
            <div className="flex items-center gap-2 mb-2">
              <img src="/logo-96.png" alt="RentWise" width={30} height={30} style={{ borderRadius: 8 }} />
              <span className="display" style={{ fontWeight: 600, fontSize: "1.15rem" }}>RentWise</span>
            </div>
            <p className="text-xs" style={{ opacity: 0.65, lineHeight: 1.6 }}>
              The rental record, built by the people who actually lived there. Kenya's independent
              source for what a place is really like before you sign a lease.
            </p>
          </div>
          {cols.map((c, i) => (
            <div key={c.title}>
              <div className="text-xs mb-2.5" style={{ fontWeight: 700, color: [glow, "#7FB3E8", "#E39BC4"][i], textTransform: "uppercase", letterSpacing: "0.05em" }}>{c.title}</div>
              <div className="flex flex-col gap-2">
                {c.links.map(([label, key]) => (
                  <button key={label} onClick={() => onNavigate(key)} className="footer-link text-sm text-left">
                    {label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div className="flex flex-wrap items-center justify-between gap-2 mt-8 pt-4 text-xs" style={{ borderTop: `1px solid rgba(246,242,233,0.15)`, opacity: 0.55 }}>
          <span>© {new Date().getFullYear()} RentWise. All rights reserved.</span>
          <span>Nairobi, Kenya</span>
        </div>
      </div>
      <style>{`
        .footer-grid { display: grid; grid-template-columns: 1fr; gap: 2rem; }
        @media (min-width: 700px) { .footer-grid { grid-template-columns: 1.4fr 1fr 1fr 1fr; } }
        .footer-link { background: none; border: none; color: ${paper}; opacity: 0.78; padding: 0; transition: opacity 0.15s ease, transform 0.15s ease, color 0.15s ease; }
        .footer-link:hover { opacity: 1; transform: translateX(3px); color: ${glow}; }
      `}</style>
    </footer>
  );
}

function PageShell({ title, kicker, onBack, children }) {
  return (
    <div className="wrap-mid">
      <button onClick={onBack} className="link flex items-center gap-1 text-sm mb-6">
        <ChevronLeft size={16} /> Back
      </button>
      {kicker && (
        <span className="pill pill-rust mb-3" style={{ display: "inline-flex" }}>{kicker}</span>
      )}
      <h1 className="display mb-6" style={{ fontWeight: 600, fontSize: "clamp(1.75rem, 4vw, 2.5rem)" }}>{title}</h1>
      <div className="static-content">{children}</div>
      <style>{`
        .static-content h2 { font-family: 'Fraunces', serif; font-size: 1.15rem; font-weight: 600; margin: 2rem 0 0.6rem; color: ${ink}; }
        .static-content p { font-size: 0.9rem; line-height: 1.7; color: #4A4438; margin: 0 0 0.9rem; }
        .static-content ul { padding-left: 1.1rem; margin: 0 0 1rem; }
        .static-content li { font-size: 0.9rem; line-height: 1.7; color: #4A4438; margin-bottom: 0.35rem; }
        .faq-item { border: 1.5px solid ${line}; background: ${paperRaised}; border-radius: 14px; overflow: hidden; transition: border-color 0.2s ease, transform 0.15s ease, box-shadow 0.2s ease; }
        .faq-item:hover { transform: translateY(-1px); box-shadow: 0 8px 20px -14px rgba(32,38,31,0.4); }
        .faq-icon { width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; transition: transform 0.2s cubic-bezier(.34,1.56,.64,1); }
        .faq-item:hover .faq-icon, .faq-trigger:hover .faq-icon { transform: scale(1.12) rotate(-6deg); }
      `}</style>
    </div>
  );
}

// ---------------------------------------------------------------------------
export function AboutPage({ onBack }) {
  return (
    <PageShell title="Know before you rent" kicker="About RentWise" onBack={onBack}>
      <p>
        RentWise exists because renting in Kenya usually means finding out what a place is
        really like <em>after</em> you've already signed and paid a deposit — the water schedule,
        the actual noise level, whether the landlord fixes things. We built a place for that
        information to live before the lease, not after.
      </p>
      <h2>How it works</h2>
      <p>
        Anyone who has lived somewhere can document it: category ratings for water, security,
        noise, maintenance, electricity, internet, and more, plus free-text context on why they
        stayed or left. Those reviews build a property's public record over time — its "digital
        passport" — visible to anyone researching that address.
      </p>
      <h2>Why anonymity is the default, not a setting</h2>
      <p>
        Every review is posted as "Verified former resident" or "Community contributor" — never
        with a name attached, whether or not you have an account. That's deliberate: honest
        feedback about a landlord or a neighbourhood is much harder to give if it can be traced
        back to you.
      </p>
      <h2>What "verified" means</h2>
      <p>
        A reviewer can attach private proof — a tenancy agreement, receipts, photos, a location
        pin, dated evidence — to back up a claim. That proof is never shown publicly. Only a
        RentWise moderator reviews it, to decide whether a review earns the verified badge.
      </p>
      <div className="grid sm:grid-cols-3 gap-3 mt-6">
        {[
          { icon: ShieldCheck, label: "Verification without exposure", color: "#2F8F73" },
          { icon: Lock, label: "Private proof, public trust", color: "#5B4FCF" },
          { icon: Users, label: "Built by real residents", color: "#C2478D" },
        ].map((f) => (
          <div key={f.label} className="p-3.5 flex items-start gap-3 faq-item" style={{ background: paperRaised, borderColor: line }}>
            <span className="faq-icon" style={{ background: `${f.color}22`, color: f.color }}><f.icon size={16} /></span>
            <span className="text-sm" style={{ fontWeight: 500, paddingTop: 4 }}>{f.label}</span>
          </div>
        ))}
      </div>
    </PageShell>
  );
}

// ---------------------------------------------------------------------------
export function TermsPage({ onBack }) {
  return (
    <PageShell title="Terms and Conditions" kicker="Legal" onBack={onBack}>
      <p style={{ opacity: 0.55, fontSize: "0.8rem" }}>Last updated: {new Date().toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" })}</p>
      <h2>1. What RentWise is</h2>
      <p>RentWise is a platform for documenting and researching rental properties through resident-submitted reviews and property records. It is not a listing, booking, or property-management service, and it does not broker rental agreements.</p>
      <h2>2. Accounts</h2>
      <p>You need an account to create a property record on RentWise; submitting a review does not require one. You're responsible for keeping your login credentials secure and for anything posted under your account.</p>
      <h2>3. Content you submit</h2>
      <ul>
        <li>Reviews must describe your own genuine experience as a resident, former resident, or someone with direct knowledge of the property.</li>
        <li>You may not post content that harasses, doxxes, or targets any individual, including landlords, property managers, or other tenants.</li>
        <li>Evidence submitted for verification must be your own or something you have the right to submit.</li>
        <li>RentWise may remove content, or restrict an account, that violates these terms or our Community Guidelines.</li>
      </ul>
      <h2>4. No warranty on accuracy</h2>
      <p>Reviews reflect individual experiences and opinions, not verified facts about a property in every case. RentWise makes reasonable efforts to detect and act on fraudulent or abusive content but cannot guarantee the accuracy of every review.</p>
      <h2>5. Limitation of liability</h2>
      <p>RentWise is provided "as is." To the fullest extent permitted by law, RentWise is not liable for decisions made based on information found on the platform, including rental decisions.</p>
      <h2>6. Changes to these terms</h2>
      <p>We may update these terms as the platform evolves. Continued use after a change means you accept the updated terms.</p>
      <h2>7. Contact</h2>
      <p>Questions about these terms can be sent through the Contact Us page.</p>
    </PageShell>
  );
}

// ---------------------------------------------------------------------------
export function PrivacyPage({ onBack }) {
  return (
    <PageShell title="Privacy Policy" kicker="Legal" onBack={onBack}>
      <p style={{ opacity: 0.55, fontSize: "0.8rem" }}>Last updated: {new Date().toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" })}</p>
      <h2>What we collect</h2>
      <ul>
        <li><strong>Account info:</strong> email address, and optionally a display name and Google profile info, if you sign up. None of this is ever shown on your reviews.</li>
        <li><strong>Reviews:</strong> the ratings and text you submit about a property. Public, but never attributed to your name.</li>
        <li><strong>Verification evidence:</strong> photos, videos, documents, location pins, or date/time claims submitted to back up a review. Private — visible only to RentWise moderators, never public, never sold or shared.</li>
        <li><strong>Usage data:</strong> basic technical logs (like error logs) needed to run and secure the service.</li>
      </ul>
      <h2>How public vs. private data is separated</h2>
      <p>
        RentWise deliberately keeps two separate systems: property photos you choose to publish to a
        listing's public gallery, and private verification evidence tied to a review. The second
        category is never exposed by any public page or API endpoint — only through an
        authenticated admin dashboard, restricted to RentWise staff accounts.
      </p>
      <h2>What we don't do</h2>
      <ul>
        <li>We don't attach your name or email to a review, ever — not even privately to other users.</li>
        <li>We don't sell personal data to advertisers or third parties.</li>
        <li>We don't publish verification evidence, under any circumstance.</li>
      </ul>
      <h2>Your rights</h2>
      <p>
        From your Account page, you can download a copy of your data or delete your account at any
        time. Deleting your account removes your login and personal details; your reviews remain —
        they were never linked to your name in the first place.
      </p>
      <h2>Contact</h2>
      <p>For privacy questions or requests, use the Contact Us page.</p>
    </PageShell>
  );
}

// ---------------------------------------------------------------------------
export function ContactPage({ onBack }) {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(null);

  async function submit(e) {
    e.preventDefault();
    setSending(true);
    setError(null);
    try {
      await api.contactUs(form);
      setSent(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setSending(false);
    }
  }

  return (
    <PageShell title="Contact us" kicker="Support" onBack={onBack}>
      <p>Question, correction, or a report about a review or property? Send it here — a real person reads these.</p>
      {sent ? (
        <div className="p-4 mt-4 flex items-start gap-2" style={{ background: paperRaised, border: `1px solid ${line}` }}>
          <MessageCircle size={16} className="mt-0.5 shrink-0" color={forest} />
          <span className="text-sm">Thanks — we've received your message and will get back to you by email.</span>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-3 mt-4 max-w-md">
          {error && <p className="text-sm" style={{ color: "#9C2B2B" }}>{error}</p>}
          <input className="input" required placeholder="Your name" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
          <input className="input" type="email" required placeholder="Your email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} />
          <textarea className="input" required rows={5} placeholder="How can we help?" value={form.message} onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))} />
          <button type="submit" disabled={sending} className="btn-pop py-2.5 px-5 text-sm flex items-center gap-2" style={{ background: clay, color: paper, border: "none" }}>
            <Mail size={14} /> {sending ? "Sending…" : "Send message"}
          </button>
        </form>
      )}
    </PageShell>
  );
}

// ---------------------------------------------------------------------------
const FAQ_COLORS = ["#2E86D6", "#C2478D", "#D9A61E", "#2F8F73", "#7B3FA0", "#D9622B", "#5B4FCF"];
const FAQS = [
  { q: "Do I need an account to write a review?", a: "No — anyone can document a property and submit a review with no account at all. An account is only required to create a new property record, so we can maintain accountability for what gets added to the database.", icon: Users },
  { q: "Will my name ever show up on a review?", a: "No. Every review is posted as \"Verified former resident\" or \"Community contributor\" — never with a name or email, regardless of whether you're logged in.", icon: Lock },
  { q: "What does the \"verified\" badge mean?", a: "It means the reviewer submitted private proof (like a tenancy agreement, receipts, or photos) that a RentWise admin checked to confirm they actually lived there. That proof itself is never made public.", icon: ShieldCheck },
  { q: "Who can see the evidence I submit?", a: "Only RentWise's moderation team, through the admin dashboard. It never appears on the public property page, and it's never sold or shared.", icon: Eye },
  { q: "Can a landlord get a review taken down?", a: "Landlords can report a review through Contact Us if they believe it violates our Terms (harassment, doxxing, fabricated claims). Our moderation team reviews every report — we don't remove reviews solely because a landlord disputes them.", icon: MessageCircle },
  { q: "Is RentWise a listing site?", a: "No — RentWise doesn't list properties for rent or broker leases. It's a research tool for finding out what a place is actually like, whether you found it here, on a listing site, or through a friend.", icon: ChevronDown },
  { q: "How is a property's score calculated?", a: "Each category (water, security, noise, etc.) averages the ratings submitted for it, alongside a sample-size indicator so you can tell a score based on 8 reviews from one based on a single review.", icon: ShieldCheck },
];

export function FaqsPage({ onBack }) {
  const [open, setOpen] = useState(0);
  return (
    <PageShell title="Frequently asked questions" kicker="Support" onBack={onBack}>
      <div className="space-y-3 mt-2">
        {FAQS.map((f, i) => {
          const color = FAQ_COLORS[i % FAQ_COLORS.length];
          const isOpen = open === i;
          return (
            <div key={i} className="faq-item" style={{ borderColor: isOpen ? color : line, "--faq-color": color }}>
              <button onClick={() => setOpen(isOpen ? null : i)} className="faq-trigger">
                <span className="faq-icon" style={{ background: `${color}22`, color }}>
                  <f.icon size={16} />
                </span>
                <span className="faq-q">{f.q}</span>
                <ChevronDown size={17} className="faq-chevron" style={{ transform: isOpen ? "rotate(180deg)" : "none", color }} />
              </button>
              <div className="faq-answer" style={{ maxHeight: isOpen ? 240 : 0 }}>
                <p style={{ padding: "0 1.1rem 1.1rem 3.4rem", margin: 0, fontSize: "0.88rem", lineHeight: 1.65, color: "#4A4438" }}>{f.a}</p>
              </div>
            </div>
          );
        })}
      </div>
      <style>{`
        .faq-trigger { width: 100%; display: flex; align-items: center; gap: 0.85rem; text-align: left; padding: 0.9rem 1.1rem; background: none; border: none; cursor: pointer; font-size: 0.92rem; font-weight: 600; color: ${ink}; }
        .faq-q { flex: 1; }
        .faq-chevron { flex-shrink: 0; transition: transform 0.25s cubic-bezier(.34,1.56,.64,1); }
        .faq-answer { max-height: 0; overflow: hidden; transition: max-height 0.35s cubic-bezier(.4,0,.2,1); }
      `}</style>
    </PageShell>
  );
}
