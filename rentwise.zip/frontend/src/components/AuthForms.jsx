import React, { useState, useEffect } from "react";
import { ChevronLeft, Loader2, Mail, CheckCircle2, Eye, EyeOff, ShieldCheck, Lock, Users } from "lucide-react";
import { api } from "../api.js";

const ink = "#20261F";
const paper = "#F6F2E9";
const paperRaised = "#FBF8F0";
const clay = "#A8451F";
const line = "#D8CFBD";
const rust = "#9C2B2B";
const forest = "#33512E";
const glow = "#E8B84B";

// ---------------------------------------------------------------------------
// Split-screen shell used by the two primary entry points (sign in / sign up).
// Left panel carries the brand — logo, the glow motif from the mark, and a
// short trust pitch. Collapses to a slim top band on narrow screens.
// ---------------------------------------------------------------------------
function AuthShell({ title, subtitle, onBack, children }) {
  return (
    <div className="auth-shell">
      <div className="auth-brand">
        <div className="auth-brand-inner">
          <img src="/logo-96.png" alt="" width={40} height={40} style={{ borderRadius: 10 }} />
          <h1 className="display" style={{ fontSize: "1.7rem", fontWeight: 600, margin: "0.75rem 0 0.4rem", color: paper }}>RentWise</h1>
          <p style={{ fontSize: "0.85rem", opacity: 0.75, maxWidth: 320, lineHeight: 1.5, color: paper }}>
            The rental record, built by the people who actually lived there.
          </p>
          <div className="auth-brand-glow" />
          <ul className="auth-trust">
            <li><ShieldCheck size={15} /> Reviews are always posted anonymously</li>
            <li><Lock size={15} /> Verification proof is seen only by moderators</li>
            <li><Users size={15} /> Built from real former-resident experiences</li>
          </ul>
        </div>
      </div>
      <div className="auth-form-panel">
        <div className="auth-form-inner">
          {onBack && (
            <button onClick={onBack} className="flex items-center gap-1 text-sm mb-5" style={{ opacity: 0.6, background: "none", border: "none" }}>
              <ChevronLeft size={16} /> Back
            </button>
          )}
          <h2 className="display text-2xl mb-1" style={{ fontWeight: 600 }}>{title}</h2>
          {subtitle && <p className="text-sm mb-6" style={{ opacity: 0.65 }}>{subtitle}</p>}
          {children}
        </div>
      </div>
      <style>{`
        .auth-shell { min-height: 100vh; display: grid; grid-template-columns: 1fr; }
        @media (min-width: 860px) { .auth-shell { grid-template-columns: 0.85fr 1.15fr; } }
        .auth-brand {
          position: relative; overflow: hidden; background: ${ink};
          display: flex; align-items: center; justify-content: center; padding: 2.5rem 2rem;
          min-height: 220px;
        }
        @media (min-width: 860px) { .auth-brand { min-height: 100vh; } }
        .auth-brand-inner { position: relative; z-index: 1; max-width: 360px; }
        .auth-brand-glow {
          position: absolute; width: 320px; height: 320px; border-radius: 50%;
          background: radial-gradient(circle, ${glow}55 0%, ${glow}00 70%);
          top: -80px; right: -120px; pointer-events: none;
          animation: authGlowPulse 6s ease-in-out infinite;
        }
        @keyframes authGlowPulse { 0%, 100% { opacity: 0.6; transform: scale(1); } 50% { opacity: 1; transform: scale(1.15); } }
        .auth-trust { list-style: none; padding: 0; margin: 1.75rem 0 0; display: flex; flex-direction: column; gap: 0.6rem; }
        .auth-trust li { display: flex; align-items: center; gap: 0.5rem; font-size: 0.8rem; color: ${paper}; opacity: 0.85; }
        .auth-form-panel { display: flex; align-items: center; justify-content: center; padding: 2.5rem 1.5rem 4rem; }
        .auth-form-inner { width: 100%; max-width: 380px; }
      `}</style>
    </div>
  );
}

function ErrBox({ error }) {
  if (!error) return null;
  return <p className="text-sm mb-3 p-2" style={{ color: rust, background: "#F3E9E4", border: "1px solid #E4C8B8" }}>{error}</p>;
}

function PasswordInput({ value, onChange, placeholder, minLength, autoComplete }) {
  const [show, setShow] = useState(false);
  return (
    <div style={{ position: "relative" }}>
      <input
        className="input" type={show ? "text" : "password"} required minLength={minLength}
        placeholder={placeholder} value={value} onChange={onChange} autoComplete={autoComplete}
        style={{ paddingRight: 40 }}
      />
      <button
        type="button" onClick={() => setShow((s) => !s)} aria-label={show ? "Hide password" : "Show password"}
        style={{ position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", opacity: 0.55, display: "flex" }}
      >
        {show ? <EyeOff size={16} /> : <Eye size={16} />}
      </button>
    </div>
  );
}

// Renders as an active "Continue with Google" button once the backend
// reports GOOGLE_CLIENT_ID etc. are set; otherwise a clearly-disabled one, so
// it's obvious this is a real feature waiting on credentials, not a dead end.
function GoogleButton() {
  const [enabled, setEnabled] = useState(null); // null = checking
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.googleAuthStatus().then((s) => setEnabled(s.enabled)).catch(() => setEnabled(false));
  }, []);

  function go() {
    setBusy(true);
    api.goToGoogleLogin(); // full-page redirect — this tab navigates away
  }

  return (
    <button
      type="button"
      onClick={go}
      disabled={enabled === false || busy}
      title={enabled === false ? "Google sign-in isn't set up yet on this deployment" : undefined}
      className="btn-pop w-full flex items-center justify-center gap-2.5 py-2.5 text-sm mb-4"
      style={{ background: paperRaised, border: `1px solid ${line}`, opacity: enabled === false ? 0.5 : 1, cursor: enabled === false ? "not-allowed" : "pointer" }}
    >
      {busy ? <Loader2 size={16} className="animate-spin" /> : <GoogleG />}
      {busy ? "Redirecting to Google…" : enabled === false ? "Continue with Google (not set up yet)" : "Continue with Google"}
    </button>
  );
}

function GoogleG() {
  return (
    <svg width="16" height="16" viewBox="0 0 48 48" aria-hidden="true">
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.9 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.6 6.1 29.6 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.7-.4-3.5z" />
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.6 15.9 18.9 13 24 13c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.6 7.1 29.6 5 24 5c-7.7 0-14.4 4.4-17.7 10.7z" transform="translate(0,-1)" />
      <path fill="#4CAF50" d="M24 44c5.5 0 10.4-1.9 14.3-5.1l-6.6-5.6C29.6 35 26.9 36 24 36c-5.3 0-9.7-3.1-11.3-7.6l-6.6 5.1C9.5 39.6 16.2 44 24 44z" />
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-0.8 2.3-2.3 4.3-4.2 5.7l6.6 5.6C41.5 36.5 44 30.9 44 24c0-1.3-.1-2.7-.4-3.5z" />
    </svg>
  );
}

function OrDivider() {
  return (
    <div className="flex items-center gap-3 my-4">
      <div style={{ flex: 1, height: 1, background: line }} />
      <span className="text-xs" style={{ opacity: 0.5 }}>or</span>
      <div style={{ flex: 1, height: 1, background: line }} />
    </div>
  );
}

export function Login({ onBack, onSuccess, goSignup, goForgot }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setLoading(true); setError(null);
    try {
      const { token, user } = await api.login({ email, password });
      api.setToken(token);
      onSuccess(user);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell title="Welcome back" subtitle="Sign in to review, verify, and document properties." onBack={onBack}>
      <GoogleButton />
      <OrDivider />
      <form onSubmit={submit} className="space-y-3">
        <ErrBox error={error} />
        <input className="input" type="email" required placeholder="Email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <PasswordInput value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" autoComplete="current-password" />
        <button type="submit" disabled={loading} className="btn-pop w-full py-3 text-sm flex items-center justify-center gap-2" style={{ background: ink, color: paper, border: "none" }}>
          {loading && <Loader2 size={14} className="animate-spin" />} {loading ? "Signing in…" : "Sign in"}
        </button>
      </form>
      <div className="flex justify-between text-xs mt-4" style={{ opacity: 0.7 }}>
        <button onClick={goForgot} className="link">Forgot password?</button>
        <button onClick={goSignup} className="link">Create an account</button>
      </div>
    </AuthShell>
  );
}

export function Signup({ onBack, onSuccess, goLogin }) {
  const [email, setEmail] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setLoading(true); setError(null);
    try {
      const { token, user } = await api.signup({ email, password, display_name: displayName });
      api.setToken(token);
      onSuccess(user);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell title="Create your account" subtitle="Needed to document a property. Reviews stay anonymous either way." onBack={onBack}>
      <GoogleButton />
      <OrDivider />
      <form onSubmit={submit} className="space-y-3">
        <ErrBox error={error} />
        <input className="input" placeholder="Display name (private — never shown on reviews)" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
        <input className="input" type="email" required placeholder="Email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <PasswordInput value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password (min 8 characters)" minLength={8} autoComplete="new-password" />
        <button type="submit" disabled={loading} className="btn-pop w-full py-3 text-sm flex items-center justify-center gap-2" style={{ background: clay, color: paper, border: "none" }}>
          {loading && <Loader2 size={14} className="animate-spin" />} {loading ? "Creating account…" : "Create account"}
        </button>
      </form>
      <p className="text-xs mt-4 text-center" style={{ opacity: 0.55 }}>
        By continuing you agree to RentWise's Terms and Privacy Policy.
      </p>
      <button onClick={goLogin} className="link text-xs mt-3 block w-full text-center">
        Already have an account? Sign in
      </button>
    </AuthShell>
  );
}

// ---------------------------------------------------------------------------
// Secondary, single-purpose flows keep a simpler centered card — they're a
// step inside a task (resetting a password, confirming an email), not a
// front door, so they don't need the full brand split-screen treatment.
// ---------------------------------------------------------------------------
function SimpleShell({ title, children, onBack }) {
  return (
    <div className="wrap-form">
      {onBack && (
        <button onClick={onBack} className="flex items-center gap-1 text-sm mb-4" style={{ opacity: 0.7, background: "none", border: "none" }}>
          <ChevronLeft size={16} /> Back
        </button>
      )}
      <div className="flex items-center gap-2 mb-4">
        <img src="/logo-96.png" alt="" width={28} height={28} style={{ borderRadius: 7 }} />
        <h2 className="display text-xl" style={{ fontWeight: 600 }}>{title}</h2>
      </div>
      {children}
    </div>
  );
}

export function ForgotPassword({ onBack }) {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setLoading(true);
    try { await api.forgotPassword(email); } finally { setLoading(false); setSent(true); }
  }

  return (
    <SimpleShell title="Reset your password" onBack={onBack}>
      {sent ? (
        <p className="text-sm flex items-start gap-2" style={{ opacity: 0.8 }}>
          <Mail size={16} className="mt-0.5" /> If an account exists for that email, a reset link is on its way.
        </p>
      ) : (
        <form onSubmit={submit} className="space-y-3">
          <input className="input" type="email" required placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <button type="submit" disabled={loading} className="btn-pop w-full py-3 text-sm" style={{ background: ink, color: paper, border: "none" }}>
            {loading ? "Sending…" : "Send reset link"}
          </button>
        </form>
      )}
    </SimpleShell>
  );
}

export function ResetPassword({ token, onDone }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setLoading(true); setError(null);
    try {
      await api.resetPassword(token, password);
      setDone(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  if (done) {
    return (
      <SimpleShell title="Password updated">
        <p className="text-sm mb-4 flex items-center gap-2" style={{ color: forest }}><CheckCircle2 size={16} /> You can now sign in with your new password.</p>
        <button onClick={onDone} className="btn-pop w-full py-3 text-sm" style={{ background: ink, color: paper, border: "none" }}>Go to sign in</button>
      </SimpleShell>
    );
  }

  return (
    <SimpleShell title="Choose a new password">
      <form onSubmit={submit} className="space-y-3">
        <ErrBox error={error} />
        <PasswordInput value={password} onChange={(e) => setPassword(e.target.value)} placeholder="New password (min 8 characters)" minLength={8} autoComplete="new-password" />
        <button type="submit" disabled={loading} className="btn-pop w-full py-3 text-sm" style={{ background: clay, color: paper, border: "none" }}>
          {loading ? "Saving…" : "Save new password"}
        </button>
      </form>
    </SimpleShell>
  );
}

export function VerifyEmailLanding({ token, onDone }) {
  const [status, setStatus] = useState("checking"); // checking | ok | error
  useEffect(() => {
    api.verifyEmail(token).then(() => setStatus("ok")).catch(() => setStatus("error"));
  }, [token]);

  return (
    <SimpleShell title="Email verification">
      {status === "checking" && <p className="text-sm flex items-center gap-2" style={{ opacity: 0.7 }}><Loader2 size={14} className="animate-spin" /> Verifying…</p>}
      {status === "ok" && <p className="text-sm flex items-center gap-2 mb-4" style={{ color: forest }}><CheckCircle2 size={16} /> Your email is verified.</p>}
      {status === "error" && <p className="text-sm mb-4" style={{ color: rust }}>This link is invalid or has expired. Request a new one from your account page.</p>}
      <button onClick={onDone} className="btn-pop w-full py-3 text-sm" style={{ background: ink, color: paper, border: "none" }}>Continue to RentWise</button>
    </SimpleShell>
  );
}
