import React, { useState } from "react";
import { X } from "lucide-react";

const ink = "#20261F";
const paper = "#F6F2E9";
const paperRaised = "#FBF8F0";
const line = "#D8CFBD";

// A chip picker where "Other" never dead-ends: choosing it reveals a text
// field, and whatever the person types is added as its own chip (as many as
// they like), replacing the literal word "Other" in the stored value.
//
// multi=true  -> value is an array, chips toggle independently (e.g. why_left)
// multi=false -> value is a single string (e.g. property type, county)
export default function SelectableOther({ options, value, onChange, multi = false }) {
  const [draft, setDraft] = useState("");
  const presets = options.filter((o) => o !== "Other");
  const isCustom = (v) => v && v !== "Other" && !presets.includes(v);
  const customValues = multi
    ? value.filter(isCustom)
    : (isCustom(value) ? [value] : []);
  const otherActive = multi
    ? customValues.length > 0 || value.includes("Other")
    : customValues.length > 0 || value === "Other";

  function isOn(opt) {
    if (opt !== "Other") return multi ? value.includes(opt) : value === opt;
    return otherActive;
  }

  function toggle(opt) {
    if (opt === "Other") {
      if (multi) {
        if (otherActive) onChange(value.filter((v) => presets.includes(v)));
        else onChange([...value, "Other"]);
      } else {
        onChange(otherActive ? "" : "Other");
      }
      return;
    }
    if (multi) {
      onChange(value.includes(opt) ? value.filter((v) => v !== opt) : [...value, opt]);
    } else {
      onChange(opt);
    }
  }

  function addCustom() {
    const text = draft.trim();
    if (!text) return;
    if (multi) {
      onChange([...value.filter((v) => v !== "Other"), text]);
    } else {
      onChange(text);
    }
    setDraft("");
  }

  function removeCustom(text) {
    if (multi) onChange(value.filter((v) => v !== text));
    else onChange("");
  }

  return (
    <div>
      <div className="flex flex-wrap">
        {presets.map((opt) => (
          <button
            key={opt}
            type="button"
            onClick={() => toggle(opt)}
            className={`chip px-3 py-1.5 text-sm mr-2 mb-2 ${isOn(opt) ? "on" : ""}`}
          >
            {opt}
          </button>
        ))}
        <button
          type="button"
          onClick={() => toggle("Other")}
          className={`chip px-3 py-1.5 text-sm mr-2 mb-2 ${otherActive ? "on" : ""}`}
        >
          Other
        </button>
      </div>

      {otherActive && (
        <div className="mb-2">
          {customValues.length > 0 && (
            <div className="flex flex-wrap mb-1.5">
              {customValues.map((c) => (
                <span key={c} className="flex items-center gap-1 text-xs pl-2.5 pr-1.5 py-1 mr-2 mb-1" style={{ background: paperRaised, border: `1px solid ${line}` }}>
                  {c}
                  <button type="button" onClick={() => removeCustom(c)} aria-label={`Remove ${c}`} style={{ background: "none", border: "none", display: "flex" }}>
                    <X size={11} />
                  </button>
                </span>
              ))}
            </div>
          )}
          {(multi || customValues.length === 0) && (
            <div className="flex gap-2">
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addCustom(); } }}
                placeholder={multi ? "Describe another reason, then press Add" : "Describe it"}
                className="input"
                style={{ flex: 1 }}
              />
              {multi && (
                <button type="button" onClick={addCustom} className="text-sm px-3" style={{ background: ink, color: paper, border: "none" }}>
                  Add
                </button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
