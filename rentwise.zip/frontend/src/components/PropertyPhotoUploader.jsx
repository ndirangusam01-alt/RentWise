import React, { useState, useRef } from "react";
import { Camera, Loader2, Star, Trash2 } from "lucide-react";
import { api } from "../api.js";

const line = "#D8CFBD";
const paperRaised = "#FBF8F0";
const ink = "#20261F";
const paper = "#F6F2E9";
const clay = "#A8451F";

// PUBLIC listing photo gallery. Anyone browsing the property sees these —
// distinct from the private review evidence in EvidenceUploader.jsx. Lets the
// contributor upload as many exterior/interior shots as they like and pick
// which one represents the listing, the way Jiji does.
export default function PropertyPhotoUploader({ propertyId, photos, onChange }) {
  const [area, setArea] = useState("exterior");
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState(null);
  const inputRef = useRef(null);

  async function pickFiles(e) {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    setError(null);
    setUploading(true);
    try {
      for (const file of files) {
        const saved = await api.uploadPropertyPhoto(propertyId, file, { area });
        onChange((cur) => [...cur, saved].sort((a, b) => (b.is_cover ? 1 : 0) - (a.is_cover ? 1 : 0) || a.position - b.position));
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  async function makeCover(photoId) {
    try {
      await api.setCoverPhoto(propertyId, photoId);
      onChange((cur) => cur.map((p) => ({ ...p, is_cover: p.id === photoId })));
    } catch (e) {
      setError(e.message);
    }
  }

  async function remove(photoId) {
    try {
      await api.deletePropertyPhoto(propertyId, photoId);
      onChange((cur) => cur.filter((p) => p.id !== photoId));
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <div>
      {photos.length > 0 && (
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mb-3">
          {photos.map((p) => (
            <div key={p.id} className="relative aspect-square overflow-hidden group" style={{ border: p.is_cover ? `2px solid ${clay}` : `1px solid ${line}` }}>
              <img src={api.mediaUrl(p.url)} alt={p.caption || `${p.area} photo`} className="w-full h-full object-cover" />
              <span className="absolute top-1 left-1 text-[10px] px-1.5 py-0.5" style={{ background: "rgba(32,38,31,0.75)", color: paper }}>
                {p.area === "interior" ? "Inside" : "Outside"}
              </span>
              <div className="absolute inset-x-0 bottom-0 flex items-center justify-between p-1" style={{ background: "linear-gradient(transparent, rgba(0,0,0,0.55))" }}>
                <button
                  type="button"
                  onClick={() => makeCover(p.id)}
                  title={p.is_cover ? "Cover photo" : "Set as cover photo"}
                  className="flex items-center gap-0.5 text-[10px] px-1 py-0.5"
                  style={{ background: "none", border: "none", color: p.is_cover ? "#E8B84B" : paper }}
                >
                  <Star size={11} fill={p.is_cover ? "#E8B84B" : "none"} /> {p.is_cover ? "Cover" : "Set cover"}
                </button>
                <button type="button" onClick={() => remove(p.id)} aria-label="Remove photo" style={{ background: "none", border: "none", color: paper }}>
                  <Trash2 size={12} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-center gap-2 mb-2">
        <div className="flex chip p-0.5" style={{ background: paperRaised }}>
          {["exterior", "interior"].map((a) => (
            <button
              key={a}
              type="button"
              onClick={() => setArea(a)}
              className="text-xs px-2.5 py-1"
              style={area === a ? { background: ink, color: paper } : { background: "none", border: "none" }}
            >
              {a === "exterior" ? "Outside" : "Inside"}
            </button>
          ))}
        </div>
        <label className="flex-1 flex items-center justify-center gap-2 py-2 text-sm cursor-pointer" style={{ border: `1px dashed ${line}`, opacity: 0.8 }}>
          {uploading ? <Loader2 size={15} className="animate-spin" /> : <Camera size={15} />}
          {uploading ? "Uploading…" : `Add ${area === "interior" ? "inside" : "outside"} photos`}
          <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={pickFiles} className="hidden" disabled={uploading} />
        </label>
      </div>
      {error && <p className="text-xs" style={{ color: "#9C2B2B" }}>{error}</p>}
      <p className="text-xs" style={{ opacity: 0.5 }}>Add as many as you like from both inside and outside, then tap the star on the one that should represent the listing.</p>
    </div>
  );
}
