import React, { useState } from "react";
import { MapContainer, TileLayer, Marker, useMapEvents } from "react-leaflet";
import L from "leaflet";
import { Crosshair, MapPin } from "lucide-react";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";

// react-leaflet's default marker icon paths break under bundlers unless re-pointed like this
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({ iconRetinaUrl: markerIcon2x, iconUrl: markerIcon, shadowUrl: markerShadow });

const NAIROBI = [-1.2921, 36.8219];

function ClickCatcher({ onPick }) {
  useMapEvents({
    click(e) { onPick(e.latlng.lat, e.latlng.lng); },
  });
  return null;
}

export default function LocationPicker({ lat, lng, precision, onChange }) {
  const [geoError, setGeoError] = useState(null);
  const [locating, setLocating] = useState(false);
  const center = lat && lng ? [lat, lng] : NAIROBI;

  function useMyLocation() {
    if (!navigator.geolocation) {
      setGeoError("Your browser doesn't support location.");
      return;
    }
    setLocating(true);
    setGeoError(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        onChange(pos.coords.latitude, pos.coords.longitude, "exact_gps");
        setLocating(false);
      },
      (err) => {
        setGeoError(err.message || "Couldn't get your location.");
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs" style={{ opacity: 0.6 }}>
          {lat && lng
            ? precision === "exact_gps" ? "📍 Exact GPS captured" : "📍 Approximate pin placed"
            : "Tap the map to drop an approximate pin, or use your location"}
        </span>
        <button
          type="button"
          onClick={useMyLocation}
          disabled={locating}
          className="flex items-center gap-1 text-xs px-2 py-1"
          style={{ border: "1px solid #D8CFBD", background: "#FBF8F0" }}
        >
          <Crosshair size={12} /> {locating ? "Locating…" : "Use my current location"}
        </button>
      </div>

      <div style={{ height: 220, border: "1px solid #D8CFBD" }}>
        <MapContainer center={center} zoom={lat ? 15 : 12} style={{ height: "100%", width: "100%" }}>
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <ClickCatcher onPick={(la, ln) => onChange(la, ln, "approx_pin")} />
          {lat && lng && <Marker position={[lat, lng]} />}
        </MapContainer>
      </div>

      {geoError && <p className="text-xs mt-1" style={{ color: "#9C2B2B" }}>{geoError}</p>}
      {lat && lng && (
        <button type="button" onClick={() => onChange(null, null, null)} className="text-xs mt-1 underline" style={{ opacity: 0.6, background: "none", border: "none" }}>
          Clear pin — keep this approximate/landmark-only
        </button>
      )}
      <p className="text-xs mt-1 flex items-center gap-1" style={{ opacity: 0.5 }}>
        <MapPin size={11} /> A precise pin is optional. A landmark or description works fine too.
      </p>
    </div>
  );
}
