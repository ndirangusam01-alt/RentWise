import React, { useState, useEffect } from "react";
import {
  ChevronLeft, LayoutDashboard, ShieldCheck, Flag, BarChart3, FileImage,
  Loader2, MapPin, Clock, FileText, Check, X, Search, SlidersHorizontal, Plus,
} from "lucide-react";
import { api } from "../api.js";

const ink = "#20261F";
const paper = "#F6F2E9";
const paperRaised = "#FBF8F0";
const clay = "#A8451F";
const forest = "#33512E";
const ochre = "#B9862E";
const rust = "#9C2B2B";
const line = "#D8CFBD";

const TABS = [
  { key: "analytics", label: "Analytics", icon: BarChart3 },
  { key: "moderation", label: "Moderation", icon: Flag },
  { key: "trust", label: "Trust & verification", icon: ShieldCheck },
  { key: "content", label: "Content", icon: FileImage },
  { key: "filters", label: "Filters", icon: SlidersHorizontal },
];

export default function AdminDashboard({ onBack }) {
  const [tab, setTab] = useState("analytics");

  return (
    <div className="wrap-wide">
      <button onClick={onBack} className="flex items-center gap-1 text-sm mb-4" style={{ opacity: 0.7, background: "none", border: "none" }}>
        <ChevronLeft size={16} /> Back to app
      </button>
      <div className="flex items-center gap-2 mb-1">
        <LayoutDashboard size={20} />
        <h2 className="display text-2xl" style={{ fontWeight: 600 }}>Admin dashboard</h2>
      </div>
      <p className="text-sm mb-6" style={{ opacity: 0.65 }}>Content, trust, moderation, and analytics — visible only to admin accounts.</p>

      <div className="flex flex-wrap gap-2 mb-6" style={{ borderBottom: `1px solid ${line}` }}>
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className="flex items-center gap-1.5 text-sm px-3 py-2"
            style={{
              background: "none", border: "none", borderBottom: tab === t.key ? `2px solid ${clay}` : "2px solid transparent",
              color: tab === t.key ? ink : "rgba(32,38,31,0.55)", fontWeight: tab === t.key ? 600 : 400,
            }}
          >
            <t.icon size={14} /> {t.label}
          </button>
        ))}
      </div>

      {tab === "analytics" && <AnalyticsTab />}
      {tab === "moderation" && <ModerationTab />}
      {tab === "trust" && <TrustTab />}
      {tab === "content" && <ContentTab />}
      {tab === "filters" && <FiltersTab />}
    </div>
  );
}

function StatCard({ label, value, tone }) {
  return (
    <div className="stat-card p-4" style={{ background: paperRaised, border: `1px solid ${line}`, "--accent": tone || clay }}>
      <div className="text-xs mb-1" style={{ color: "#6E6455" }}>{label}</div>
      <div className="display text-2xl" style={{ fontWeight: 600, color: tone || ink }}>{value}</div>
    </div>
  );
}

// ---------------------------------------------------------------------------
function AnalyticsTab() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    api.admin.stats().then(setStats).catch((e) => setError(e.message));
  }, []);

  if (error) return <ErrorNote message={error} />;
  if (!stats) return <Loading />;

  return (
    <div>
      <div className="listing-grid mb-6">
        <StatCard label="Properties documented" value={stats.properties} tone="#2E86D6" />
        <StatCard label="Published reviews" value={stats.publishedReviews} tone="#5B4FCF" />
        <StatCard label="Verified reviews" value={stats.verifiedReviews} tone={forest} />
        <StatCard label="Pending moderation" value={stats.pendingReviews} tone={stats.pendingReviews > 0 ? ochre : ink} />
        <StatCard label="Open reports" value={stats.openReports} tone={stats.openReports > 0 ? rust : ink} />
        <StatCard label="Registered accounts" value={stats.users} tone="#C2478D" />
        <StatCard label="Listing photos" value={stats.photos} tone="#2F8F73" />
      </div>
      <p className="text-xs" style={{ opacity: 0.5 }}>
        Deeper analytics — trust-score distributions, recency-weighted category trends, fraud-flag rates — are
        on the roadmap once the scoring engine (see below) is in place.
      </p>
    </div>
  );
}

// ---------------------------------------------------------------------------
function ModerationTab() {
  const [status, setStatus] = useState("under_review");
  const [reviews, setReviews] = useState([]);
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const [rv, rp] = await Promise.all([api.admin.reviews({ status }), api.admin.reports("open")]);
      setReviews(rv);
      setReports(rp);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); }, [status]);

  async function actOnReview(id, newStatus) {
    await api.admin.updateReview(id, newStatus);
    setReviews((cur) => cur.filter((r) => r.id !== id));
  }
  async function actOnReport(id, newStatus) {
    await api.admin.updateReport(id, { status: newStatus });
    setReports((cur) => cur.filter((r) => r.id !== id));
  }

  if (error) return <ErrorNote message={error} />;

  return (
    <div>
      <Section2 title={`Open reports (${reports.length})`}>
        {reports.length === 0 && <Empty text="No open reports." />}
        <div className="space-y-2">
          {reports.map((r) => (
            <div key={r.id} className="p-3 flex items-start justify-between gap-3" style={{ background: paperRaised, border: `1px solid ${line}` }}>
              <div className="text-sm">
                <div className="font-medium">{r.property_name || "Property"} · {r.reason.replace(/_/g, " ")}</div>
                {r.details && <div className="text-xs mt-1" style={{ opacity: 0.7 }}>{r.details}</div>}
                <div className="text-xs mt-1" style={{ opacity: 0.5 }}>Filed {new Date(r.created_at).toLocaleDateString()}</div>
              </div>
              <div className="flex gap-1.5 shrink-0">
                <button onClick={() => actOnReport(r.id, "resolved")} className="text-xs px-2 py-1 flex items-center gap-1" style={{ background: forest, color: paper, border: "none" }}><Check size={11} /> Resolve</button>
                <button onClick={() => actOnReport(r.id, "dismissed")} className="text-xs px-2 py-1 flex items-center gap-1" style={{ background: "none", border: `1px solid ${line}` }}><X size={11} /> Dismiss</button>
              </div>
            </div>
          ))}
        </div>
      </Section2>

      <Section2 title="Review queue" right={
        <select className="input" style={{ width: "auto" }} value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="under_review">Under review</option>
          <option value="published">Published</option>
          <option value="removed">Removed</option>
        </select>
      }>
        {loading ? <Loading /> : reviews.length === 0 ? <Empty text="Nothing here." /> : (
          <div className="space-y-2">
            {reviews.map((r) => (
              <div key={r.id} className="p-3" style={{ background: paperRaised, border: `1px solid ${line}` }}>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="text-sm font-medium">{r.property_name || "Property"}</div>
                  <span className="text-xs" style={{ opacity: 0.5 }}>{new Date(r.created_at).toLocaleDateString()}</span>
                </div>
                {r.why_left?.length > 0 && <div className="text-xs mb-1" style={{ opacity: 0.7 }}>Left because: {r.why_left.join(", ")}</div>}
                {r.best_thing && <p className="text-xs mb-1"><strong>Best:</strong> {r.best_thing}</p>}
                {r.wish_knew && <p className="text-xs mb-1"><strong>Wish knew:</strong> {r.wish_knew}</p>}
                <div className="flex gap-1.5 mt-2">
                  {status !== "published" && <button onClick={() => actOnReview(r.id, "published")} className="text-xs px-2 py-1 flex items-center gap-1" style={{ background: forest, color: paper, border: "none" }}><Check size={11} /> Publish</button>}
                  {status !== "removed" && <button onClick={() => actOnReview(r.id, "removed")} className="text-xs px-2 py-1 flex items-center gap-1" style={{ background: rust, color: paper, border: "none" }}><X size={11} /> Remove</button>}
                </div>
              </div>
            ))}
          </div>
        )}
      </Section2>
    </div>
  );
}

// ---------------------------------------------------------------------------
function TrustTab() {
  const [propertyId, setPropertyId] = useState("");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  async function lookup() {
    if (!propertyId.trim()) return;
    setLoading(true);
    setError(null);
    setData(null);
    try {
      const result = await api.admin.propertyVerification(propertyId.trim());
      setData(result);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  const iconFor = { photo: FileImage, video: FileImage, document: FileText, location: MapPin, date_time: Clock };

  return (
    <div>
      <p className="text-sm mb-3" style={{ opacity: 0.7 }}>
        Paste a property ID to review every private verification item submitted against its reviews —
        photos, videos, documents, location pins, and date/time claims. Nothing here is ever public.
      </p>
      <div className="flex gap-2 mb-6">
        <input value={propertyId} onChange={(e) => setPropertyId(e.target.value)} placeholder="Property ID (UUID)" className="input" />
        <button onClick={lookup} className="text-sm px-4 flex items-center gap-1.5 shrink-0" style={{ background: ink, color: paper, border: "none" }}><Search size={14} /> Look up</button>
      </div>
      {loading && <Loading />}
      {error && <ErrorNote message={error} />}
      {data && (
        <div>
          <h3 className="text-sm mb-2" style={{ fontWeight: 600 }}>{data.property.name || "Unnamed property"}</h3>
          <Section2 title={`Reviews (${data.reviews.length})`}>
            <div className="space-y-2 mb-4">
              {data.reviews.map((r) => (
                <div key={r.id} className="p-2.5 text-xs" style={{ background: paperRaised, border: `1px solid ${line}` }}>
                  <span className={`pill mr-2 ${r.verification_level === "verified_resident" ? "pill-green" : "pill-amber"}`}>{r.verification_level}</span>
                  status: {r.status} · {new Date(r.created_at).toLocaleDateString()}
                </div>
              ))}
            </div>
          </Section2>
          <Section2 title={`Private evidence (${data.evidence.length})`}>
            {data.evidence.length === 0 && <Empty text="No verification material submitted for this property." />}
            <div className="space-y-2">
              {data.evidence.map((e) => {
                const Icon = iconFor[e.media_type] || FileImage;
                return (
                  <div key={e.id} className="p-2.5 flex items-start gap-2 text-xs" style={{ background: paperRaised, border: `1px solid ${line}` }}>
                    <Icon size={14} className="mt-0.5 shrink-0" />
                    <div className="flex-1">
                      <div className="font-medium">{e.media_type}{e.review_id ? ` · review ${e.review_id.slice(0, 8)}` : ""}</div>
                      {e.url && <a href={api.mediaUrl(e.url)} target="_blank" rel="noreferrer" className="underline">{e.url}</a>}
                      {e.submitted_lat && <div>Location: {e.submitted_lat}, {e.submitted_lng}</div>}
                      {e.event_at && <div>Claimed date/time: {new Date(e.event_at).toLocaleString()}</div>}
                      {e.caption && <div style={{ opacity: 0.7 }}>Note: {e.caption}</div>}
                      <div style={{ opacity: 0.5 }}>Submitted {new Date(e.uploaded_at).toLocaleDateString()}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Section2>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
function ContentTab() {
  const [q, setQ] = useState("");
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState([]);
  const [msgLoading, setMsgLoading] = useState(true);

  async function search() {
    setLoading(true);
    try {
      setUsers(await api.admin.users(q));
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { search(); }, []);
  useEffect(() => {
    api.admin.contactMessages({ resolved: "false" }).then(setMessages).finally(() => setMsgLoading(false));
  }, []);

  async function resolveMessage(id) {
    await api.admin.resolveContactMessage(id, true);
    setMessages((cur) => cur.filter((m) => m.id !== id));
  }

  return (
    <div>
      <Section2 title={`Contact Us submissions (${messages.length} open)`}>
        {msgLoading ? <Loading /> : messages.length === 0 ? <Empty text="No open messages." /> : (
          <div className="space-y-2 mb-4">
            {messages.map((m) => (
              <div key={m.id} className="p-3" style={{ background: paperRaised, border: `1px solid ${line}` }}>
                <div className="flex items-start justify-between gap-3 mb-1">
                  <div className="text-sm font-medium">{m.name} <span className="font-normal" style={{ opacity: 0.6 }}>· {m.email}</span></div>
                  <span className="text-xs shrink-0" style={{ opacity: 0.5 }}>{new Date(m.created_at).toLocaleDateString()}</span>
                </div>
                <p className="text-sm mb-2" style={{ opacity: 0.8 }}>{m.message}</p>
                <button onClick={() => resolveMessage(m.id)} className="text-xs px-2 py-1 flex items-center gap-1" style={{ background: forest, color: paper, border: "none" }}><Check size={11} /> Mark resolved</button>
              </div>
            ))}
          </div>
        )}
      </Section2>

      <Section2 title="Contributor reliability" right={
        <div className="flex gap-2">
          <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && search()} placeholder="Search by email or name" className="input" style={{ width: 220 }} />
          <button onClick={search} className="text-xs px-3" style={{ background: ink, color: paper, border: "none" }}>Search</button>
        </div>
      }>
        {loading ? <Loading /> : (
          <div className="space-y-1.5">
            {users.map((u) => (
              <div key={u.id} className="flex items-center justify-between text-sm p-2.5" style={{ background: paperRaised, border: `1px solid ${line}` }}>
                <div>
                  <div className="flex items-center gap-1.5">
                    {u.display_name || u.phone_or_email}
                    {u.role === "admin" && <span className="pill pill-blue">admin</span>}
                  </div>
                  <div className="text-xs" style={{ opacity: 0.55 }}>{u.phone_or_email} · {u.review_count} review{u.review_count === "1" ? "" : "s"}</div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {u.email_verified ? <ShieldCheck size={14} color={forest} /> : <span className="text-xs" style={{ opacity: 0.4 }}>unverified</span>}
                  <button
                    onClick={() => promote(u.id, u.role === "admin" ? "user" : "admin")}
                    className="text-xs px-2 py-1"
                    style={{ border: `1px solid ${line}`, background: "none" }}
                  >
                    {u.role === "admin" ? "Revoke admin" : "Make admin"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Section2>
      <p className="text-xs" style={{ opacity: 0.5 }}>
        Property and listing-photo moderation (removing spam or wrong-context photos) will surface here
        once photo reports are wired in — currently reachable via each property's own page.
      </p>
    </div>
  );
}

// ---------------------------------------------------------------------------
function FiltersTab() {
  const [defs, setDefs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showNew, setShowNew] = useState(false);
  const [newFilter, setNewFilter] = useState({ key: "", label: "", type: "boolean", optionsText: "" });
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    try {
      setDefs(await api.admin.filterDefinitions());
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); }, []);

  async function toggleActive(fd) {
    const updated = await api.admin.updateFilterDefinition(fd.id, { active: !fd.active });
    setDefs((cur) => cur.map((d) => (d.id === fd.id ? updated : d)));
  }

  async function createFilter() {
    setSaving(true);
    setError(null);
    try {
      const options = newFilter.type === "select"
        ? newFilter.optionsText.split(",").map((s) => s.trim()).filter(Boolean)
        : undefined;
      const created = await api.admin.createFilterDefinition({ key: newFilter.key, label: newFilter.label, type: newFilter.type, options });
      setDefs((cur) => [...cur, created]);
      setNewFilter({ key: "", label: "", type: "boolean", optionsText: "" });
      setShowNew(false);
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <p className="text-sm mb-4" style={{ opacity: 0.7 }}>
        Filters added here show up immediately on the property search page and on the "Add a property"
        form's Amenities section — no code change or redeploy needed.
      </p>
      {error && <ErrorNote message={error} />}
      <Section2 title={`Active & inactive filters (${defs.length})`} right={
        <button onClick={() => setShowNew((s) => !s)} className="text-xs px-2.5 py-1.5 flex items-center gap-1" style={{ background: ink, color: paper, border: "none" }}>
          <Plus size={12} /> New filter
        </button>
      }>
        {showNew && (
          <div className="p-3 mb-3 space-y-2" style={{ background: paperRaised, border: `1px solid ${line}` }}>
            <div className="grid sm:grid-cols-2 gap-2">
              <input className="input" placeholder="Key (e.g. borehole_water)" value={newFilter.key} onChange={(e) => setNewFilter((f) => ({ ...f, key: e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, "_") }))} />
              <input className="input" placeholder="Label shown to users (e.g. Borehole water)" value={newFilter.label} onChange={(e) => setNewFilter((f) => ({ ...f, label: e.target.value }))} />
            </div>
            <div className="flex gap-2">
              {["boolean", "select"].map((t) => (
                <button key={t} type="button" onClick={() => setNewFilter((f) => ({ ...f, type: t }))} className="chip px-3 py-1.5 text-xs" style={newFilter.type === t ? { background: ink, color: paper, borderColor: ink } : {}}>
                  {t === "boolean" ? "Yes/No" : "Choose one"}
                </button>
              ))}
            </div>
            {newFilter.type === "select" && (
              <input className="input" placeholder="Options, comma-separated (e.g. Borehole, Mains, Tanker)" value={newFilter.optionsText} onChange={(e) => setNewFilter((f) => ({ ...f, optionsText: e.target.value }))} />
            )}
            <button onClick={createFilter} disabled={saving || !newFilter.key || !newFilter.label} className="text-sm px-3 py-2" style={{ background: clay, color: paper, border: "none", opacity: (!newFilter.key || !newFilter.label) ? 0.5 : 1 }}>
              {saving ? "Creating…" : "Create filter"}
            </button>
          </div>
        )}
        {loading ? <Loading /> : (
          <div className="space-y-1.5">
            {defs.map((fd) => (
              <div key={fd.id} className="flex items-center justify-between text-sm p-2.5" style={{ background: paperRaised, border: `1px solid ${line}`, opacity: fd.active ? 1 : 0.5 }}>
                <div>
                  <div style={{ fontWeight: 500 }}>{fd.label} <span className="text-xs" style={{ opacity: 0.5 }}>({fd.key})</span></div>
                  <div className="text-xs" style={{ opacity: 0.55 }}>
                    {fd.type === "boolean" ? "Yes/No" : `Choose one: ${(fd.options || []).join(", ")}`}
                  </div>
                </div>
                <button onClick={() => toggleActive(fd)} className="text-xs px-2 py-1" style={{ border: `1px solid ${line}`, background: "none" }}>
                  {fd.active ? "Deactivate" : "Activate"}
                </button>
              </div>
            ))}
          </div>
        )}
      </Section2>
    </div>
  );
}

// ---------------------------------------------------------------------------
function Section2({ title, right, children }) {
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
        <h3 className="text-sm" style={{ fontWeight: 600 }}>{title}</h3>
        {right}
      </div>
      {children}
    </div>
  );
}
function Loading() {
  return <div className="flex items-center gap-2 text-sm py-4" style={{ opacity: 0.6 }}><Loader2 size={14} className="animate-spin" /> Loading…</div>;
}
function Empty({ text }) {
  return <div className="text-sm py-4 text-center" style={{ opacity: 0.5, border: `1px dashed ${line}` }}>{text}</div>;
}
function ErrorNote({ message }) {
  return <div className="text-sm py-3 px-3" style={{ background: "#F3E9E4", border: "1px solid #E4C8B8", color: rust }}>{message}</div>;
}
