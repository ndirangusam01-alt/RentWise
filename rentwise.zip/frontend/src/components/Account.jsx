import React, { useState } from "react";
import { ChevronLeft, ShieldCheck, ShieldAlert, LogOut, Lock, Download, Trash2, LayoutDashboard } from "lucide-react";
import { api } from "../api.js";

const ink = "#20261F";
const paper = "#F6F2E9";
const paperRaised = "#FBF8F0";
const line = "#D8CFBD";
const forest = "#33512E";
const rust = "#9C2B2B";

const TABS = ["Profile", "Privacy & data", "Settings"];

export default function Account({ user, onBack, onLogout, onUserUpdated, onAdmin }) {
  const [tab, setTab] = useState("Profile");

  return (
    <div className="wrap-form">
      <button onClick={onBack} className="flex items-center gap-1 text-sm mb-4" style={{ opacity: 0.7, background: "none", border: "none" }}>
        <ChevronLeft size={16} /> Back
      </button>
      <h2 className="display text-2xl mb-4" style={{ fontWeight: 600 }}>Your account</h2>

      <div className="flex gap-2 mb-6" style={{ borderBottom: `1px solid ${line}` }}>
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className="text-sm px-1 pb-2"
            style={{ background: "none", border: "none", borderBottom: tab === t ? `2px solid #A8451F` : "2px solid transparent", fontWeight: tab === t ? 600 : 400, opacity: tab === t ? 1 : 0.6 }}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === "Profile" && <ProfileTab user={user} onUserUpdated={onUserUpdated} />}
      {tab === "Privacy & data" && <PrivacyTab user={user} />}
      {tab === "Settings" && <SettingsTab />}

      {user.role === "admin" && (
        <button onClick={onAdmin} className="btn-pop w-full py-2.5 text-sm flex items-center justify-center gap-2 mt-6" style={{ border: `1px solid ${line}`, background: paperRaised }}>
          <LayoutDashboard size={14} /> Open admin dashboard
        </button>
      )}
      <button onClick={onLogout} className="btn-pop w-full py-2.5 text-sm flex items-center justify-center gap-2 mt-3" style={{ border: `1px solid ${line}`, background: "none" }}>
        <LogOut size={14} /> Log out
      </button>
    </div>
  );
}

function ProfileTab({ user, onUserUpdated }) {
  const [displayName, setDisplayName] = useState(user.display_name || "");
  const [saving, setSaving] = useState(false);
  const [resent, setResent] = useState(false);

  async function save() {
    setSaving(true);
    try {
      const updated = await api.updateProfile({ display_name: displayName });
      onUserUpdated(updated);
    } finally {
      setSaving(false);
    }
  }
  async function resend() {
    await api.resendVerification(user.email);
    setResent(true);
  }

  return (
    <div>
      <div className="p-3 mb-4 text-sm flex items-center gap-2" style={{ background: paperRaised, border: `1px solid ${line}` }}>
        {user.email_verified ? (
          <><ShieldCheck size={16} color={forest} /> Email verified</>
        ) : (
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1"><ShieldAlert size={16} color="#B9862E" /> Email not verified yet</div>
            {resent
              ? <div className="text-xs" style={{ opacity: 0.6 }}>New link sent — check your inbox.</div>
              : <button onClick={resend} className="link text-xs">Resend verification email</button>}
          </div>
        )}
      </div>

      <label className="block mb-1 text-xs" style={{ opacity: 0.6 }}>Email</label>
      <div className="mb-4 text-sm" style={{ opacity: 0.8 }}>{user.email}</div>

      <label className="block mb-1 text-xs" style={{ opacity: 0.6 }}>Display name (private — never shown on reviews)</label>
      <input className="input mb-3" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
      <button onClick={save} disabled={saving} className="btn-pop w-full py-2.5 text-sm" style={{ background: ink, color: paper, border: "none" }}>
        {saving ? "Saving…" : "Save changes"}
      </button>
    </div>
  );
}

function PrivacyTab({ user }) {
  const [exporting, setExporting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState(null);

  async function exportData() {
    setExporting(true);
    setError(null);
    try {
      const data = await api.exportData();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "rentwise-my-data.json";
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      setError(e.message);
    } finally {
      setExporting(false);
    }
  }

  async function deleteAccount() {
    setDeleting(true);
    setError(null);
    try {
      await api.deleteAccount();
      api.setToken(null);
      window.location.reload();
    } catch (e) {
      setError(e.message);
      setDeleting(false);
    }
  }

  return (
    <div>
      <div className="p-3 mb-5 text-sm" style={{ background: paperRaised, border: `1px solid ${line}` }}>
        <div className="font-medium mb-1 flex items-center gap-2"><Lock size={14} /> How your privacy works here</div>
        <ul className="list-disc pl-4 space-y-1 mt-2" style={{ opacity: 0.8 }}>
          <li>Reviews you submit are always posted anonymously, as "Verified former resident" or "Community contributor" — never with your name or email.</li>
          <li>Proof you attach to a review (photos, documents, location, date/time) is private — only a RentWise admin can see it, to confirm your "verified" badge.</li>
          <li>The public property page only ever shows photos you deliberately upload to its public gallery.</li>
        </ul>
      </div>

      <div className="mb-5">
        <div className="text-sm font-medium mb-1">Download your data</div>
        <p className="text-xs mb-2" style={{ opacity: 0.65 }}>A copy of your account details and every review you've submitted, as a JSON file.</p>
        <button onClick={exportData} disabled={exporting} className="text-sm px-3 py-2 flex items-center gap-2" style={{ border: `1px solid ${line}`, background: paperRaised }}>
          <Download size={14} /> {exporting ? "Preparing…" : "Download my data"}
        </button>
      </div>

      <div>
        <div className="text-sm font-medium mb-1" style={{ color: rust }}>Delete account</div>
        <p className="text-xs mb-2" style={{ opacity: 0.65 }}>
          Your reviews stay on the record (they were never linked to your name), but your account and login are permanently removed.
        </p>
        {!confirmDelete ? (
          <button onClick={() => setConfirmDelete(true)} className="text-sm px-3 py-2 flex items-center gap-2" style={{ border: `1px solid ${rust}`, color: rust, background: "none" }}>
            <Trash2 size={14} /> Delete my account
          </button>
        ) : (
          <div className="p-3" style={{ background: "#F3E9E4", border: "1px solid #E4C8B8" }}>
            <p className="text-sm mb-2">This can't be undone. Delete your account for good?</p>
            <div className="flex gap-2">
              <button onClick={deleteAccount} disabled={deleting} className="text-sm px-3 py-1.5" style={{ background: rust, color: paper, border: "none" }}>{deleting ? "Deleting…" : "Yes, delete"}</button>
              <button onClick={() => setConfirmDelete(false)} className="text-sm px-3 py-1.5" style={{ background: "none", border: `1px solid ${line}` }}>Cancel</button>
            </div>
          </div>
        )}
      </div>
      {error && <p className="text-xs mt-3" style={{ color: rust }}>{error}</p>}
    </div>
  );
}

function SettingsTab() {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);

  async function changePassword() {
    setSaving(true);
    setError(null);
    setMessage(null);
    try {
      await api.changePassword({ current_password: current, new_password: next });
      setMessage("Password updated.");
      setCurrent(""); setNext("");
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <div className="text-sm font-medium mb-2">Change password</div>
      <input className="input mb-2" type="password" placeholder="Current password" value={current} onChange={(e) => setCurrent(e.target.value)} />
      <input className="input mb-3" type="password" placeholder="New password (min. 8 characters)" value={next} onChange={(e) => setNext(e.target.value)} />
      <button onClick={changePassword} disabled={saving || !current || next.length < 8} className="btn-pop w-full py-2.5 text-sm" style={{ background: ink, color: paper, border: "none", opacity: (saving || !current || next.length < 8) ? 0.5 : 1 }}>
        {saving ? "Updating…" : "Update password"}
      </button>
      {message && <p className="text-xs mt-2" style={{ color: forest }}>{message}</p>}
      {error && <p className="text-xs mt-2" style={{ color: rust }}>{error}</p>}
    </div>
  );
}
