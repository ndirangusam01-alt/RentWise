# RentWise

A rental intelligence platform: before someone rents, they can see what previous
tenants actually experienced at that property — water reliability, security,
noise, landlord responsiveness, and why people left — sourced from structured
reviews rather than star ratings or marketing photos.

This is a real, working full-stack app:
- **backend/** — Node.js + Express API on PostgreSQL. Tested end-to-end with a
  live Postgres instance during development (schema, duplicate detection,
  review aggregation, scoring — all verified against a real database, not mocked).
- **frontend/** — React (Vite) app that talks to that API over HTTP.

Nothing here is a simulation — it's the same code you'd run in production, just
not yet deployed to a public URL (that step needs your own hosting account,
which I can't create on your behalf from this environment).

**A note on this pass specifically:** this round of changes (responsive
redesign, public photo gallery, private-evidence split, admin dashboard,
filters, the "Other" free-text fix, account privacy/settings) was written in
a sandbox with no network access — no live Postgres, no `npm install`, no
running dev server. Every backend file was syntax-checked with `node --check`
and every frontend file with `tsc --jsx react --noEmit`, and the logic was
reviewed line by line, but none of it has been run end-to-end the way the
original build was. Run `npm run migrate` and click through the flows below
before trusting this in production — if anything doesn't work, it's a good
first data point for a follow-up pass.

## Run it locally (10 minutes)

**1. Backend**
```bash
cd backend
npm install
cp .env.example .env          # edit DATABASE_URL, and see "Auth & email" below
npm run migrate               # creates all tables (safe to rerun — tracks what's applied)
npm start                     # http://localhost:3001
```

### Auth & email setup
Add these to `backend/.env`:
```
JWT_SECRET=some-long-random-string        # required in production; there's an insecure dev default otherwise
RESEND_API_KEY=re_xxxxxxxx                # optional locally — see below
RESEND_FROM_EMAIL=RentWise <you@yourdomain.com>
APP_BASE_URL=http://localhost:5173        # used to build verification/reset links
```
**If `RESEND_API_KEY` is not set**, the app doesn't fail — it logs the full email
(including the verification/reset link) to the backend terminal instead, so you
can develop and test the entire auth flow without a Resend account at all. Get
a real key from [resend.com](https://resend.com) when you're ready to send
actual email; the free tier covers early-stage usage.

### Google sign-in setup (optional)
Email+password works with zero extra setup. To turn on the "Continue with
Google" button too:
1. Go to [Google Cloud Console → Credentials](https://console.cloud.google.com/apis/credentials), create an OAuth 2.0 Client ID (type: Web application).
2. Add an **Authorized redirect URI** matching exactly what you'll set below — for local dev, `http://localhost:3001/api/auth/google/callback`.
3. Add to `backend/.env`:
```
GOOGLE_CLIENT_ID=xxxxxxxx.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=xxxxxxxx
GOOGLE_REDIRECT_URI=http://localhost:3001/api/auth/google/callback
FRONTEND_ORIGIN=http://localhost:5173
```
Until these are set, the Google button renders visibly disabled with a
"not set up yet" label instead of silently failing. The client secret never
reaches the browser — the whole token exchange happens server-side.

**2. Frontend** (new terminal)
```bash
cd frontend
npm install
cp .env.example .env          # VITE_API_URL should point at your backend
npm run dev                   # http://localhost:5173
```

Open `http://localhost:5173` — you now have a working local copy.

### Local Postgres, if you don't already have one
```bash
# macOS
brew install postgresql@16 && brew services start postgresql@16
createdb rentwise

# Ubuntu/Debian
sudo apt-get install postgresql postgresql-contrib
sudo -u postgres createdb rentwise
sudo -u postgres psql -c "ALTER USER postgres PASSWORD 'postgres';"
# then set DATABASE_URL=postgres://postgres:postgres@localhost:5432/rentwise
```

## Deploying to a real public URL

You need a hosting account for this part — I can't create one for you, but here's
the exact path. **Render** is the simplest free option that supports both a
Postgres database and a Node web service.

1. Push this folder to a GitHub repo.
2. On [render.com](https://render.com): **New → PostgreSQL** — copy the "Internal
   Database URL" it gives you.
3. **New → Web Service**, point it at your repo's `backend/` folder.
   - Build command: `npm install`
   - Start command: `npm start`
   - Environment variable `DATABASE_URL` = the internal database URL from step 2
   - After first deploy, open the Render **Shell** tab for this service and run
     `npm run migrate` once, to create the tables.
4. **New → Static Site**, point it at your repo's `frontend/` folder.
   - Build command: `npm install && npm run build`
   - Publish directory: `dist`
   - Environment variable `VITE_API_URL` = the URL Render gave your backend service
     (something like `https://rentwise-backend.onrender.com`)
5. Render gives the static site a URL like `https://rentwise.onrender.com` —
   that's your real, live, public app.

Railway and Fly.io work the same way (Postgres add-on + web service + static
site) if you'd rather use one of those.

## Making yourself an admin

Three ways, in order of convenience:

1. **CLI, one command** — from `backend`, run:
   ```
   npm run seed:admin -- you@yourdomain.com
   ```
   If that account already exists, it's promoted. If not, it's created (with
   a random temporary password printed to the console — change it from
   Account → Settings after your first login). You can also set
   `ADMIN_EMAIL` in `.env` and just run `npm run seed:admin` with no arguments.

2. **From the dashboard** — once you have at least one admin, sign in as
   them, open the admin dashboard's **Content** tab, find any user in the
   contributor list, and click **Make admin**. Same button lets you revoke it.

3. **Directly in the database** (no script needed):
   ```sql
   UPDATE users SET role = 'admin' WHERE phone_or_email = 'you@yourdomain.com';
   ```

Whichever way, the change takes effect on that person's next login (or next
`/api/auth/me` refresh), and shows the "Admin" link on the home screen and
account page.

## What's real vs. what's next

**Latest round of changes:**
- **Google sign-in now uses a full-page redirect**, not a popup. The popup
  version broke in real browsers — Google's own login pages set a
  Cross-Origin-Opener-Policy header that severs a popup from its opener's
  browsing-context group, so `window.opener` goes null before our callback
  page can use it. A redirect has no popup/opener relationship to sever, so
  this bug class can't happen with the current implementation.
- **Storage now supports AWS S3** (`STORAGE_DRIVER=s3`), built around a
  fully-private bucket — no ACLs, no bucket policy, works unmodified with
  AWS's "block all public access" default. Every URL handed to the browser
  (public photo or private evidence) is a short-lived signed URL minted at
  request time, not a permanent link. Run `npm install` again in `backend`
  to pull in the two new AWS SDK packages.
- **Location filters**: a real County → Subcounty hierarchy for all 47
  Kenyan counties (`frontend/src/kenyaLocations.js`), used both when
  documenting a property and when searching. Dropping a location pin now
  attempts to auto-fill county/subcounty via reverse geocoding
  (OpenStreetMap's Nominatim — free, no API key), which you can always
  confirm or override.
- **Better search**: debounced search-as-you-type (was firing a request per
  keystroke), case-insensitive by default, plus typo-tolerant fuzzy matching
  via Postgres trigram similarity (`pg_trgm`) layered on top of substring
  matching.
- **Admin-manageable custom filters** — a full mechanism, not a mockup.
  Admins add new Yes/No or multiple-choice filters from the dashboard's new
  **Filters** tab; each one immediately appears both as a search filter and
  as a field on the property creation form's Amenities section, with no code
  change or redeploy. Seeded with a few defaults (parking, furnished, pet
  friendly, gated community, water source) so the filter bar isn't empty on
  a fresh install.
- **Admin seeding**: `npm run seed:admin -- you@email.com` from the CLI, or a
  "Make admin" button in the dashboard's Content tab — see below.

**Working now:** property creation with duplicate detection, layered location
(exact GPS via browser geolocation, click-to-drop approximate pin on a real
OpenStreetMap map — no API key needed — landmark, or free-text description),
a **public photo gallery per property** (as many interior/exterior shots as
you like, pick which one is the cover — separate from private review
evidence), structured "why did you leave" reviews with free-text "Other"
reasons that never dead-end, live server-computed category scores with a
sample-size confidence indicator, frequently-reported-issue tallies, rent
history over time, a right-of-dispute reporting endpoint, extensive filters
(location, type, bedrooms, rent range, verified-only, admin-defined
amenities, sort) alongside fuzzy free-text search, and **real optional
accounts**: signup, login (email+password and Google), email verification,
and forgot/reset password, all backed by bcrypt password hashing and JWTs.

**Privacy architecture:** two clearly separate systems. `property_photos` are
public — anyone browsing sees them. `evidence` (photos, videos, documents,
location pins, date/time claims a reviewer submits to back up a "verified"
review) is private and is **never** returned by any public endpoint — only an
admin, through `/api/admin/evidence` or the Trust & Verification tab of the
admin dashboard, can see it. Reviews themselves are always anonymous — no
name or email is ever attached to what's shown publicly, by design, not by
toggle.

**Admin dashboard:** role-gated (`users.role = 'admin'`, checked against the
database on every request, not trusted from the JWT). Five tabs — Analytics
(top-line counts), Moderation (the report queue, review queue, and Contact Us
inbox, with publish/remove/resolve/dismiss actions), Trust & Verification
(look up a property's private evidence to confirm a claim), Content
(contributor lookup, promote/revoke admin), and Filters (create/deactivate
admin-defined search filters). Account settings gained matching depth: a
Privacy & Data tab (explains the anonymity guarantee, lets someone download
their data or delete their account) and a Settings tab (change password).

**Branding, auth, and site pages:**
- Your uploaded logo is now the app icon/favicon and appears on the login,
  signup, account, and footer screens (`frontend/public/logo-*.png`).
- **Google sign-in** — a real redirect-based OAuth flow (`/api/auth/google` →
  `/api/auth/google/callback` → back to the app), not a placeholder button.
  It stays visibly disabled with a clear label until you add
  `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` / `GOOGLE_REDIRECT_URI` — see
  the setup steps above. Signing up with email+password still works exactly
  as before either way.
- **Professional split-screen login/signup** — brand panel with the logo and
  an animated glow motif, password visibility toggle, Google button, clearer
  errors.
- **Creating a property now requires an account** (`POST /api/properties`
  is behind `requireAuth`); submitting a *review* still doesn't, by design —
  that split was the whole point of the anonymous-contribution model.
- **Footer + site pages**, Jiji-style: About Us, Terms and Conditions,
  Privacy Policy, Contact Us (a real form that lands in the admin dashboard's
  Content tab), and FAQs — all written specifically about how RentWise's
  privacy/verification model actually works, not generic placeholder text.
- **A bigger, animated hero visual** on the home screen — an enlarged,
  glowing "doorway" scene built from the logo's own motif (CSS/SVG, not a
  photo), with small floating icons for the categories RentWise scores.
  **On "real, lively images":** I deliberately didn't wire in generic stock
  photography (e.g., hotlinked Unsplash/Pexels images) for two reasons —
  those services increasingly require your own API key and rate-limit or
  license restrictions to use reliably in a shipped product, and generic
  "stock apartment" photos on a platform whose whole pitch is *real* verified
  properties risks feeling inauthentic. The real, lively images on RentWise
  are the actual property photos your users upload to each listing's public
  gallery. If you'd like a licensed stock-photo API wired in for marketing
  chrome anyway (hero backgrounds, empty states), get an API key from
  Unsplash or Pexels and I'll wire it in the same way Google's credentials
  slot in above.

**Deliberately not built yet** — these are genuinely large, separate
projects and shouldn't be rushed into the same pass as the fixes above:
- **Recency-weighted trust scoring** (the "2024: ⭐⭐, 2025: ⭐⭐⭐, 2026: ⭐⭐⭐⭐"
  model, where old reviews fade unless newer ones corroborate them). This
  needs a scoring job design, not just a UI change — the current scores are
  simple averages.
- **Ask Previous Tenants** (anonymous Q&A between a prospective tenant and
  verified former residents) — needs its own moderation model to prevent
  harassment/doxxing, per your own note.
- **Landlord/management profiles and right-of-response UI** (the API
  endpoint exists — `POST /api/reviews/:id/responses` — but there's no
  screen for it, and no neighbourhood/infrastructure data model yet).
- **AI features**: natural-language search, personalized match percentages,
  personalized recommendations from onboarding, fake-review detection
  (flag → human review → action). These need a model/provider decision and
  a design for how AI output gets logged and reviewed before it's real,
  not just a promise in the UI — the search box already says this feature
  isn't live yet rather than silently failing to parse natural language.
- **Offline-first** — a real architecture decision (service worker + local
  queue + conflict resolution), not a small addition.
- Any payment/monetization flow.

Say which of these you want next and I'll build it against this same schema.

## Project structure
```
rentwise/
├── backend/
│   ├── schema.sql              # baseline Postgres schema
│   ├── migrations/             # incremental changes (evidence, auth, photos/admin, google auth, contact, custom filters, ...)
│   ├── scripts/
│   │   ├── migrate.js          # bootstraps schema.sql, then applies new migrations
│   │   └── seed-admin.js       # npm run seed:admin -- you@email.com
│   ├── uploads/                # local dev file storage (see storage note above)
│   └── src/
│       ├── server.js
│       ├── auth.js             # JWT signing/verification + requireAuth/requireAdmin middleware
│       │                        # + the Google OAuth redirect flow
│       ├── email.js            # Resend wrapper with a console-log dev fallback
│       ├── storage.js          # local-disk / private-S3-with-signed-URLs driver
│       ├── db/pool.js
│       └── routes/{areas,properties,reviews,evidence,auth,admin,contact,filters}.js
└── frontend/
    ├── public/                 # logo/favicon assets generated from your uploaded logo
    └── src/
        ├── api.js              # all backend calls, incl. token storage, admin.*, Google redirect helper
        ├── kenyaLocations.js   # all 47 counties + their subcounties, for location filters
        ├── components/
        │   ├── LocationPicker.jsx      # click-to-pin map + "use my location"
        │   ├── PropertyMap.jsx         # read-only map on the property page
        │   ├── PropertyPhotoUploader.jsx # PUBLIC listing photo gallery + cover picker
        │   ├── EvidenceUploader.jsx    # PRIVATE review proof (photo/video/document/location/date-time)
        │   ├── SelectableOther.jsx     # chip picker where "Other" never dead-ends
        │   ├── AuthForms.jsx           # split-screen login/signup (+ Google) / forgot/reset/verify
        │   ├── StaticPages.jsx         # Footer + About/Terms/Privacy/Contact/FAQs
        │   ├── Account.jsx             # Profile / Privacy & Data / Settings
        │   └── AdminDashboard.jsx      # Analytics / Moderation / Trust & Verification / Content / Filters
        └── App.jsx              # home / create / property passport / review flow
```
