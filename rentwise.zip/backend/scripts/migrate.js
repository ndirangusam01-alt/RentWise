require("dotenv").config();
const fs = require("fs");
const path = require("path");
const { Pool } = require("pg");

async function main() {
  if (!process.env.DATABASE_URL) {
    console.error("DATABASE_URL is not set. Copy .env.example to .env and fill it in first.");
    process.exit(1);
  }
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.DATABASE_URL.includes("localhost") ? false : { rejectUnauthorized: false },
  });

  await pool.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      name TEXT PRIMARY KEY,
      applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )
  `);

  const applied = new Set(
    (await pool.query(`SELECT name FROM schema_migrations`)).rows.map(r => r.name)
  );

  // Bootstrap: run schema.sql exactly once, on a database that has no `properties` table yet.
  const tableCheck = await pool.query(`SELECT to_regclass('public.properties') AS exists`);
  if (!applied.has("000_schema.sql") && !tableCheck.rows[0].exists) {
    console.log("Applying schema.sql (initial bootstrap) ...");
    const sql = fs.readFileSync(path.join(__dirname, "..", "schema.sql"), "utf8");
    await pool.query(sql);
    await pool.query(`INSERT INTO schema_migrations (name) VALUES ('000_schema.sql')`);
    console.log("  done.");
  } else if (!applied.has("000_schema.sql")) {
    // properties table already exists from before migrations were tracked — just record it
    await pool.query(`INSERT INTO schema_migrations (name) VALUES ('000_schema.sql') ON CONFLICT DO NOTHING`);
  }

  const migrationsDir = path.join(__dirname, "..", "migrations");
  const files = fs.existsSync(migrationsDir)
    ? fs.readdirSync(migrationsDir).filter(f => f.endsWith(".sql")).sort()
    : [];

  for (const file of files) {
    if (applied.has(file)) continue;
    console.log(`Applying ${file} ...`);
    const sql = fs.readFileSync(path.join(migrationsDir, file), "utf8");
    await pool.query(sql);
    await pool.query(`INSERT INTO schema_migrations (name) VALUES ($1)`, [file]);
    console.log("  done.");
  }

  console.log("Migrations up to date.");
  await pool.end();
}

main().catch(err => {
  console.error("Migration failed:", err.message);
  process.exit(1);
});
