// Usage: npm run seed:admin -- you@example.com [a-temporary-password]
//
// Promotes an existing account to admin. If no account exists yet for that
// email, creates one (with the given password, or a random one printed to
// the console) and marks it admin immediately — handy for a brand-new
// deployment where you haven't signed up through the app yet.
require("dotenv").config();
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const { Pool } = require("pg");

async function main() {
  const email = (process.argv[2] || process.env.ADMIN_EMAIL || "").toLowerCase().trim();
  if (!email) {
    console.error("Usage: npm run seed:admin -- you@example.com [password]");
    console.error("(or set ADMIN_EMAIL in .env and run: npm run seed:admin)");
    process.exit(1);
  }
  if (!process.env.DATABASE_URL) {
    console.error("DATABASE_URL is not set. Copy .env.example to .env and fill it in first.");
    process.exit(1);
  }

  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.DATABASE_URL.includes("localhost") ? false : { rejectUnauthorized: false },
  });

  const { rows } = await pool.query("SELECT id FROM users WHERE phone_or_email = $1", [email]);

  if (rows[0]) {
    await pool.query("UPDATE users SET role = 'admin' WHERE id = $1", [rows[0].id]);
    console.log(`✓ ${email} is now an admin.`);
  } else {
    const password = process.argv[3] || crypto.randomBytes(9).toString("base64url");
    const password_hash = await bcrypt.hash(password, 10);
    await pool.query(
      `INSERT INTO users (phone_or_email, password_hash, role, email_verified)
       VALUES ($1, $2, 'admin', true)`,
      [email, password_hash]
    );
    console.log(`✓ Created a new admin account for ${email}.`);
    if (!process.argv[3]) console.log(`  Temporary password: ${password}`);
    console.log(`  Sign in and change the password from Account → Settings.`);
  }

  await pool.end();
}

main().catch((err) => {
  console.error("Seeding failed:", err.message);
  process.exit(1);
});
