-- Migration 007: admin-manageable custom filters
--
-- Lets an admin add new filterable property attributes (e.g. "Parking",
-- "Water source") from the dashboard, without a code change. Each definition
-- immediately becomes: (a) a field on the property creation form, and (b) a
-- filter control on the search page — both read this table directly.
CREATE TABLE IF NOT EXISTS filter_definitions (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key         TEXT UNIQUE NOT NULL,             -- slug, e.g. 'parking'
  label       TEXT NOT NULL,                    -- e.g. 'Parking available'
  type        TEXT NOT NULL CHECK (type IN ('boolean', 'select')),
  options     JSONB,                            -- select type only: ["Borehole","Mains/county","Tanker"]
  active      BOOLEAN NOT NULL DEFAULT true,
  position    INTEGER NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS property_filter_values (
  property_id           UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  filter_definition_id  UUID NOT NULL REFERENCES filter_definitions(id) ON DELETE CASCADE,
  value                 TEXT NOT NULL,
  PRIMARY KEY (property_id, filter_definition_id)
);
CREATE INDEX IF NOT EXISTS idx_pfv_lookup ON property_filter_values (filter_definition_id, value);

-- A few sensible defaults so the filter bar isn't empty on a fresh install —
-- admins can edit, deactivate, or add more from the dashboard at any time.
INSERT INTO filter_definitions (key, label, type, options, position) VALUES
  ('parking', 'Parking available', 'boolean', NULL, 1),
  ('furnished', 'Furnished', 'boolean', NULL, 2),
  ('pet_friendly', 'Pet friendly', 'boolean', NULL, 3),
  ('gated_community', 'Gated community', 'boolean', NULL, 4),
  ('water_source', 'Water source', 'select', '["Mains/county", "Borehole", "Tanker delivery", "Well"]', 5)
ON CONFLICT (key) DO NOTHING;

-- ---------------------------------------------------------------------------
-- Fuzzy, typo-tolerant text search (used alongside ILIKE, not instead of it).
-- ---------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE INDEX IF NOT EXISTS idx_properties_name_trgm ON properties USING gin (name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_areas_neighbourhood_trgm ON areas USING gin (neighbourhood gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_areas_estate_trgm ON areas USING gin (estate gin_trgm_ops);
