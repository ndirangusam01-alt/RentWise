-- Migration 002: evidence (photos/videos)
-- Evidence attaches to a property (general) or optionally to a specific review.
-- Evidence improves a record; it is never required to create one.

CREATE TABLE IF NOT EXISTS evidence (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id   UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  review_id     UUID REFERENCES reviews(id) ON DELETE SET NULL,
  media_type    TEXT NOT NULL CHECK (media_type IN ('photo', 'video')),
  url           TEXT NOT NULL,
  original_filename TEXT,
  caption       TEXT,
  uploaded_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_evidence_property ON evidence (property_id);
