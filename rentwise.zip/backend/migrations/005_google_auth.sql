-- Migration 005: Google sign-in
--
-- password_hash stays nullable — a Google-only account never gets one. A
-- person who signed up with email+password can also link Google later (same
-- row, google_id gets filled in); we match on email since Google's own
-- verified email is trustworthy enough to link automatically.
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS google_id TEXT UNIQUE,
  ADD COLUMN IF NOT EXISTS avatar_url TEXT;

ALTER TABLE users ALTER COLUMN password_hash DROP NOT NULL;
