-- Migration 004: admin roles, public property photo gallery, richer private evidence
--
-- Two separate concepts that were previously conflated:
--  1. `property_photos` — PUBLIC listing photos (interior/exterior) anyone can browse,
--     with one flagged as the cover image. Shown to everyone, like Jiji-style listings.
--  2. `evidence` — PRIVATE verification material attached to a review (photos, videos,
--     documents, location pins, date/time claims). Never shown publicly. Only an
--     admin can view it, to verify a reviewer's claim. This migration widens what
--     kinds of evidence can be submitted and makes the private/admin-only intent explicit.

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin'));

-- ---------------------------------------------------------------------------
-- Public property photo gallery
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS property_photos (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id         UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  url                 TEXT NOT NULL,
  area                TEXT NOT NULL DEFAULT 'exterior' CHECK (area IN ('exterior', 'interior')),
  caption             TEXT,
  is_cover            BOOLEAN NOT NULL DEFAULT false,
  position            INTEGER NOT NULL DEFAULT 0,
  uploaded_by_user_id UUID,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_property_photos_property ON property_photos (property_id);
-- Enforce a single cover photo per property at the database level.
CREATE UNIQUE INDEX IF NOT EXISTS idx_property_photos_one_cover
  ON property_photos (property_id) WHERE is_cover;

-- ---------------------------------------------------------------------------
-- Widen private review evidence: photos/videos/documents/location/date-time.
-- Some evidence types (location, date_time) carry no file at all.
-- ---------------------------------------------------------------------------
ALTER TABLE evidence
  ALTER COLUMN url DROP NOT NULL,
  ADD COLUMN IF NOT EXISTS submitted_lat DOUBLE PRECISION,
  ADD COLUMN IF NOT EXISTS submitted_lng DOUBLE PRECISION,
  ADD COLUMN IF NOT EXISTS event_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS reviewed_by_admin_id UUID,
  ADD COLUMN IF NOT EXISTS reviewed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS admin_note TEXT;

ALTER TABLE evidence DROP CONSTRAINT IF EXISTS evidence_media_type_check;
ALTER TABLE evidence ADD CONSTRAINT evidence_media_type_check
  CHECK (media_type IN ('photo', 'video', 'document', 'location', 'date_time'));

-- Note: "Other" reasons don't need a schema change — the client now appends
-- whatever free text the person types directly into the existing why_left
-- TEXT[] array, so custom reasons are stored and displayed exactly like the
-- preset ones instead of being a dead-end "Other" chip with nowhere to go.

-- ---------------------------------------------------------------------------
-- Moderation: let a report reference who filed it (optional) and give admins
-- an audit trail of who actioned it.
-- ---------------------------------------------------------------------------
ALTER TABLE reports
  ADD COLUMN IF NOT EXISTS reported_by_user_id UUID,
  ADD COLUMN IF NOT EXISTS resolved_by_admin_id UUID,
  ADD COLUMN IF NOT EXISTS resolution_note TEXT,
  ADD COLUMN IF NOT EXISTS resolved_at TIMESTAMPTZ;
