-- RentWise database schema
-- Postgres 14+. PostGIS is optional (see note on `geom` below) — the app works fully
-- on lat/lng float columns alone, so you can skip PostGIS entirely if your host doesn't offer it.

CREATE EXTENSION IF NOT EXISTS pgcrypto;      -- for gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS pg_trgm;       -- for fuzzy name matching (duplicate detection)
-- CREATE EXTENSION IF NOT EXISTS postgis;    -- uncomment if your host supports it

-- ---------------------------------------------------------------------------
-- Administrative hierarchy (country-agnostic: level1/2/3 map to whatever the
-- country uses — county/sub-county/ward in Kenya, state/county/city elsewhere)
-- ---------------------------------------------------------------------------
CREATE TABLE areas (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  country       TEXT NOT NULL DEFAULT 'Kenya',
  level1        TEXT,             -- e.g. County
  level2        TEXT,             -- e.g. Sub-county
  level3        TEXT,             -- e.g. Ward
  neighbourhood TEXT,             -- e.g. Kasarani
  estate        TEXT,             -- e.g. Mwiki / village
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_areas_search ON areas (country, level1, neighbourhood, estate);

-- ---------------------------------------------------------------------------
-- Landlords / property managers (optional claim target; not required to exist
-- before a property does)
-- ---------------------------------------------------------------------------
CREATE TABLE landlords (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  display_name    TEXT NOT NULL,
  claimed         BOOLEAN NOT NULL DEFAULT false,
  claimed_user_id UUID,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Properties are persistent entities, not posts.
-- ---------------------------------------------------------------------------
CREATE TABLE properties (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name             TEXT,                          -- optional; property may have no formal name
  area_id          UUID REFERENCES areas(id),
  landlord_id      UUID REFERENCES landlords(id),

  property_type    TEXT NOT NULL,                 -- bedsitter/single room/1BR/2BR/maisonette/SQ/other
  bedrooms         TEXT,                           -- free text: "2", "3rd floor unit", etc.
  units_in_building INTEGER,

  -- location precision is layered — every field is optional except the area link
  lat              DOUBLE PRECISION,
  lng              DOUBLE PRECISION,
  location_precision TEXT CHECK (location_precision IN ('exact_gps','approx_pin','landmark_only','description_only')),
  landmark         TEXT,
  location_description TEXT,          -- "from the main road, enter the second dirt road..."
  location_verified BOOLEAN NOT NULL DEFAULT false,

  rent_min         NUMERIC,
  rent_max         NUMERIC,
  currency         TEXT NOT NULL DEFAULT 'KES',
  rent_period      TEXT NOT NULL DEFAULT 'monthly',

  created_by_user_id UUID,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_properties_area ON properties (area_id);
CREATE INDEX idx_properties_name_trgm ON properties USING gin (name gin_trgm_ops);

-- Rent reported over time (history), separate from the property's current headline rent
CREATE TABLE rent_observations (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id  UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  amount       NUMERIC NOT NULL,
  currency     TEXT NOT NULL DEFAULT 'KES',
  observed_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  source_review_id UUID
);

-- ---------------------------------------------------------------------------
-- Reviews: structured, not free-form essays
-- ---------------------------------------------------------------------------
CREATE TABLE reviews (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id        UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  author_user_id      UUID,               -- nullable: reviews are publicly anonymous

  duration_lived     TEXT,                -- '<3 months' | '3-6 months' | ... | '2+ years'
  still_living_here  BOOLEAN NOT NULL DEFAULT false,
  why_left           TEXT[] DEFAULT '{}', -- structured reasons, e.g. {'Water problems','Noise'}
  would_rent_again    TEXT CHECK (would_rent_again IN ('Definitely','Probably','Not sure','Probably not','Never')),

  rating_water        SMALLINT CHECK (rating_water BETWEEN 1 AND 5),
  rating_electricity  SMALLINT CHECK (rating_electricity BETWEEN 1 AND 5),
  rating_security     SMALLINT CHECK (rating_security BETWEEN 1 AND 5),
  rating_noise        SMALLINT CHECK (rating_noise BETWEEN 1 AND 5),
  rating_maintenance  SMALLINT CHECK (rating_maintenance BETWEEN 1 AND 5),
  rating_internet     SMALLINT CHECK (rating_internet BETWEEN 1 AND 5),
  rating_landlord     SMALLINT CHECK (rating_landlord BETWEEN 1 AND 5),
  rating_value        SMALLINT CHECK (rating_value BETWEEN 1 AND 5),

  best_thing         TEXT,
  wish_knew           TEXT,

  verification_level TEXT NOT NULL DEFAULT 'unverified'
                        CHECK (verification_level IN ('unverified','community','verified_resident')),

  status              TEXT NOT NULL DEFAULT 'published'
                        CHECK (status IN ('published','under_review','removed')),

  created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_reviews_property ON reviews (property_id);

-- ---------------------------------------------------------------------------
-- Landlord right-of-response to a specific review
-- ---------------------------------------------------------------------------
CREATE TABLE responses (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  review_id   UUID NOT NULL REFERENCES reviews(id) ON DELETE CASCADE,
  landlord_id UUID REFERENCES landlords(id),
  body        TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Reports / disputes (moderation queue)
-- ---------------------------------------------------------------------------
CREATE TABLE reports (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  target_type  TEXT NOT NULL CHECK (target_type IN ('review','property')),
  target_id    UUID NOT NULL,
  reason       TEXT NOT NULL,             -- 'wrong_property'|'false_info'|'never_lived_there'|'pii'|'harassment'|'spam'|'other'
  details      TEXT,
  status       TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','investigating','resolved','dismissed')),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Users (minimal — full auth wiring is a phase-2 task, see README)
-- ---------------------------------------------------------------------------
CREATE TABLE users (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_or_email  TEXT UNIQUE,
  reputation      INTEGER NOT NULL DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
