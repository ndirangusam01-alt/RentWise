const express = require("express");
const multer = require("multer");
const pool = require("../db/pool");
const { driver, ALLOWED_MIME, MAX_BYTES } = require("../storage");

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_BYTES },
  fileFilter: (req, file, cb) => {
    if (!ALLOWED_MIME[file.mimetype]) {
      return cb(new Error(`Unsupported file type: ${file.mimetype}`));
    }
    cb(null, true);
  },
});

// POST /api/properties/:propertyId/evidence  (multipart/form-data, field name "file")
//
// PRIVACY: everything this endpoint stores is private verification material —
// it backs a reviewer's claim (e.g. "I have a tenancy agreement", "here's a
// photo of the flooding", "I was there on this date") and is never returned by
// any public endpoint. Only an admin, via /api/admin/evidence, can read it.
//
// Optional field "review_id" attaches this evidence to a specific review.
// Optional field "caption".
// Optional field "document_type": photo|video|document|location|date_time (default "photo").
//   - photo/video/document require a file.
//   - location requires submitted_lat + submitted_lng instead of a file.
//   - date_time requires event_at (ISO string) instead of a file.
router.post("/properties/:propertyId/evidence", (req, res) => {
  upload.single("file")(req, res, async (err) => {
    if (err) return res.status(400).json({ error: err.message });

    const { propertyId } = req.params;
    const {
      review_id, caption, document_type = "photo",
      submitted_lat, submitted_lng, event_at,
    } = req.body;

    const needsFile = ["photo", "video", "document"].includes(document_type);
    if (needsFile && !req.file) return res.status(400).json({ error: "No file uploaded" });
    if (document_type === "location" && (submitted_lat === undefined || submitted_lng === undefined)) {
      return res.status(400).json({ error: "submitted_lat and submitted_lng are required for location evidence" });
    }
    if (document_type === "date_time" && !event_at) {
      return res.status(400).json({ error: "event_at is required for date_time evidence" });
    }

    try {
      const propCheck = await pool.query("SELECT id FROM properties WHERE id = $1", [propertyId]);
      if (!propCheck.rows[0]) return res.status(404).json({ error: "Property not found" });

      let url = null, mediaType = document_type, originalFilename = null;
      if (needsFile) {
        const saved = await driver.save(req.file.buffer, req.file.originalname, req.file.mimetype);
        url = saved.ref;
        mediaType = saved.mediaType;
        originalFilename = req.file.originalname;
      }

      const { rows } = await pool.query(
        `INSERT INTO evidence
          (property_id, review_id, media_type, url, original_filename, caption,
           submitted_lat, submitted_lng, event_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
        [propertyId, review_id || null, mediaType, url, originalFilename, caption || null,
         submitted_lat ?? null, submitted_lng ?? null, event_at || null]
      );
      res.status(201).json({ ...rows[0], url: await driver.resolve(rows[0].url) });
    } catch (e) {
      console.error(e);
      res.status(500).json({ error: "Upload failed" });
    }
  });
});

module.exports = router;
