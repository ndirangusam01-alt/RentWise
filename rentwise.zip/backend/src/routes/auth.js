const express = require("express");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const pool = require("../db/pool");
const { signToken, requireAuth } = require("../auth");
const { sendVerificationEmail, sendPasswordResetEmail } = require("../email");

const router = express.Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function publicUser(u) {
  return {
    id: u.id, email: u.phone_or_email, display_name: u.display_name,
    email_verified: u.email_verified, reputation: u.reputation, role: u.role,
  };
}

// POST /api/auth/signup
router.post("/signup", async (req, res) => {
  const { email, password, display_name } = req.body;
  if (!email || !EMAIL_RE.test(email)) return res.status(400).json({ error: "A valid email is required" });
  if (!password || password.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters" });

  try {
    const existing = await pool.query("SELECT id FROM users WHERE phone_or_email = $1", [email.toLowerCase()]);
    if (existing.rows[0]) return res.status(409).json({ error: "An account with this email already exists" });

    const password_hash = await bcrypt.hash(password, 10);
    const verification_token = crypto.randomBytes(32).toString("hex");
    const verification_token_expires = new Date(Date.now() + 24 * 60 * 60 * 1000);

    const { rows } = await pool.query(
      `INSERT INTO users (phone_or_email, password_hash, display_name, verification_token, verification_token_expires)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [email.toLowerCase(), password_hash, display_name || null, verification_token, verification_token_expires]
    );
    const user = rows[0];

    await sendVerificationEmail(user.phone_or_email, verification_token);

    const token = signToken(user);
    res.status(201).json({ token, user: publicUser(user) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Signup failed" });
  }
});

// POST /api/auth/login
router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: "Email and password are required" });

  try {
    const { rows } = await pool.query("SELECT * FROM users WHERE phone_or_email = $1", [email.toLowerCase()]);
    const user = rows[0];
    if (!user || !user.password_hash) return res.status(401).json({ error: "Invalid email or password" });

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: "Invalid email or password" });

    const token = signToken(user);
    res.json({ token, user: publicUser(user) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Login failed" });
  }
});

// GET /api/auth/verify-email?token=...
router.get("/verify-email", async (req, res) => {
  const { token } = req.query;
  if (!token) return res.status(400).json({ error: "Missing token" });
  try {
    const { rows } = await pool.query(
      `SELECT id FROM users WHERE verification_token = $1 AND verification_token_expires > now()`,
      [token]
    );
    if (!rows[0]) return res.status(400).json({ error: "This verification link is invalid or has expired" });

    await pool.query(
      `UPDATE users SET email_verified = true, verification_token = NULL, verification_token_expires = NULL, updated_at = now()
       WHERE id = $1`,
      [rows[0].id]
    );
    res.json({ verified: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Verification failed" });
  }
});

// POST /api/auth/resend-verification  { email }
router.post("/resend-verification", async (req, res) => {
  const { email } = req.body;
  try {
    const { rows } = await pool.query("SELECT * FROM users WHERE phone_or_email = $1", [(email || "").toLowerCase()]);
    const user = rows[0];
    // Always respond success even if not found, so this endpoint can't be used to enumerate accounts.
    if (!user || user.email_verified) return res.json({ sent: true });

    const verification_token = crypto.randomBytes(32).toString("hex");
    const verification_token_expires = new Date(Date.now() + 24 * 60 * 60 * 1000);
    await pool.query(
      `UPDATE users SET verification_token = $1, verification_token_expires = $2 WHERE id = $3`,
      [verification_token, verification_token_expires, user.id]
    );
    await sendVerificationEmail(user.phone_or_email, verification_token);
    res.json({ sent: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not resend verification email" });
  }
});

// POST /api/auth/forgot-password  { email }
router.post("/forgot-password", async (req, res) => {
  const { email } = req.body;
  try {
    const { rows } = await pool.query("SELECT * FROM users WHERE phone_or_email = $1", [(email || "").toLowerCase()]);
    const user = rows[0];
    if (user) {
      const reset_token = crypto.randomBytes(32).toString("hex");
      const reset_token_expires = new Date(Date.now() + 60 * 60 * 1000);
      await pool.query(`UPDATE users SET reset_token = $1, reset_token_expires = $2 WHERE id = $3`, [reset_token, reset_token_expires, user.id]);
      await sendPasswordResetEmail(user.phone_or_email, reset_token);
    }
    // Same response whether or not the account exists — don't leak which emails are registered.
    res.json({ sent: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not process password reset" });
  }
});

// POST /api/auth/reset-password  { token, password }
router.post("/reset-password", async (req, res) => {
  const { token, password } = req.body;
  if (!password || password.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters" });
  try {
    const { rows } = await pool.query(
      `SELECT id FROM users WHERE reset_token = $1 AND reset_token_expires > now()`,
      [token]
    );
    if (!rows[0]) return res.status(400).json({ error: "This reset link is invalid or has expired" });

    const password_hash = await bcrypt.hash(password, 10);
    await pool.query(
      `UPDATE users SET password_hash = $1, reset_token = NULL, reset_token_expires = NULL, updated_at = now() WHERE id = $2`,
      [password_hash, rows[0].id]
    );
    res.json({ reset: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Password reset failed" });
  }
});

// GET /api/auth/me
router.get("/me", requireAuth, async (req, res) => {
  try {
    const { rows } = await pool.query("SELECT * FROM users WHERE id = $1", [req.user.sub]);
    if (!rows[0]) return res.status(404).json({ error: "User not found" });
    res.json(publicUser(rows[0]));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load profile" });
  }
});

// PATCH /api/auth/me  { display_name }
router.patch("/me", requireAuth, async (req, res) => {
  const { display_name } = req.body;
  try {
    const { rows } = await pool.query(
      `UPDATE users SET display_name = $1, updated_at = now() WHERE id = $2 RETURNING *`,
      [display_name || null, req.user.sub]
    );
    res.json(publicUser(rows[0]));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Update failed" });
  }
});

// POST /api/auth/change-password  { current_password, new_password }
router.post("/change-password", requireAuth, async (req, res) => {
  const { current_password, new_password } = req.body;
  if (!new_password || new_password.length < 8) return res.status(400).json({ error: "New password must be at least 8 characters" });
  try {
    const { rows } = await pool.query("SELECT * FROM users WHERE id = $1", [req.user.sub]);
    const user = rows[0];
    if (!user || !user.password_hash) return res.status(400).json({ error: "This account has no password set" });
    const ok = await bcrypt.compare(current_password || "", user.password_hash);
    if (!ok) return res.status(401).json({ error: "Current password is incorrect" });
    const password_hash = await bcrypt.hash(new_password, 10);
    await pool.query("UPDATE users SET password_hash = $1, updated_at = now() WHERE id = $2", [password_hash, user.id]);
    res.json({ changed: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not change password" });
  }
});

// GET /api/auth/export-data — everything tied to this account, for the person's own records.
// Reviews are included because they're the account's content, even though they're
// displayed publicly with no name attached.
router.get("/export-data", requireAuth, async (req, res) => {
  try {
    const [userRes, reviewsRes] = await Promise.all([
      pool.query("SELECT id, phone_or_email, display_name, email_verified, reputation, created_at FROM users WHERE id = $1", [req.user.sub]),
      pool.query("SELECT * FROM reviews WHERE author_user_id = $1 ORDER BY created_at DESC", [req.user.sub]),
    ]);
    if (!userRes.rows[0]) return res.status(404).json({ error: "User not found" });
    res.json({ account: userRes.rows[0], reviews: reviewsRes.rows, exported_at: new Date().toISOString() });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not export data" });
  }
});

// DELETE /api/auth/me — deletes the account. Reviews already carry no name or
// email, so they stay on the record as anonymous contributions (the whole
// point of the anonymous-by-design model) but are unlinked from the account.
router.delete("/me", requireAuth, async (req, res) => {
  try {
    await pool.query("UPDATE reviews SET author_user_id = NULL WHERE author_user_id = $1", [req.user.sub]);
    await pool.query("DELETE FROM users WHERE id = $1", [req.user.sub]);
    res.json({ deleted: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not delete account" });
  }
});

// ---------------------------------------------------------------------------
// Google sign-in (OAuth 2.0 authorization-code flow, popup-based).
//
// Frontend does a full-page navigation to GET /api/auth/google (no popup).
// Google redirects back to GET /api/auth/google/callback with a code; we
// exchange it server-side for an access token (client secret never touches
// the browser), fetch the person's Google profile, find-or-create their
// RentWise account, and redirect back into the app with a short-lived,
// single-use handoff code in the URL — never the JWT itself, since URLs end
// up in browser history and server logs.
//
// (An earlier version of this used a popup + window.postMessage. That broke
// in real browsers: Google's own accounts.google.com sets a
// Cross-Origin-Opener-Policy header that severs the popup from its opener's
// browsing-context group, so `window.opener` goes null by the time our own
// callback page runs — through no fault of our code. A plain redirect has no
// popup/opener relationship to sever, so this class of bug can't happen here.)
//
// Needs GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, and GOOGLE_REDIRECT_URI
// (must exactly match a redirect URI registered in the Google Cloud Console,
// e.g. https://api.yourrentwise.com/api/auth/google/callback) in the
// backend's .env. Until those are set, both routes below reply with a clear
// 503 instead of a confusing crash, so the rest of the app keeps working.
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || "http://localhost:5173";

// In-memory, single-use, 60-second handoff codes. A short-lived in-memory map
// is fine here — if the backend restarts mid-handoff the person just retries
// sign-in, and nothing else depends on this surviving a restart.
const pendingGoogleAuth = new Map();
function issueHandoffCode(payload) {
  const code = crypto.randomBytes(24).toString("hex");
  pendingGoogleAuth.set(code, payload);
  setTimeout(() => pendingGoogleAuth.delete(code), 60_000);
  return code;
}

function googleConfigured() {
  return !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET && process.env.GOOGLE_REDIRECT_URI);
}

router.get("/google", (req, res) => {
  if (!googleConfigured()) {
    return res.status(503).send("Google sign-in isn't configured yet — set GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, and GOOGLE_REDIRECT_URI on the backend.");
  }
  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID,
    redirect_uri: process.env.GOOGLE_REDIRECT_URI,
    response_type: "code",
    scope: "openid email profile",
    prompt: "select_account",
  });
  res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`);
});

router.get("/google/callback", async (req, res) => {
  function backToApp(payload) {
    const code = issueHandoffCode(payload);
    res.redirect(`${FRONTEND_ORIGIN}/?google_auth=${code}`);
  }

  if (!googleConfigured()) return backToApp({ error: "Google sign-in isn't configured yet." });

  const { code, error: googleError } = req.query;
  if (googleError) return backToApp({ error: "Google sign-in was cancelled." });
  if (!code) return backToApp({ error: "Missing authorization code from Google." });

  try {
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: process.env.GOOGLE_CLIENT_ID,
        client_secret: process.env.GOOGLE_CLIENT_SECRET,
        redirect_uri: process.env.GOOGLE_REDIRECT_URI,
        grant_type: "authorization_code",
      }),
    });
    const tokenData = await tokenRes.json();
    if (!tokenRes.ok || !tokenData.access_token) {
      console.error("Google token exchange failed:", tokenData);
      return backToApp({ error: "Google sign-in failed during token exchange." });
    }

    const profileRes = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });
    const profile = await profileRes.json();
    if (!profile.email) return backToApp({ error: "Google didn't share an email address." });

    const email = profile.email.toLowerCase();
    let { rows } = await pool.query("SELECT * FROM users WHERE google_id = $1 OR phone_or_email = $2", [profile.sub, email]);
    let user = rows[0];

    if (!user) {
      const inserted = await pool.query(
        `INSERT INTO users (phone_or_email, google_id, display_name, avatar_url, email_verified)
         VALUES ($1,$2,$3,$4,$5) RETURNING *`,
        [email, profile.sub, profile.name || null, profile.picture || null, !!profile.email_verified]
      );
      user = inserted.rows[0];
    } else if (!user.google_id) {
      // Same email as an existing password account — link Google to it rather than duplicating.
      const updated = await pool.query(
        `UPDATE users SET google_id = $1, avatar_url = COALESCE(avatar_url, $2),
           email_verified = email_verified OR $3 WHERE id = $4 RETURNING *`,
        [profile.sub, profile.picture || null, !!profile.email_verified, user.id]
      );
      user = updated.rows[0];
    }

    const token = signToken(user);
    backToApp({ token, user: publicUser(user) });
  } catch (err) {
    console.error(err);
    backToApp({ error: "Google sign-in failed unexpectedly." });
  }
});

// GET /api/auth/google/exchange?code=... — the frontend calls this once,
// immediately on load, to trade the one-time handoff code for the real
// token+user payload. The code is deleted the instant it's read, so a code
// sitting in browser history after the redirect is already worthless.
router.get("/google/exchange", (req, res) => {
  const { code } = req.query;
  const payload = code && pendingGoogleAuth.get(code);
  if (!payload) return res.status(400).json({ error: "This sign-in link has expired or was already used." });
  pendingGoogleAuth.delete(code);
  if (payload.error) return res.status(400).json({ error: payload.error });
  res.json(payload);
});

module.exports = router;
module.exports.googleConfigured = googleConfigured;

// GET /api/auth/google/status — lets the frontend know whether to show the
// Google button as active or as "coming soon" without guessing from a failed click.
router.get("/google/status", (req, res) => res.json({ enabled: googleConfigured() }));
