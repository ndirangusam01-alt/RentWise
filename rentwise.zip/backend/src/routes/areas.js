const express = require("express");
const pool = require("../db/pool");

const router = express.Router();

// GET /api/areas?q=kasarani — used for area autocomplete when documenting a property
router.get("/", async (req, res) => {
  const { q = "", country = "Kenya" } = req.query;
  try {
    const { rows } = await pool.query(
      `SELECT id, country, level1, level2, level3, neighbourhood, estate
       FROM areas
       WHERE country = $1
         AND (
           neighbourhood ILIKE '%' || $2 || '%' OR
           estate ILIKE '%' || $2 || '%' OR
           level1 ILIKE '%' || $2 || '%'
         )
       ORDER BY neighbourhood NULLS LAST
       LIMIT 15`,
      [country, q]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to search areas" });
  }
});

// POST /api/areas — find-or-create so we don't spawn duplicate area rows
router.post("/", async (req, res) => {
  const { country = "Kenya", level1, level2, level3, neighbourhood, estate } = req.body;
  try {
    const existing = await pool.query(
      `SELECT id FROM areas
       WHERE country = $1 AND coalesce(level1,'') = coalesce($2,'')
         AND coalesce(level2,'') = coalesce($3,'')
         AND coalesce(neighbourhood,'') = coalesce($4,'')
         AND coalesce(estate,'') = coalesce($5,'')
       LIMIT 1`,
      [country, level1, level2, neighbourhood, estate]
    );
    if (existing.rows[0]) return res.json(existing.rows[0]);

    const { rows } = await pool.query(
      `INSERT INTO areas (country, level1, level2, level3, neighbourhood, estate)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [country, level1, level2, level3, neighbourhood, estate]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create area" });
  }
});

module.exports = router;
