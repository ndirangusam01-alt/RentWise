const express = require("express");
const pool = require("../db/pool");
const { requireAuth } = require("../auth");
const { driver, resolveMany, ALLOWED_MIME, MAX_BYTES } = require("../storage");

const router = express.Router();

const RATING_FIELDS = ["water", "electricity", "security", "noise", "maintenance", "internet", "landlord", "value"];

// GET /api/properties/duplicates?name=&area_id=&landmark=
// Called BEFORE creating a property so the client can offer "is this the same place?"
router.get("/duplicates", async (req, res) => {
  const { name = "", area_id, landmark = "" } = req.query;
  if (!area_id) return res.json([]);
  try {
    const { rows } = await pool.query(
      `SELECT id, name, landmark, property_type, rent_min, rent_max,
              similarity(coalesce(name,''), $2) AS name_sim
       FROM properties
       WHERE area_id = $1
         AND (
           ($2 <> '' AND similarity(coalesce(name,''), $2) > 0.25)
           OR ($3 <> '' AND landmark ILIKE '%' || $3 || '%')
           OR ($2 = '' AND $3 = '')
         )
       ORDER BY name_sim DESC NULLS LAST
       LIMIT 5`,
      [area_id, name, landmark]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Duplicate search failed" });
  }
});

// POST /api/properties — create a new property record. Requires a signed-in
// account (per product decision: no anonymous listings) — the reviews on top
// of it can still be posted anonymously, that's a separate, deliberate rule.
router.post("/", requireAuth, async (req, res) => {
  const {
    name, area_id, property_type, bedrooms, units_in_building,
    lat, lng, location_precision, landmark, location_description,
    rent_min, rent_max, currency = "KES",
  } = req.body;

  if (!area_id || !property_type) {
    return res.status(400).json({ error: "area_id and property_type are required" });
  }

  try {
    const { rows } = await pool.query(
      `INSERT INTO properties
        (name, area_id, property_type, bedrooms, units_in_building, lat, lng,
         location_precision, landmark, location_description, rent_min, rent_max, currency,
         created_by_user_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
       RETURNING *`,
      [name || null, area_id, property_type, bedrooms || null, units_in_building || null,
       lat || null, lng || null, location_precision || "landmark_only", landmark || null,
       location_description || null, rent_min || null, rent_max || null, currency,
       req.user.sub]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create property" });
  }
});

// POST /api/properties/:id/filter-values  { values: { parking: "true", water_source: "Borehole" } }
// Bulk-sets this property's answers to whichever custom filters are
// currently active — called right after property creation. Unknown or
// inactive filter keys are silently ignored rather than erroring, so a
// filter an admin later deactivates doesn't break existing submissions.
router.post("/:id/filter-values", requireAuth, async (req, res) => {
  const { id } = req.params;
  const values = req.body?.values || {};
  const keys = Object.keys(values);
  if (keys.length === 0) return res.json({ saved: 0 });
  try {
    const { rows: defs } = await pool.query(
      `SELECT id, key FROM filter_definitions WHERE key = ANY($1) AND active = true`, [keys]
    );
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      for (const def of defs) {
        const value = values[def.key];
        if (value === undefined || value === null || value === "") continue;
        await client.query(
          `INSERT INTO property_filter_values (property_id, filter_definition_id, value)
           VALUES ($1,$2,$3)
           ON CONFLICT (property_id, filter_definition_id) DO UPDATE SET value = EXCLUDED.value`,
          [id, def.id, String(value)]
        );
      }
      await client.query("COMMIT");
    } catch (e) {
      await client.query("ROLLBACK");
      throw e;
    } finally {
      client.release();
    }
    res.json({ saved: defs.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to save filter values" });
  }
});

// GET /api/properties?q=&county=&subcounty=&type=&bedrooms=&minRent=&maxRent=&verifiedOnly=&sort=&limit=&custom_<key>=
// sort: "recent" (default) | "most_reviewed" | "price_asc" | "price_desc"
// Text search combines a plain substring match (ILIKE, case-insensitive) with
// pg_trgm similarity, so a small typo ("kasarni") still finds "Kasarani"
// instead of returning nothing.
router.get("/", async (req, res) => {
  const {
    q = "", county, subcounty, type, bedrooms, minRent, maxRent,
    verifiedOnly, sort = "recent", limit = 30, ...rest
  } = req.query;
  try {
    const conditions = [];
    const params = [];
    if (q.trim()) {
      params.push(q.trim());
      const i = params.length;
      conditions.push(
        `(p.name ILIKE '%' || $${i} || '%' OR a.neighbourhood ILIKE '%' || $${i} || '%' OR a.estate ILIKE '%' || $${i} || '%'
          OR similarity(coalesce(p.name,''), $${i}) > 0.3
          OR similarity(coalesce(a.neighbourhood,''), $${i}) > 0.3
          OR similarity(coalesce(a.estate,''), $${i}) > 0.3)`
      );
    }
    if (county) { params.push(county); conditions.push(`a.level1 = $${params.length}`); }
    if (subcounty) { params.push(subcounty); conditions.push(`a.level2 = $${params.length}`); }
    if (type) { params.push(type); conditions.push(`p.property_type = $${params.length}`); }
    if (bedrooms) { params.push(bedrooms); conditions.push(`p.bedrooms = $${params.length}`); }
    if (minRent) { params.push(minRent); conditions.push(`p.rent_max >= $${params.length}`); }
    if (maxRent) { params.push(maxRent); conditions.push(`p.rent_min <= $${params.length}`); }
    if (verifiedOnly === "true") {
      conditions.push(`EXISTS (SELECT 1 FROM reviews r WHERE r.property_id = p.id AND r.status = 'published' AND r.verification_level = 'verified_resident')`);
    }

    // Admin-defined custom filters arrive as custom_<key>=<value>. Each one
    // that's actually present in the query string becomes its own EXISTS
    // clause against property_filter_values, so a property must match every
    // custom filter the person set, not just one of them.
    for (const [qKey, qVal] of Object.entries(rest)) {
      if (!qKey.startsWith("custom_") || qVal === "" || qVal === undefined) continue;
      const key = qKey.slice("custom_".length);
      params.push(key);
      const keyIdx = params.length;
      params.push(qVal);
      const valIdx = params.length;
      conditions.push(
        `EXISTS (
           SELECT 1 FROM property_filter_values pfv
           JOIN filter_definitions fd ON fd.id = pfv.filter_definition_id
           WHERE pfv.property_id = p.id AND fd.key = $${keyIdx} AND pfv.value = $${valIdx}
         )`
      );
    }

    const where = conditions.length ? conditions.join(" AND ") : "TRUE";
    params.push(limit);

    const orderBy = {
      most_reviewed: "review_count DESC, p.created_at DESC",
      price_asc: "p.rent_min ASC NULLS LAST, p.created_at DESC",
      price_desc: "p.rent_max DESC NULLS LAST, p.created_at DESC",
    }[sort] || "p.created_at DESC";

    const { rows } = await pool.query(
      `SELECT p.id, p.name, p.property_type, p.bedrooms, p.rent_min, p.rent_max, p.currency,
              p.created_at, a.level1 AS county, a.level2 AS subcounty, a.neighbourhood AS area, a.estate,
              (SELECT COUNT(*) FROM reviews r WHERE r.property_id = p.id AND r.status = 'published') AS review_count,
              (SELECT COUNT(*) FROM reviews r WHERE r.property_id = p.id AND r.status = 'published' AND r.verification_level = 'verified_resident') AS verified_review_count,
              (SELECT url FROM property_photos pp WHERE pp.property_id = p.id AND pp.is_cover LIMIT 1) AS cover_photo_url
       FROM properties p
       LEFT JOIN areas a ON a.id = p.area_id
       WHERE ${where}
       ORDER BY ${orderBy}
       LIMIT $${params.length}`,
      params
    );
    const withResolvedCovers = await Promise.all(
      rows.map(async (r) => ({ ...r, cover_photo_url: await driver.resolve(r.cover_photo_url) }))
    );
    res.json(withResolvedCovers);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Search failed" });
  }
});

// GET /api/properties/:id — the full "property passport": scores, issue frequency,
// rent history, and reviews, all computed live from the reviews table.
router.get("/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const propRes = await pool.query(
      `SELECT p.*, a.country, a.level1 AS county, a.level2, a.level3,
              a.neighbourhood AS area, a.estate
       FROM properties p LEFT JOIN areas a ON a.id = p.area_id
       WHERE p.id = $1`,
      [id]
    );
    if (!propRes.rows[0]) return res.status(404).json({ error: "Property not found" });

    const scoreSelect = RATING_FIELDS
      .map(f => `AVG(rating_${f})::numeric(3,2) AS ${f}_avg, COUNT(rating_${f}) AS ${f}_n`)
      .join(", ");
    const scoreRes = await pool.query(
      `SELECT ${scoreSelect}, COUNT(*) AS total_reviews
       FROM reviews WHERE property_id = $1 AND status = 'published'`,
      [id]
    );

    const issueRes = await pool.query(
      `SELECT reason, COUNT(*) AS count
       FROM (SELECT unnest(why_left) AS reason FROM reviews WHERE property_id = $1 AND status = 'published') t
       GROUP BY reason ORDER BY count DESC LIMIT 6`,
      [id]
    );

    const reviewsRes = await pool.query(
      `SELECT id, duration_lived, still_living_here, why_left, would_rent_again,
              rating_water, rating_electricity, rating_security, rating_noise,
              rating_maintenance, rating_internet, rating_landlord, rating_value,
              best_thing, wish_knew, verification_level, created_at
       FROM reviews WHERE property_id = $1 AND status = 'published'
       ORDER BY created_at DESC LIMIT 50`,
      [id]
    );

    const rentHistoryRes = await pool.query(
      `SELECT amount, currency, observed_at FROM rent_observations
       WHERE property_id = $1 ORDER BY observed_at ASC`,
      [id]
    );

    // PUBLIC photo gallery only — private review evidence (verification photos,
    // documents, location/date claims) deliberately never appears in this
    // response. Admins read that separately via /api/admin/evidence.
    const photosRes = await pool.query(
      `SELECT id, url, area, caption, is_cover, position
       FROM property_photos WHERE property_id = $1 ORDER BY is_cover DESC, position ASC, created_at ASC`,
      [id]
    );

    const filterValuesRes = await pool.query(
      `SELECT fd.key, fd.label, fd.type, pfv.value
       FROM property_filter_values pfv
       JOIN filter_definitions fd ON fd.id = pfv.filter_definition_id
       WHERE pfv.property_id = $1 AND fd.active = true`,
      [id]
    );

    const scores = scoreRes.rows[0];
    const total = Number(scores.total_reviews) || 0;
    const categoryScores = {};
    RATING_FIELDS.forEach(f => {
      const avg = scores[`${f}_avg`];
      const n = Number(scores[`${f}_n`]) || 0;
      categoryScores[f] = {
        average: avg === null ? null : Number(avg),
        sampleSize: n,
        confidence: n >= 10 ? "High" : n >= 3 ? "Medium" : "Low",
      };
    });

    res.json({
      property: propRes.rows[0],
      reviewCount: total,
      categoryScores,
      frequentlyReported: issueRes.rows.map(r => ({
        reason: r.reason,
        count: Number(r.count),
        pct: total ? Math.round((Number(r.count) / total) * 100) : 0,
      })),
      reviews: reviewsRes.rows,
      rentHistory: rentHistoryRes.rows,
      photos: await resolveMany(photosRes.rows, "url"),
      amenities: filterValuesRes.rows,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load property" });
  }
});

// ---------------------------------------------------------------------------
// Public property photo gallery (exterior/interior). Distinct from the
// private review evidence in routes/evidence.js — these are meant to be seen
// by everyone browsing a listing, like the photo grid on Jiji.
// ---------------------------------------------------------------------------
const multer = require("multer");
const photoUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_BYTES },
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith("image/")) return cb(new Error("Listing photos must be images"));
    if (!ALLOWED_MIME[file.mimetype]) return cb(new Error(`Unsupported file type: ${file.mimetype}`));
    cb(null, true);
  },
});

// POST /api/properties/:id/photos  (multipart/form-data, field "file")
// Optional fields: "area" (exterior|interior, default exterior), "caption",
// "is_cover" ("true" to make this the listing's cover photo immediately).
router.post("/:id/photos", (req, res) => {
  photoUpload.single("file")(req, res, async (err) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });
    const { id } = req.params;
    const { area = "exterior", caption, is_cover } = req.body;
    try {
      const propCheck = await pool.query("SELECT id FROM properties WHERE id = $1", [id]);
      if (!propCheck.rows[0]) return res.status(404).json({ error: "Property not found" });

      const { ref } = await driver.save(req.file.buffer, req.file.originalname, req.file.mimetype);
      const { rows: countRows } = await pool.query("SELECT COUNT(*) FROM property_photos WHERE property_id = $1", [id]);
      const makeCover = is_cover === "true" || Number(countRows[0].count) === 0; // first photo becomes the cover automatically

      const client = await pool.connect();
      try {
        await client.query("BEGIN");
        if (makeCover) {
          await client.query("UPDATE property_photos SET is_cover = false WHERE property_id = $1", [id]);
        }
        const { rows } = await client.query(
          `INSERT INTO property_photos (property_id, url, area, caption, is_cover, position)
           VALUES ($1,$2,$3,$4,$5,(SELECT COALESCE(MAX(position),-1)+1 FROM property_photos WHERE property_id = $1))
           RETURNING *`,
          [id, ref, area, caption || null, makeCover]
        );
        await client.query("COMMIT");
        res.status(201).json({ ...rows[0], url: await driver.resolve(rows[0].url) });
      } catch (e) {
        await client.query("ROLLBACK");
        throw e;
      } finally {
        client.release();
      }
    } catch (e) {
      console.error(e);
      res.status(500).json({ error: "Upload failed" });
    }
  });
});

// PATCH /api/properties/:id/photos/:photoId/cover — pick which photo represents the listing
router.patch("/:id/photos/:photoId/cover", async (req, res) => {
  const { id, photoId } = req.params;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("UPDATE property_photos SET is_cover = false WHERE property_id = $1", [id]);
    const { rows } = await client.query(
      "UPDATE property_photos SET is_cover = true WHERE id = $1 AND property_id = $2 RETURNING *",
      [photoId, id]
    );
    if (!rows[0]) { await client.query("ROLLBACK"); return res.status(404).json({ error: "Photo not found" }); }
    await client.query("COMMIT");
    res.json(rows[0]);
  } catch (e) {
    await client.query("ROLLBACK");
    console.error(e);
    res.status(500).json({ error: "Failed to set cover photo" });
  } finally {
    client.release();
  }
});

// DELETE /api/properties/:id/photos/:photoId
router.delete("/:id/photos/:photoId", async (req, res) => {
  const { id, photoId } = req.params;
  try {
    const { rows } = await pool.query(
      "DELETE FROM property_photos WHERE id = $1 AND property_id = $2 RETURNING id, is_cover",
      [photoId, id]
    );
    if (!rows[0]) return res.status(404).json({ error: "Photo not found" });
    if (rows[0].is_cover) {
      // Promote the next photo in line so a listing is never left without a cover.
      await pool.query(
        `UPDATE property_photos SET is_cover = true WHERE id = (
           SELECT id FROM property_photos WHERE property_id = $1 ORDER BY position ASC LIMIT 1
         )`,
        [id]
      );
    }
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Failed to delete photo" });
  }
});

module.exports = router;
