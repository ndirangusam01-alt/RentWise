const express = require("express");
const pool = require("../db/pool");
const { requireAdmin } = require("../auth");
const { resolveMany } = require("../storage");

const router = express.Router();

// Every route below requires a valid admin account. See auth.js#requireAdmin —
// role is checked against the database on every request, not trusted from the JWT.
router.use(requireAdmin);

// ---------------------------------------------------------------------------
// Analytics — top-line numbers for the dashboard landing tab.
// ---------------------------------------------------------------------------
router.get("/stats", async (req, res) => {
  try {
    const [properties, reviews, verifiedReviews, pendingReviews, openReports, users, photos] = await Promise.all([
      pool.query("SELECT COUNT(*) FROM properties"),
      pool.query("SELECT COUNT(*) FROM reviews WHERE status = 'published'"),
      pool.query("SELECT COUNT(*) FROM reviews WHERE status = 'published' AND verification_level = 'verified_resident'"),
      pool.query("SELECT COUNT(*) FROM reviews WHERE status = 'under_review'"),
      pool.query("SELECT COUNT(*) FROM reports WHERE status IN ('open','investigating')"),
      pool.query("SELECT COUNT(*) FROM users"),
      pool.query("SELECT COUNT(*) FROM property_photos"),
    ]);
    res.json({
      properties: Number(properties.rows[0].count),
      publishedReviews: Number(reviews.rows[0].count),
      verifiedReviews: Number(verifiedReviews.rows[0].count),
      pendingReviews: Number(pendingReviews.rows[0].count),
      openReports: Number(openReports.rows[0].count),
      users: Number(users.rows[0].count),
      photos: Number(photos.rows[0].count),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load stats" });
  }
});

// ---------------------------------------------------------------------------
// Moderation — flagged reviews and disputes.
// ---------------------------------------------------------------------------
router.get("/reports", async (req, res) => {
  const { status } = req.query;
  try {
    const params = [];
    let where = "";
    if (status) { params.push(status); where = `WHERE r.status = $${params.length}`; }
    const { rows } = await pool.query(
      `SELECT r.*, rv.property_id, rv.best_thing, rv.status AS review_status, p.name AS property_name
       FROM reports r
       LEFT JOIN reviews rv ON r.target_type = 'review' AND rv.id = r.target_id
       LEFT JOIN properties p ON p.id = COALESCE(rv.property_id, CASE WHEN r.target_type = 'property' THEN r.target_id END)
       ${where}
       ORDER BY r.created_at DESC`,
      params
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load reports" });
  }
});

// PATCH /api/admin/reports/:id  { status, resolution_note }
router.patch("/reports/:id", async (req, res) => {
  const { id } = req.params;
  const { status, resolution_note } = req.body;
  const valid = ["open", "investigating", "resolved", "dismissed"];
  if (!valid.includes(status)) return res.status(400).json({ error: "Invalid status" });
  try {
    const { rows } = await pool.query(
      `UPDATE reports SET status = $1, resolution_note = $2, resolved_by_admin_id = $3,
         resolved_at = CASE WHEN $1 IN ('resolved','dismissed') THEN now() ELSE NULL END
       WHERE id = $4 RETURNING *`,
      [status, resolution_note || null, req.user.sub, id]
    );
    if (!rows[0]) return res.status(404).json({ error: "Report not found" });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update report" });
  }
});

// GET /api/admin/reviews?status=under_review — moderation queue (also usable for any status)
router.get("/reviews", async (req, res) => {
  const { status = "under_review", propertyId } = req.query;
  try {
    const params = [status];
    let extra = "";
    if (propertyId) { params.push(propertyId); extra = `AND rv.property_id = $${params.length}`; }
    const { rows } = await pool.query(
      `SELECT rv.*, p.name AS property_name, u.phone_or_email AS author_contact
       FROM reviews rv
       LEFT JOIN properties p ON p.id = rv.property_id
       LEFT JOIN users u ON u.id = rv.author_user_id
       WHERE rv.status = $1 ${extra}
       ORDER BY rv.created_at DESC`,
      params
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load reviews" });
  }
});

// PATCH /api/admin/reviews/:id  { status: 'published' | 'removed' | 'under_review' }
router.patch("/reviews/:id", async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const valid = ["published", "removed", "under_review"];
  if (!valid.includes(status)) return res.status(400).json({ error: "Invalid status" });
  try {
    const { rows } = await pool.query(
      "UPDATE reviews SET status = $1 WHERE id = $2 RETURNING *",
      [status, id]
    );
    if (!rows[0]) return res.status(404).json({ error: "Review not found" });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update review" });
  }
});

// ---------------------------------------------------------------------------
// Trust & verification — the private evidence backing reviewers' claims.
// Never exposed on any public endpoint; this is the only place it's readable.
// ---------------------------------------------------------------------------
router.get("/evidence", async (req, res) => {
  const { propertyId, reviewId } = req.query;
  try {
    const conditions = [];
    const params = [];
    if (propertyId) { params.push(propertyId); conditions.push(`e.property_id = $${params.length}`); }
    if (reviewId) { params.push(reviewId); conditions.push(`e.review_id = $${params.length}`); }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const { rows } = await pool.query(
      `SELECT e.*, p.name AS property_name
       FROM evidence e LEFT JOIN properties p ON p.id = e.property_id
       ${where}
       ORDER BY e.uploaded_at DESC`,
      params
    );
    res.json(await resolveMany(rows, "url"));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load evidence" });
  }
});

// PATCH /api/admin/evidence/:id  { admin_note } — mark evidence as reviewed, with a note
router.patch("/evidence/:id", async (req, res) => {
  const { id } = req.params;
  const { admin_note } = req.body;
  try {
    const { rows } = await pool.query(
      `UPDATE evidence SET admin_note = $1, reviewed_by_admin_id = $2, reviewed_at = now()
       WHERE id = $3 RETURNING *`,
      [admin_note || null, req.user.sub, id]
    );
    if (!rows[0]) return res.status(404).json({ error: "Evidence not found" });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update evidence" });
  }
});

// One-stop screening view for a single property: its reviews (any status) plus
// every piece of private evidence, so an admin can verify claims in one place.
router.get("/properties/:id/verification", async (req, res) => {
  const { id } = req.params;
  try {
    const [property, reviews, evidence] = await Promise.all([
      pool.query("SELECT * FROM properties WHERE id = $1", [id]),
      pool.query("SELECT * FROM reviews WHERE property_id = $1 ORDER BY created_at DESC", [id]),
      pool.query("SELECT * FROM evidence WHERE property_id = $1 ORDER BY uploaded_at DESC", [id]),
    ]);
    if (!property.rows[0]) return res.status(404).json({ error: "Property not found" });
    res.json({ property: property.rows[0], reviews: reviews.rows, evidence: await resolveMany(evidence.rows, "url") });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load verification view" });
  }
});

// ---------------------------------------------------------------------------
// Contributor reliability — light user lookup, for correlating an author
// across reviews during an investigation. No password data is ever returned.
// ---------------------------------------------------------------------------
router.get("/users", async (req, res) => {
  const { q = "" } = req.query;
  try {
    const { rows } = await pool.query(
      `SELECT id, phone_or_email, display_name, role, reputation, email_verified, created_at,
              (SELECT COUNT(*) FROM reviews r WHERE r.author_user_id = users.id) AS review_count
       FROM users
       WHERE phone_or_email ILIKE '%' || $1 || '%' OR display_name ILIKE '%' || $1 || '%'
       ORDER BY created_at DESC LIMIT 50`,
      [q]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load users" });
  }
});

// GET /api/admin/contact-messages?resolved=false
router.get("/contact-messages", async (req, res) => {
  const { resolved } = req.query;
  try {
    const params = [];
    let where = "";
    if (resolved !== undefined) { params.push(resolved === "true"); where = `WHERE resolved = $${params.length}`; }
    const { rows } = await pool.query(
      `SELECT * FROM contact_messages ${where} ORDER BY created_at DESC LIMIT 100`, params
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load messages" });
  }
});

// PATCH /api/admin/contact-messages/:id  { resolved }
router.patch("/contact-messages/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const { rows } = await pool.query(
      "UPDATE contact_messages SET resolved = $1 WHERE id = $2 RETURNING *",
      [!!req.body.resolved, id]
    );
    if (!rows[0]) return res.status(404).json({ error: "Message not found" });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update message" });
  }
});

// PATCH /api/admin/users/:id/role  { role: 'admin' | 'user' }
router.patch("/users/:id/role", async (req, res) => {
  const { role } = req.body;
  if (!["admin", "user"].includes(role)) return res.status(400).json({ error: "Invalid role" });
  try {
    const { rows } = await pool.query(
      "UPDATE users SET role = $1 WHERE id = $2 RETURNING id, phone_or_email, role", [role, req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error: "User not found" });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update role" });
  }
});

// ---------------------------------------------------------------------------
// Custom filters — lets an admin add new filterable property attributes
// without a code deploy. See migrations/007_custom_filters.sql.
// ---------------------------------------------------------------------------
router.get("/filter-definitions", async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT * FROM filter_definitions ORDER BY position ASC, created_at ASC`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load filter definitions" });
  }
});

const SLUG_RE = /^[a-z][a-z0-9_]*$/;

// POST /api/admin/filter-definitions  { key, label, type, options? }
router.post("/filter-definitions", async (req, res) => {
  const { key, label, type, options } = req.body;
  if (!key || !SLUG_RE.test(key)) return res.status(400).json({ error: "Key must be lowercase letters, numbers, and underscores, starting with a letter" });
  if (!label?.trim()) return res.status(400).json({ error: "Label is required" });
  if (!["boolean", "select"].includes(type)) return res.status(400).json({ error: "Type must be 'boolean' or 'select'" });
  if (type === "select" && (!Array.isArray(options) || options.length < 2)) {
    return res.status(400).json({ error: "Select filters need at least two options" });
  }
  try {
    const { rows: posRows } = await pool.query(`SELECT COALESCE(MAX(position), 0) + 1 AS next FROM filter_definitions`);
    const { rows } = await pool.query(
      `INSERT INTO filter_definitions (key, label, type, options, position)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [key, label.trim(), type, type === "select" ? JSON.stringify(options) : null, posRows[0].next]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    if (err.code === "23505") return res.status(409).json({ error: "A filter with this key already exists" });
    console.error(err);
    res.status(500).json({ error: "Failed to create filter" });
  }
});

// PATCH /api/admin/filter-definitions/:id  { label?, active?, options? }
router.patch("/filter-definitions/:id", async (req, res) => {
  const { label, active, options } = req.body;
  try {
    const { rows } = await pool.query(
      `UPDATE filter_definitions SET
         label = COALESCE($1, label),
         active = COALESCE($2, active),
         options = COALESCE($3, options)
       WHERE id = $4 RETURNING *`,
      [label ?? null, active ?? null, options ? JSON.stringify(options) : null, req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error: "Filter not found" });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update filter" });
  }
});

module.exports = router;
