const express = require("express");
const pool = require("../db/pool");
const { optionalAuth } = require("../auth");

const router = express.Router();

const RATING_FIELDS = ["water", "electricity", "security", "noise", "maintenance", "internet", "landlord", "value"];
const VALID_RECOMMEND = ["Definitely", "Probably", "Not sure", "Probably not", "Never"];

// POST /api/properties/:propertyId/reviews
router.post("/properties/:propertyId/reviews", optionalAuth, async (req, res) => {
  const { propertyId } = req.params;
  const {
    duration_lived, still_living_here = false, why_left = [], would_rent_again,
    ratings = {}, best_thing, wish_knew, verification_level = "unverified",
    reported_rent,
  } = req.body;

  if (would_rent_again && !VALID_RECOMMEND.includes(would_rent_again)) {
    return res.status(400).json({ error: "Invalid would_rent_again value" });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const propCheck = await client.query("SELECT id FROM properties WHERE id = $1", [propertyId]);
    if (!propCheck.rows[0]) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Property not found" });
    }

    const cols = ["property_id", "author_user_id", "duration_lived", "still_living_here", "why_left", "would_rent_again",
      "best_thing", "wish_knew", "verification_level"];
    const vals = [propertyId, req.user ? req.user.sub : null, duration_lived || null, still_living_here, why_left, would_rent_again || null,
      best_thing || null, wish_knew || null, verification_level];

    RATING_FIELDS.forEach(f => {
      cols.push(`rating_${f}`);
      const v = ratings[f];
      vals.push(Number.isInteger(v) && v >= 1 && v <= 5 ? v : null);
    });

    const placeholders = cols.map((_, i) => `$${i + 1}`).join(", ");
    const { rows } = await client.query(
      `INSERT INTO reviews (${cols.join(", ")}) VALUES (${placeholders}) RETURNING *`,
      vals
    );
    const review = rows[0];

    if (reported_rent && Number(reported_rent) > 0) {
      await client.query(
        `INSERT INTO rent_observations (property_id, amount, source_review_id) VALUES ($1,$2,$3)`,
        [propertyId, reported_rent, review.id]
      );
    }

    await client.query("COMMIT");
    res.status(201).json(review);
  } catch (err) {
    await client.query("ROLLBACK");
    console.error(err);
    res.status(500).json({ error: "Failed to submit review" });
  } finally {
    client.release();
  }
});

// POST /api/reviews/:id/reports — flag a review for moderation (right-of-dispute)
router.post("/reviews/:id/reports", async (req, res) => {
  const { id } = req.params;
  const { reason, details } = req.body;
  const validReasons = ["wrong_property", "false_info", "never_lived_there", "pii", "harassment", "spam", "other"];
  if (!validReasons.includes(reason)) {
    return res.status(400).json({ error: "Invalid reason" });
  }
  try {
    const { rows } = await pool.query(
      `INSERT INTO reports (target_type, target_id, reason, details) VALUES ('review',$1,$2,$3) RETURNING *`,
      [id, reason, details || null]
    );
    await pool.query(`UPDATE reviews SET status = 'under_review' WHERE id = $1`, [id]);
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to file report" });
  }
});

// POST /api/reviews/:id/responses — landlord right-of-response to a specific review
router.post("/reviews/:id/responses", async (req, res) => {
  const { id } = req.params;
  const { landlord_id, body } = req.body;
  if (!body || !body.trim()) return res.status(400).json({ error: "body is required" });
  try {
    const { rows } = await pool.query(
      `INSERT INTO responses (review_id, landlord_id, body) VALUES ($1,$2,$3) RETURNING *`,
      [id, landlord_id || null, body.trim()]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to submit response" });
  }
});

module.exports = router;
