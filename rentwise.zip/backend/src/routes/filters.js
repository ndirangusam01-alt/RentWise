const express = require("express");
const pool = require("../db/pool");

const router = express.Router();

// GET /api/filter-definitions — active custom filters, for both the search
// filter bar and the "amenities" section of the property creation form.
router.get("/", async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT id, key, label, type, options FROM filter_definitions
       WHERE active = true ORDER BY position ASC, created_at ASC`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load filters" });
  }
});

module.exports = router;
