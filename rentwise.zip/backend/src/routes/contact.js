const express = require("express");
const pool = require("../db/pool");

const router = express.Router();
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// POST /api/contact — the public Contact Us form. No auth required; anyone
// (renter, landlord, or someone reporting a review) can reach the team.
router.post("/", async (req, res) => {
  const { name, email, message } = req.body;
  if (!name?.trim() || !EMAIL_RE.test(email || "") || !message?.trim()) {
    return res.status(400).json({ error: "Name, a valid email, and a message are all required" });
  }
  try {
    const { rows } = await pool.query(
      `INSERT INTO contact_messages (name, email, message) VALUES ($1,$2,$3) RETURNING id, created_at`,
      [name.trim(), email.toLowerCase().trim(), message.trim()]
    );
    res.status(201).json({ received: true, id: rows[0].id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to send your message — please try again" });
  }
});

module.exports = router;
