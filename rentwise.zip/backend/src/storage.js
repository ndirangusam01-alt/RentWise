const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const UPLOAD_DIR = path.join(__dirname, "..", "uploads");
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const MAX_BYTES = 25 * 1024 * 1024; // 25MB
const ALLOWED_MIME = {
  "image/jpeg": "photo", "image/png": "photo", "image/webp": "photo",
  "video/mp4": "video", "video/quicktime": "video", "video/webm": "video",
  "application/pdf": "document",
};

// --- Local disk driver (default; works out of the box for dev) ---
// NOTE: most PaaS hosts (Render, Railway, Fly free tiers) use ephemeral
// filesystems — files written here are LOST on every redeploy/restart.
// Set STORAGE_DRIVER=s3 (see below) for anything beyond local development.
const localDriver = {
  name: "local",
  async save(buffer, originalName, mimeType) {
    const ext = path.extname(originalName) || "";
    const filename = `${crypto.randomUUID()}${ext}`;
    fs.writeFileSync(path.join(UPLOAD_DIR, filename), buffer);
    // "ref" is already a servable relative path for this driver.
    return { ref: `/uploads/${filename}`, mediaType: ALLOWED_MIME[mimeType] };
  },
  // Nothing to resolve — the ref IS the URL.
  async resolve(ref) {
    return ref;
  },
};

// --- S3 driver (production) ---
// Untested in this environment: the sandbox this was built in has no network
// path to AWS, so treat this as reviewed-but-unverified until you upload a
// real file against your own bucket. `npm install @aws-sdk/client-s3
// @aws-sdk/s3-request-presigner` before using it (already in package.json).
//
// Deliberately stores every object PRIVATE — no ACLs, no bucket policy
// required. That means it works unmodified with AWS's modern "Block all
// public access" default (the setting that makes the old `ACL: public-read`
// approach fail on any bucket created since ~2023). Public property photos
// and private review evidence live in the same private bucket; what makes a
// photo "public" is simply that any signed-in request can ask
// routes/properties.js to mint it a signed URL, while evidence can only be
// resolved through the admin-gated routes in routes/admin.js. Signing a URL
// is a local HMAC computation — no extra network round-trip to AWS, so doing
// it fresh on every read (rather than caching a permanent URL) costs nothing.
let _s3Client = null;
function s3Client() {
  if (!_s3Client) {
    const { S3Client } = require("@aws-sdk/client-s3");
    _s3Client = new S3Client({
      region: process.env.S3_REGION,
      endpoint: process.env.S3_ENDPOINT || undefined, // set only for R2 / Spaces / MinIO-style endpoints
      forcePathStyle: !!process.env.S3_ENDPOINT,
      // Omit `credentials` entirely to fall back to the default AWS credential
      // chain (IAM role, shared config file, etc.) if you'd rather not put
      // long-lived keys in .env — set S3_ACCESS_KEY_ID/S3_SECRET_ACCESS_KEY
      // only when you specifically want static-key auth.
      credentials: process.env.S3_ACCESS_KEY_ID
        ? { accessKeyId: process.env.S3_ACCESS_KEY_ID, secretAccessKey: process.env.S3_SECRET_ACCESS_KEY }
        : undefined,
    });
  }
  return _s3Client;
}

const s3Driver = {
  name: "s3",
  async save(buffer, originalName, mimeType) {
    const { PutObjectCommand } = require("@aws-sdk/client-s3");
    const ext = path.extname(originalName) || "";
    const key = `${crypto.randomUUID()}${ext}`;
    await s3Client().send(new PutObjectCommand({
      Bucket: process.env.S3_BUCKET,
      Key: key,
      Body: buffer,
      ContentType: mimeType,
    }));
    // "ref" is a bare object key here, not a URL — resolve() turns it into
    // a real, temporary URL only at the moment something needs to display it.
    return { ref: key, mediaType: ALLOWED_MIME[mimeType] };
  },
  async resolve(ref, { expiresIn = 3600 } = {}) {
    if (!ref) return ref;
    if (ref.startsWith("http") || ref.startsWith("/")) return ref; // already a URL, or a legacy local-driver path
    const { GetObjectCommand } = require("@aws-sdk/client-s3");
    const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
    return getSignedUrl(s3Client(), new GetObjectCommand({ Bucket: process.env.S3_BUCKET, Key: ref }), { expiresIn });
  },
};

const driver = process.env.STORAGE_DRIVER === "s3" ? s3Driver : localDriver;

// Resolve a list of rows' media fields in one batch (signing is cheap/local,
// but Promise.all keeps this tidy regardless of driver).
async function resolveMany(rows, field = "url") {
  return Promise.all(rows.map(async (row) => ({ ...row, [field]: await driver.resolve(row[field]) })));
}

module.exports = { driver, resolveMany, ALLOWED_MIME, MAX_BYTES, UPLOAD_DIR };
