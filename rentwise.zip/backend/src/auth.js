const jwt = require("jsonwebtoken");
const pool = require("./db/pool");

const SECRET = process.env.JWT_SECRET || "dev-only-insecure-secret-change-me";
if (!process.env.JWT_SECRET) {
  console.warn("⚠️  JWT_SECRET is not set — using an insecure default. Set it before deploying.");
}

function signToken(user) {
  return jwt.sign({ sub: user.id, email: user.phone_or_email }, SECRET, { expiresIn: "30d" });
}

function verifyToken(token) {
  return jwt.verify(token, SECRET);
}

// Attaches req.user if a valid Bearer token is present; does not block the request otherwise.
function optionalAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (token) {
    try { req.user = verifyToken(token); } catch { /* ignore invalid/expired token */ }
  }
  next();
}

// Blocks the request with 401 unless a valid Bearer token is present.
function requireAuth(req, res, next) {
  optionalAuth(req, res, () => {
    if (!req.user) return res.status(401).json({ error: "Authentication required" });
    next();
  });
}

// Blocks the request with 401/403 unless the caller is authenticated AND has
// role = 'admin' in the database. Role lives in the DB (not the JWT payload)
// so revoking admin access takes effect immediately, without waiting for
// tokens to expire.
async function requireAdmin(req, res, next) {
  requireAuth(req, res, async () => {
    try {
      const { rows } = await pool.query("SELECT role FROM users WHERE id = $1", [req.user.sub]);
      if (!rows[0] || rows[0].role !== "admin") {
        return res.status(403).json({ error: "Admin access required" });
      }
      next();
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Failed to verify admin access" });
    }
  });
}

module.exports = { signToken, verifyToken, optionalAuth, requireAuth, requireAdmin };
