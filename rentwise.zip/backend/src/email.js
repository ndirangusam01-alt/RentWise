const APP_BASE_URL = process.env.APP_BASE_URL || "http://localhost:5173";
const FROM = process.env.RESEND_FROM_EMAIL || "RentWise <onboarding@resend.dev>";

let resendClient = null;
function getClient() {
  if (!process.env.RESEND_API_KEY) return null;
  if (!resendClient) {
    const { Resend } = require("resend");
    resendClient = new Resend(process.env.RESEND_API_KEY);
  }
  return resendClient;
}

// Sends via Resend if RESEND_API_KEY is set; otherwise logs to the console so
// local development works without any email account at all. This fallback is
// intentional, not a stub to remove later — many real apps do exactly this in dev.
async function sendEmail({ to, subject, html }) {
  const client = getClient();
  if (!client) {
    console.log(`\n---- DEV EMAIL (no RESEND_API_KEY set, not actually sent) ----`);
    console.log(`To: ${to}\nSubject: ${subject}\n${html}`);
    console.log(`----------------------------------------------------------------\n`);
    return { devMode: true };
  }
  // NOTE: this call is written against Resend's documented API but has not been executed
  // in this environment — the sandbox this was built in has no network path to api.resend.com.
  // Verify against your own Resend account and API key before relying on it in production.
  return client.emails.send({ from: FROM, to, subject, html });
}

function sendVerificationEmail(to, token) {
  const link = `${APP_BASE_URL}/verify-email?token=${token}`;
  return sendEmail({
    to,
    subject: "Verify your RentWise account",
    html: `<p>Welcome to RentWise.</p><p><a href="${link}">Click here to verify your email</a>. This link expires in 24 hours.</p>`,
  });
}

function sendPasswordResetEmail(to, token) {
  const link = `${APP_BASE_URL}/reset-password?token=${token}`;
  return sendEmail({
    to,
    subject: "Reset your RentWise password",
    html: `<p>We received a request to reset your password.</p><p><a href="${link}">Click here to choose a new password</a>. This link expires in 1 hour. If you didn't request this, ignore this email.</p>`,
  });
}

module.exports = { sendEmail, sendVerificationEmail, sendPasswordResetEmail };
