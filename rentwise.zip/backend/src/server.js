require("dotenv").config();
const path = require("path");
const express = require("express");
const cors = require("cors");

const areasRouter = require("./routes/areas");
const propertiesRouter = require("./routes/properties");
const reviewsRouter = require("./routes/reviews");
const evidenceRouter = require("./routes/evidence");
const authRouter = require("./routes/auth");
const adminRouter = require("./routes/admin");
const contactRouter = require("./routes/contact");
const filtersRouter = require("./routes/filters");

const app = express();
app.use(cors());
app.use(express.json());
app.use("/uploads", express.static(path.join(__dirname, "..", "uploads")));

app.get("/api/health", (req, res) => res.json({ ok: true, service: "rentwise-backend" }));

app.use("/api/areas", areasRouter);
app.use("/api/properties", propertiesRouter);
app.use("/api", reviewsRouter);   // /api/properties/:id/reviews and /api/reviews/:id/*
app.use("/api", evidenceRouter);  // /api/properties/:id/evidence
app.use("/api/auth", authRouter);
app.use("/api/admin", adminRouter);
app.use("/api/contact", contactRouter);
app.use("/api/filter-definitions", filtersRouter);

app.use((req, res) => res.status(404).json({ error: "Not found" }));
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`RentWise API listening on port ${PORT}`));
